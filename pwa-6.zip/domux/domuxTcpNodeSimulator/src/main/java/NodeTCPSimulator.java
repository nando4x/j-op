import java.util.HashMap;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.InetAddress;
import java.util.Date;
import com.domux.center.devices.channels.DomuxTCPIP;
import com.nandox.libraries.Configuration;

public class NodeTCPSimulator  extends Thread {
	private ServerSocket serverSocket;
	private String fileName;
	private HashMap<String,Boolean> resources;
	String activeSession;
	String CMD_UNKNOWN = "command unknown or not in current service";
	int DMXRESP_OK = 1;
	int DMXRESP_ERRCRC = -1;
	int DMXRESP_ERRSYNTAX = -2;
	int DMXRESP_ERRCMDUNK = -3;
	int DMXRESP_ERRSRVUNK = -4;
	int DMXRESP_ERRCMDFUNDEF = -5;
	int DMXRESP_ERRRESUNK = -6;
	
	
	public NodeTCPSimulator(String ipaddr) throws Exception {
		if ( ipaddr != null && !ipaddr.isEmpty() )
			serverSocket = new ServerSocket(DomuxTCPIP.PORT,100,InetAddress.getByName(ipaddr));
		else
			serverSocket = new ServerSocket(DomuxTCPIP.PORT);
	    //serverSocket.setSoTimeout(10000);
		this.resources = new HashMap<String,Boolean>();
	}
	
	private String manageCmd(String data) {
		Configuration cfg = new Configuration();
		try {
			FileInputStream fi = new FileInputStream(this.fileName);
			cfg.load(fi);
			fi.close();
		} catch (Exception e) {
            e.printStackTrace();
		}
		
		this.generateID(cfg);

		String pars[] = data.split(" ");
		pars[0] = pars[0].toUpperCase();
		String ret = "";
		if ( pars[0].startsWith("SS") || pars[0].startsWith("STARTSESSION") ) {
			this.activeSession = pars[1];
            System.out.println("Active session " + this.activeSession);
            ret = "OK\n\r";
		} else if ( pars[0].startsWith("ES") || pars[0].startsWith("ENDSESSION") ) {
            System.out.println("Close session " + this.activeSession);
            ret = "OK\n\r";
		} else	if ( pars[0].startsWith("GETREG") ) {
			ret = this.getRegistration(cfg);
		} else	if ( pars[0].startsWith("GETCFG") ) {
			ret = this.getConfiguration(cfg);
		} else	if ( pars[0].startsWith("SETCFG") ) {
			ret = this.setConfiguration(cfg,pars[1]);
		} else	if ( pars[0].startsWith("FIRE") ) {
			ret = this.fire(cfg, pars[1].toUpperCase());
		} else	if ( pars[0].startsWith("READ") ) {
			ret = this.read(cfg, pars[1].toUpperCase());
		} else {
			ret = "ERROR "+ DMXRESP_ERRCMDUNK + "("+CMD_UNKNOWN+")";
		}
		return ret;
	}
	
	private String getRegistration(Configuration cfg) {
		String ret = "OK DXID=";
		ret += cfg.getStringValue("DXID", "")+"^^";
		ret += "NAME=";
		ret += cfg.getStringValue("NAME", "????")+"^^";
		ret += cfg.getStringValue("features", "");
		ret += "\n\r";
		return ret;
	}
	private String getConfiguration(Configuration cfg) {
		String ret = "OK ";
		ret += cfg.getStringValue("cfg", "");
		ret += "\n\r";
		return ret;
	}
	private String setConfiguration(Configuration cfg, String data) {
		String ret = "OK";
		int ini = data.indexOf("NAME=");
		int end = data.indexOf("^^", ini);
		cfg.setStringValue("NAME", data.substring(ini, end).split("=")[1]);
		cfg.setStringValue("cfg", data.substring(0,ini)+data.substring(end+2));
		try {
			FileOutputStream fo = new FileOutputStream(this.fileName);
			byte[] buff = new byte[cfg.getInputStream().available()];
			cfg.getInputStream().read(buff);
			fo.write(buff);
			fo.close();
		} catch (Exception e) {
			// TODO: manage error
		}
		ret += "\n\r";
		return ret;
	}
	private void generateID (Configuration cfg) {
		String id = cfg.getStringValue("DXID", "");
		if ( id.isEmpty() ) {
			Date dt = new Date();
			long i = dt.getTime();
			i = i * 1000 + (long)(Math.random() * 1000);
			cfg.setStringValue("DXID", ""+i);
			try {
				FileOutputStream fo = new FileOutputStream(this.fileName);
				byte[] buff = new byte[cfg.getInputStream().available()];
				cfg.getInputStream().read(buff);
				fo.write(buff);
				fo.close();
			} catch (Exception e) {
				
			}
		}
	}
	private String fire(Configuration cfg, String res) {
		if ( res.split("[=]").length <= 1 )
			return "ERROR " + DMXRESP_ERRSYNTAX + "(command syntax error)";
		if ( cfg.getStringValue("cfg", "").indexOf(res.split("[=]")[0]+".NAME=") < 0 ) 
			return "ERROR " + DMXRESP_ERRRESUNK + "(resource not found)";
		this.resources.put(res.split("[=]")[0],"1".equals(res.split("[=]")[1]));
		return "OK "  + res.split("[=]")[1] + "\n\r";
	}
	private String read(Configuration cfg, String res) {
		String[] rs = res.split(",");
		String val = "";
		for ( int ix=0; ix<rs.length; ix++ ) {
			if ( cfg.getStringValue("cfg", "").indexOf(rs[ix]) < 0 ) 
				return "ERROR " + DMXRESP_ERRRESUNK + "(resource not found)";
			Boolean r =this.resources.get(rs[ix]);
			val += (!val.isEmpty()?",":"") + (r!=null&&r?"1":"0"); 
		}
		return "OK "  + val + "\n\r";
	}
	public void run() {
   	 	Socket server = null;
	      while(true) {
	         try {
	            System.out.println("Waiting for client on port " + 
	               serverSocket.getLocalPort() + "...");
	            if ( server != null )
	            	server.close();
	            server = serverSocket.accept();
	            
	            System.out.println("Just connected to " + server.getRemoteSocketAddress());
	            //DataInputStream in = new DataInputStream(server.getInputStream());
	            InputStream in = server.getInputStream();
				byte[] chr = new byte[1];
				String data = "";
				while ( in.read(chr) > 0 ) {
					if ( chr [0] == '\n' )
						continue;
					if ( chr[0] == '\r' ) {
						while ( in.available() > 0 )
							in.read(chr);
						System.out.println("data: "+data);
						data = this.manageCmd(data);
						//DataOutputStream out = new DataOutputStream(server.getOutputStream());
						server.getOutputStream().write(data.getBytes());
						System.out.println("return: "+data);
						data = "";
					}
					if ( chr[0] >= 32 && chr[0] <= 127 )
						data += (char)chr[0];
				}
	            System.out.println("Connection finish " + server.getRemoteSocketAddress());
	            server.close();
	            
	         } catch (SocketTimeoutException s) {
	            System.out.println("Socket timed out!");
	            break;
	         } catch (IOException e) {
	            e.printStackTrace();
	            //break;
	         }
	      }
	   }	
	public static void main(String[] args) {
		try {
			String ip = "";
			if ( args.length > 1)
				ip = args[1];
			NodeTCPSimulator sim = new NodeTCPSimulator(ip);
			if ( args.length > 0)
				sim.fileName = args[0];
			sim.start();
			while (true) {
				Thread.sleep(1000);
			}
		} catch ( Exception e ) {
            System.out.println(e);
		}
	}

}
