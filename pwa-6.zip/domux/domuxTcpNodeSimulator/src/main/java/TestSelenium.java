import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
public class TestSelenium {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:/Users/Fernando/Downloads/chromedriver.exe");
		
		WebDriver d = new ChromeDriver();

		d.get("http://localhost:4502/domuxPWA/index.html?pages/configuration.html");
		String p1 = d.getPageSource();
		WebElement e = d.findElement(By.cssSelector("[tab-id=\"users\"]"));
		e.click();
		String p2 = d.getPageSource();
		p2 = p2;
		e = null;
	}

}
