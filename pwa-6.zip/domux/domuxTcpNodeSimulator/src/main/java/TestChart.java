import java.util.TreeMap;
import java.util.Map;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;  
import java.awt.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.io.FileOutputStream;
import java.io.IOException;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.renderer.xy.XYStepRenderer;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.data.time.TimeTableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.TextAnchor;
import org.jfree.chart.ChartUtilities;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.*;

import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTick;
import org.jfree.chart.axis.ValueTick;
import org.jfree.data.Range;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.TextAnchor;

public class TestChart {
	private void rendered() {
		
		LinkedHashMap<Date, String> termStructure= new LinkedHashMap<Date, String>();
		try {
			for ( int ix=2019;ix<=2069; ix++ ) {
				termStructure.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/06/" + ix),""+ix);
			}
		} catch ( Exception e) {}
		LinkedHashMap<Date, String> profile = new LinkedHashMap<Date, String>();
		try {
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/06/2019"),"Today");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("19/06/2019"),"1 day");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("20/06/2019"),"2 days");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("21/06/2019"),"3 days");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("25/06/2019"),"1 week");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("02/07/2019"),"2 weeks");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/07/2019"),"1 month");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("19/08/2019"),"2 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/09/2019"),"3 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/10/2019"),"4 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("19/11/2019"),"5 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/12/2019"),"6 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/01/2020"),"7 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/02/2020"),"8 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/03/2020"),"9 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/04/2020"),"10 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("19/05/2020"),"11 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2020"),"12 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/07/2020"),"13 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/08/2020"),"14 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("16/09/2020"),"15 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("19/10/2020"),"16 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/11/2020"),"17 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("16/12/2020"),"18 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/01/2021"),"19 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("16/02/2021"),"20 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/03/2021"),"21 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("19/04/2021"),"22 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/05/2021"),"23 months");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2021"),"2 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2022"),"3 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("20/06/2023"),"4 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/06/2024"),"5 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2025"),"6 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2026"),"7 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/06/2027"),"8 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("19/06/2028"),"9 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("19/06/2029"),"10 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/06/2030"),"11 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/06/2031"),"12 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2032"),"13 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2033"),"14 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("19/06/2034"),"15 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("19/06/2035"),"16 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2036"),"17 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2037"),"18 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2038"),"19 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("20/06/2039"),"20 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2044"),"25 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("17/06/2049"),"30 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/06/2059"),"40 years");
			profile.put(new SimpleDateFormat("dd/MM/yyyy").parse("18/06/2069"),"50 years");
		} catch ( Exception e) {}
		
		Calendar d = Calendar.getInstance();
		d.set(2019, 6, 18);
		
		Date fromTime = d.getTime();
		d.set(2070, 6, 23);
        Date toTime	= d.getTime();

        ValueAxis domainAxis = new RtExposureChartCustomDateAxis("Date", timePeriod(fromTime, toTime), termStructure);
        final NumberAxis rangeAxis = new NumberAxis("Value (EUR)");

        XYLineAndShapeRenderer exposureRenderer = new XYLineAndShapeRenderer(true, true);
        XYStepRenderer limitRenderer = new XYStepRenderer();

        XYDataset exposureDataSet = dataSet(profile, ExposureMetric.LCE_HIGH.getDescription(),  ExposureMetric.LCE_HIGH);
        XYDataset limitDataSet = dataSet(profile, "Limit");
        
        boolean isLimitUnlimited = false;
        
        XYPlot plot = new XYPlot(exposureDataSet, domainAxis, rangeAxis, exposureRenderer);


        plot.setDataset(1, limitDataSet);
        plot.setRenderer(1, limitRenderer);
        plot.setDatasetRenderingOrder(DatasetRenderingOrder.REVERSE);
        plot.setOrientation(PlotOrientation.VERTICAL);

        exposureRenderer.setSeriesPaint(0, new Color(1f, 0f, 0f, 0.7f));
        exposureRenderer.setSeriesShape(0, new Ellipse2D.Double(-2, -2, 4, 4));
        exposureRenderer.setSeriesStroke(
                0,
                new BasicStroke(
                        0.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                        1.0f, new float[]{10.0f, 10.0f}, 0.0f
                )
        );

        limitRenderer.setSeriesPaint   (0, new Color(0f, 0.6f, 0.2f, 0.9f));
        limitRenderer.setSeriesStroke(
                0,
                new BasicStroke(2.0f)
        );

        rangeAxis.setNumberFormatOverride(new DecimalFormat() {
            public StringBuffer format(double number, StringBuffer buffer, FieldPosition position) {
                NumberTickUnit tickUnit = rangeAxis.getTickUnit();

                if (tickUnit.getSize() > 1000000d) {
                    buffer.append((int)(number / 1000000));
                    buffer.append("m");
                } else if (tickUnit.getSize() > 100000d) {
                    buffer.append((double)((int)(number / 100000))/10);
                    buffer.append("m");
                }
                else {
                    buffer.append((int)number);
                }
                return buffer;
            }
        });

        domainAxis.setLabelInsets(new RectangleInsets(40, 0, 0, 0));

        JFreeChart ch = new JFreeChart(plot);
        
        try {

        	FileOutputStream out = new FileOutputStream("E:\\\\chart.png");
            ChartUtilities.writeChartAsPNG(out,
                    ch,
                    720,
                    500);

        } catch (IOException ex) {
        }
	}

    private static  XYDataset dataSet(
    		LinkedHashMap<Date, String> profile,
            String seriesName,
            ExposureMetric metric){
        TimeTableXYDataset dataSet = new TimeTableXYDataset();
        Date[] d = profile.keySet().toArray(new Date[0]);
        for ( int ix = 0; ix<(d.length-1); ix++ ) {
            Date fromTime = d[ix], toTime = d[ix+1];
            Double value = 0.0+ix;
            dataSet.add(timePeriod(fromTime, toTime), value != null ? Math.floor(value) : null, seriesName, true); // floor decimal values when rendering exposure charts
        }
        dataSet.setDomainIsPointsInTime(true);
        return dataSet;
    }
	
    private static XYDataset dataSet(
    		LinkedHashMap<Date, String> profile,
            String seriesName){
        TimeTableXYDataset dataSet = new TimeTableXYDataset();
        Date[] d = profile.keySet().toArray(new Date[0]);
        for ( int ix = 0; ix<(d.length-1); ix++ ) {
            Date fromTime = d[ix], toTime = d[ix+1];
            Double value = 2.0+ix;
            dataSet.add(timePeriod(fromTime, toTime), value, seriesName, true);
        }
        dataSet.setDomainIsPointsInTime(true);
        return dataSet;
    }

    private static SimpleTimePeriod timePeriod(Comparable fromTime, Comparable toTime) {
        if (fromTime instanceof Date) {
            return new SimpleTimePeriod((Date) fromTime, (Date) toTime);
        } else if (fromTime instanceof Long) {
            return new SimpleTimePeriod((Long) fromTime, (Long) toTime);
        }
        return null;
    }
	
	public static void main(String[] args) {
		Integer ten=new Integer(10);
		Long nine=new Long (9);
		System.out.println(ten + nine);
		int i=1; long l=0;
		System.out.println(i + ten);

		
		//TestChart t = new TestChart();
		//t.rendered();
	}

	
	static public class RtExposureChartCustomDateAxis extends NumberAxis {
	    private TreeMap<Long, TrackedBucket> bucketsByTime;
	    private int bucketIdx = 0;

	    class TrackedBucket {
	        String label;
	        long time;
	        int idx;

	        TrackedBucket(Map.Entry<Date, String> term) {
	            this.label = term.getValue();
	            this.idx = bucketIdx++;
	            time = term.getKey().getTime();
	        }
	    }

	    public RtExposureChartCustomDateAxis(String label, SimpleTimePeriod period, LinkedHashMap<Date, String> termStructure) {
	        super(label);
	        bucketsByTime = new TreeMap<Long, TrackedBucket>();
	        for (Map.Entry<Date, String> term : termStructure.entrySet()) {
	            TrackedBucket trackedBucket = new TrackedBucket(term);
	            bucketsByTime.put(trackedBucket.time, trackedBucket);
	            if(trackedBucket.time > period.getEndMillis())
	                break;
	        }
	        setRange(period.getStartMillis(), period.getEndMillis());
	    }
	    public List<ValueTick> refreshTicks(Graphics2D graphics2d, AxisState axisstate, Rectangle2D rectangle2d, RectangleEdge rectangleedge) {
	        super.refreshTicks(graphics2d, axisstate, rectangle2d, rectangleedge);
	        List<ValueTick> ticks = new ArrayList<ValueTick>();
	        for (TrackedBucket bucket : bucketsByTime.values())
	            ticks.add(new NumberTick(bucket.time, bucket.label, TextAnchor.TOP_LEFT, TextAnchor.TOP_LEFT, 45.0D));
	        return ticks;
	    }

	    public double valueToJava2D(double value, Rectangle2D area, RectangleEdge edge) {

	        Range range = getRange();
	        double axisMax = range.getUpperBound();

	        double min = 0.0;
	        double max = 0.0;
	        if (RectangleEdge.isTopOrBottom(edge)) {
	            min = area.getX();
	            max = area.getMaxX();
	        }
	        else if (RectangleEdge.isLeftOrRight(edge)) {
	            max = area.getMinY();
	            min = area.getMaxY();
	        }

	        double bucketLength = (max - min) / bucketsByTime.size();
	        long lValue = (long) value;
	        SortedMap<Long, TrackedBucket> lower = bucketsByTime.headMap(lValue + 1);
	        double offset = 0;
	        if (!lower.isEmpty()) {
	            Long lowerK = lower.lastKey();
	            SortedMap<Long, TrackedBucket> higher = bucketsByTime.tailMap(lowerK + 1);
	            long lowerTime = bucketsByTime.get(lowerK).time;
	            int lowerIdx = bucketsByTime.get(lowerK).idx;
	            offset = bucketLength * ((lValue - lowerTime) / ((!higher.isEmpty() ? bucketsByTime.get(higher.firstKey()).time : axisMax) - lowerTime) + lowerIdx);
	        }

	        if (isInverted()) {
	            return max - offset;
	        }
	        else {
	            return min + offset;
	        }

	    }

	    public double java2DToValue(double java2DValue, Rectangle2D area,
	                                RectangleEdge edge) {
	        throw new UnsupportedOperationException("Not supported yet");
	    }
	}
	public enum ExposureMetric {
		LCE_HIGH("Pre-Settlement Exposure incl. PDC and Electronic Reservations"),
	    LCE_LOW("LCE_LOW"),
		CPE("Current Exposure"),
	    CNE("Current Negative Exposure"),
		EPE("Expected Positive Exposure"),
	    ENE("Expected Negative Exposure"),
		PV("Present Value");
	    
	    String description;
	    
	    ExposureMetric(String description) {
	        this.description = description;
	    }

	    public String getDescription() {
	        return description;
	    }
	    
	    public boolean isFutureMetric() {
	    	return !isPresentMetric();
	    }
	    
	    public boolean isPresentMetric() {
	    	switch (this) {
				case PV:
				case CPE:
				case CNE:
					return true;
					
				case LCE_HIGH:
				case LCE_LOW:
				case EPE:
				case ENE:
					return false;
		
				default:
					throw new AssertionError("Unknown Metric: " + this);
			}
	    }
	}

}
