var Domux = Domux || {};

(function (libroot) {
	var CONST = Object.freeze({
		"$INJECTREF": '#temporary',
	});
	var URL = Object.freeze({
		"STATUSPAGE": 'pages/status.html',
		"INFOPAGE": 'pages/infohelp.html',
		"READSTATUS": '/domuxCenter/restservice/status',
		"READEVENTS": '/domuxCenter/restservice/getevents',
	});

	var $util = libroot.Utils;
	var $dom = libroot.Dom;
	var $comp = libroot.Component;
	var $ajax = libroot.Ajax;

	var _status = {};
	
	this.nodes = 1;
	this.status = {
			network: {
				disconnectedNodes: '',
				totalNodes: '',
				totalErrorConnections: '',
				totalConnections: '',
				dailyErrorConnections: '',
			}
		};
	//var _events = [];
	this.readStatus = function() {
		var _this = this;
		libroot.Rest.JsendReadData(this.options.addrCenter+URL.READSTATUS,{}).setsuccess(function(data){
			var e = libroot.Dom.qryAll(document,'[nx-attach-comp="VueContainer"][vueApp="Domux.statusView"]');
			for ( var ix=0; ix<e.length; ix++ ) {
				var v = libroot.Component.getInstance(e[ix]);
				if ( v != null )
					v.vueApp.status = _status = _this.status = data;
			}
		}).seterror(function(code,message,data){
			_this.showError(code,message,data);
		});
	};
	
	this.tableEventsLoader = function(table) {
		_this = this;
		table.load([]);
		libroot.Rest.JsendReadData(this.options.addrCenter+URL.READEVENTS,{}).setsuccess(function(data){
			_events = data;
			var transid = null;
			var arr = [];
			for ( var ix=0; ix<data.length; ix++ ) {
				var o = data[ix];
				if ( transid != o.transid ) {
					transid = o.transid;
					arr.push({ 'time': o.time, 'type': o.type, 'msg':o.msg, 'class': window.labels['LABEL_EVENT_NETWORK_CLASS_'+o.class], 
					     'target': o.target.name, 'data': o.data, 'transid':transid  
					   });
				} else {
					arr[arr.length-1].msg = o.msg + '<br>'  + arr[arr.length-1].msg;
				}
			}
			table.load(arr);
		}).seterror(function(code,message,data){
			_this.showError(code,message,data);
		});
	}
	
	this.tableEventsDeatils = function(data) {
		var tmpl = $dom.qry(document, '#status #eventsdetail');
		var arr = $util.filter(_events,function(o){
			if ( o.transid == data.transid )
				return true;
			return false;
		});
		var ret = '';
		var keys = Object.keys(data);
		for ( var ix=0; ix<arr.length; ix++ ) {
			arr[ix].class = window.labels['LABEL_EVENT_NETWORK_CLASS_'+arr[ix].class];
			arr[ix].target = data.target;
			ret += tmpl.innerHTML;
			for ( var k in keys ) {
				ret = ret.replace('${'+keys[k]+'}', arr[ix][keys[k]]);
			}
		}
		return ret;
	}
	
	this.statusView = {
		mixins: [this.baseVue],
		data: function() {
			return {
				status: _status,
				showNetwork: false
			}
		},
		computed: {
			globalStatus: function() {
				for ( i in this.status ) {
					if ( this.status[i] == true )
						return true;
				}
				return false;
			},
			showDetails: function() {
				return this.showNetwork;
			}
		},
		watch: {
			'showNetwork': function(value) {
				nx.Dom(document,'#status_network').setStyle('display',value?'block':'none');
			}
		},
		methods: {
		},
		mounted: function() {
			if ( nx.Dom(document,'#status_network')[0] ) {
				try {
					this.$el.appendChild(nx.Dom(document,'#status_network')[0]);
				} catch (e) {}
			}
			// cyclic check for wrong authentication
			var _this = this;
			function _checkWrongAuth() {
				setTimeout(function(){
					var st = _this.status;
					_this.status = {};
					st.wrongAuth = Domux.wrongAuth;
					st.connectionLost = Domux.connectionLost;
					_this.status = st;
					_checkWrongAuth();
				},2000);		
			}
			_checkWrongAuth();
		}
	}
	
	var statusOpen = false;
	this.openStatus = function() {
		this.openMenu(URL.STATUSPAGE);
		return;
	};
	this.closeStatus = function() {
		this.closeMenu(URL.STATUSPAGE);
		return;
	}
	
	this.gotoInfoHelp = function() {
		this.openMenu(URL.INFOPAGE);
	}
	this.closeInfoHelp = function() {
		this.closeMenu(URL.INFOPAGE);
		return;
	}
}).call( Domux,nx );
