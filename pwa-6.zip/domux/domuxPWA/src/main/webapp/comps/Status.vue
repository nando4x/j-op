<template compile-with="labels">
	<i class="material-icons status-icon" v-show="status">warning</i>
</template>
<script>
	var libroot = nx;
	this.Status = {
		template: '',
		props: {
			"asIcon": { type: Boolean, "default": true},
			"status": { type: Boolean, "default": false},
		},
		data: function() {
			return {
			}
		},
		computed: {
		},
		methods: {
		},
		mounted: function() {
		}
	}
</script>