package com.domux.center.devices.channels;

import java.lang.StringBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.bluetooth.*;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;

//import org.springframework.stereotype.Component;
//import org.springframework.beans.factory.annotation.Value;

import com.domux.center.devices.DomuxChannel;
import com.domux.center.monitoring.MonitorEvent;
import com.nandox.libraries.Return;
import com.nandox.libraries.logging.Logger;

/**
 * Implementation of bluetooth channel.<br>
 * This channel don't use CRC checking  
 * 
 * @project   domuxCenter
 * 
 * @module    DomuxBlueTooth.java
 * 
 * @date      16 apr 2019 - 16 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
//@Component
public class DomuxBlueTooth implements DomuxChannel {
	private final OutputStream out;
	private final InputStream in;
	private final String url;
	private static Map<String,BTConnection> connPool = new HashMap<String,BTConnection>();
	
//	@Value("${channels.bluetooth.timeout:45}")
//	private int timeOut;
	/**
	 * Constructor
	 * @param	  url url to connect to device
	 * @date      16 apr 2019 - 16 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception Exception generic to cover all java.net.Socket exception type<br>
	 */
	public DomuxBlueTooth(String url) throws Exception {
		this.url = url;
		//javax.bluetooth.Initializer.Restart();
		BTConnection bc = connPool.get(url);
		if ( bc == null || bc.errorsCounter >= 10 ) {
			//removeURL(url);
			bc = new BTConnection();
			bc.conn = (StreamConnection)Connector.open(url);
			bc.out = bc.conn.openOutputStream();
			bc.in = bc.conn.openInputStream();
			bc.rdev = com.intel.bluetooth.RemoteDeviceHelper.implGetRemoteDevice(bc.conn);
			connPool.put(url, bc);
		}
		this.out = bc.out;
		this.in = bc.in;
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#readData()
	 */
	public Return readData() throws Exception {
		byte[] chr = new byte[1];
		String data = "";
		long time, start;
		time = start = System.currentTimeMillis();
		connPool.get(this.url).errorsCounter++;
		while ( time < (start + 45*1000) ) {
			if ( this.in.available() > 0 ) {
				this.in.read(chr);
				if ( (char)chr[0] == '\n' )
					continue;
				if ( (char)chr[0] == '\r' )
					return new Return(Return.RET_OK,data);
				data += (char)chr[0];
				connPool.get(this.url).errorsCounter = 0;
			}
			Thread.sleep(1);
			time = System.currentTimeMillis();
		}
		removeURL(this.url);
		throw new java.util.concurrent.TimeoutException();
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#writeData(java.lang.String)
	 */
	public Return writeData(String data) throws Exception {
		String s;
		if ( data != null ) {
			if ( data.trim().endsWith("\r") || data.trim().endsWith("\r\n") )
				s = data;
			else
				s = data + "\r";
		} else
			s = "\r";
		connPool.get(this.url).errorsCounter++;
		this.out.write(s.getBytes());
		this.out.flush();
		connPool.get(this.url).errorsCounter = 0;
		return new Return(Return.RET_NOTHING,null);
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#hasCRC()
	 */
	public boolean hasCRC() {
		return false;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#close()
	 */
	public void close() throws Exception {
	}
	/**
	 * Utility to get all devices URL
	 * @param	  monitor	event monitor to use
	 * @param	  log	logger to use
	 * @date      16 apr 2019 - 16 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  true if port is active
	 */
	public static String[] getDevicesURL(MonitorEvent monitor, Logger log) throws Exception {
		if ( log != null )
		log.debug("star BT devicediscovery");
		List<RemoteDevice> devs = discoveryDevice(monitor, log);
		ArrayList<String> urls = new ArrayList<String>();
    	for ( RemoteDevice dev : devs ) {
    		String url = discoveryService(dev, 0x1101, monitor, log);
    		if ( url != null && url.length() > 0 ) {
    			urls.add(url);
            	//com.intel.bluetooth.RemoteDeviceHelper.authenticate(dev.rdev, "12345");
    		}
		}
		return urls.toArray(new String[0]);
	}
	/**
	 * Remove url from connections pool
	 * @param	  url	url to remove
	 * @date      16 apr 2019 - 16 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  true if port is active
	 */
	public static void removeURL(String url) {
		BTConnection bt = connPool.remove(url);
		try {
			bt.out.close();
			bt.in.close();
			bt.conn.close();
		} catch (Exception e) {
			
		}
	}
	//
	//
	//
	private static List<RemoteDevice> discoveryDevice(MonitorEvent monitor, final Logger log) {
		final Object inquiryCompletedEvent = new Object();
		final List<RemoteDevice> devs = new ArrayList<RemoteDevice>();
		DiscoveryListener listener = new DiscoveryListener() {
            public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
                try {
                	devs.add(btDevice);
                	if ( log != null )
        			log.debug("discovered BT device %s, %s", btDevice.getBluetoothAddress(), btDevice.getFriendlyName(false));
                } catch (IOException cantGetDeviceName) {
                }
            }
            public void inquiryCompleted(int discType) {
                synchronized(inquiryCompletedEvent){
                    inquiryCompletedEvent.notifyAll();
                }
            }

            public void serviceSearchCompleted(int transID, int respCode) {
            }
            public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {
            }
        };
        try {
	        synchronized(inquiryCompletedEvent) {
	            boolean started = LocalDevice.getLocalDevice().getDiscoveryAgent().startInquiry(DiscoveryAgent.GIAC, listener);
	            if (started) {
	                inquiryCompletedEvent.wait();
	            }
	        }
        } catch (Exception e) {
        	if (monitor != null )
			monitor.registerEvent(null, MonitorEvent.Type.SYSERROR, "discovery BT devices error", null, e);
        	if ( log != null )
			log.error("Error in BT discovery devices", e);
        }
        return devs;
	}
	private static String discoveryService(RemoteDevice device, int uuid, MonitorEvent monitor, final Logger log) {
		final Object inquiryCompletedEvent = new Object();
		final StringBuilder url = new StringBuilder();
		DiscoveryListener listener = new DiscoveryListener() {
            public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
            }
            public void inquiryCompleted(int discType) {
            }
            public void serviceSearchCompleted(int transID, int respCode) {
                synchronized(inquiryCompletedEvent){
                    inquiryCompletedEvent.notifyAll();
                }
            }
            public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {
            	 for (int i = 0; i < servRecord.length; i++) {
            		 url.append(servRecord[i].getConnectionURL(ServiceRecord.NOAUTHENTICATE_NOENCRYPT, false));
            		 if ( url.length() > 0 ) {
            			 DataElement sname = servRecord[i].getAttributeValue(0x0100);
            			 if ( log != null )
             			 log.debug("found BT service: %s, %s", (sname!=null?sname.getValue():"")+"", url.toString());
            			 break;
            		 }
            	 }
            }
        };
    	int[] attrsID = new int[]{
        		0x0100	
       	};
    	UUID[] uuids = new UUID[]{
    			new UUID(uuid)
    	};
    	try {
	        synchronized(inquiryCompletedEvent) {
	            LocalDevice.getLocalDevice().getDiscoveryAgent().searchServices(attrsID, uuids, device, listener);
	        	inquiryCompletedEvent.wait();
	        }
    	} catch (Exception e) {
			 log.error("Error in BT service discovery", e);
    	}
		return url.toString();
	}
	static class BTConnection {
		protected RemoteDevice rdev;
		protected StreamConnection conn;
		protected OutputStream out;
		protected InputStream in;
		protected int errorsCounter;
	}
}

