package com.domux.center.services.restful;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.domux.center.ControlCenter;
import com.domux.center.monitoring.MonitorEvent;
import com.domux.center.monitoring.MonitorEvent.EventData;

/**
 * Status restful query controller 
 * 
 * @project   domuxCenter
 * 
 * @module    StatusService.java
 * 
 * @date      01 apr 2019 - 01 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", allowCredentials="true")
public class StatusService extends AbstarctJsendService {

	@Autowired
	@Qualifier("controlCenter")
	private ControlCenter cCenter;
	
	/**
	 * status service: return to complete system status.<br>
	 * Response with all SystemStatus properties as jsend data
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response as String
	 */
	@GetMapping(path = "/status",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String getStatus () {
		return this.responseSuccess(this.toJsonTree(this.cCenter.getStatus()));
	}
	/**
	 * getenvents service: return to complete events list.<br>
	 * Response with this jsend data:
	 * 		{
	 *			  [{time: string,
	 *		      	msec: number,
	 *		      	type: string,
	 * 			  	transid: number
	 * 				class: string
	 * 				msg: string
	 * 				target: {
	 *		        	dxid: string,
	 *		        	name: string,
	 *		        	Class: stirng
     *		        }	        	]
	 *		       }]
	 *		}
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response as String
	 */
	@GetMapping(path = "/getevents",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String getEvents () {
		MonitorEvent.Type[] types = {MonitorEvent.Type.NETWORK,MonitorEvent.Type.NETWORKERROR};
		List<EventData> data = cCenter.getMonitorManager().searchLastByType(types);
		return this.responseSuccess(this.toJsonTree(this.eventDataTransformer(data)));
	}
	// Transform event data to json
	//
	//
	private List<Map<String,Object>> eventDataTransformer(List<EventData> data) {
		List<Map<String,Object>> ret = new ArrayList<Map<String,Object>>(); 
		for ( EventData e : data ) {
			ret.add(e.toJSON());
		}
		return ret;
	}
}
