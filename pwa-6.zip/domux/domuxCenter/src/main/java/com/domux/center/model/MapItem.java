package com.domux.center.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.nandox.libraries.validation.BeanValidable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.validation.constraints.Min;
import javax.validation.constraints.Max;
/**
 * Map Resource data model POJO:<br>
 * contains resource reference and map coordinates
 * 
 * @project   domuxCenter
 * 
 * @module    MapItem.java
 * 
 * @date      30 mar 2019 - 30 mar 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "dxid",
    "x",
    "y"
})
public class MapItem extends BeanValidable {
	private static final int MAXAXISVALUE = 5000;
	private static final int MINAXISVALUE = 1;
	
	@NotNull(message = "ERROR_FIELD_MAP_DXIDNULL")
	@Size(min=1, message = "ERROR_FIELD_MAP_DXIDNULL")
    @XmlElement(name = "dxid", required = true)
	private String dxid;
	@Min(value=MINAXISVALUE,message = "ERROR_FIELD_MAP_XSIZE")
	@Max(value=MAXAXISVALUE,message = "ERROR_FIELD_MAP_XSIZE")
    @XmlElement(name = "x", required = true)
	private int x;
	@Min(value=MINAXISVALUE,message = "ERROR_FIELD_MAP_YSIZE")
	@Max(value=MAXAXISVALUE,message = "ERROR_FIELD_MAP_YSIZE")
    @XmlElement(name = "y", required = true)
	private int y;
    
	/**
	 * @return the dxid
	 */
	public String getDxid() {
		return dxid;
	}
	/**
	 * @param dxid the dxid to set
	 */
	public void setDxid(String dxid) {
		this.dxid = dxid;
	}
	/**
	 * @return the x
	 */
	public int getX() {
		return x;
	}
	/**
	 * @param x the x to set
	 */
	public void setX(int x) {
		this.x = x;
	}
	/**
	 * @return the y
	 */
	public int getY() {
		return y;
	}
	/**
	 * @param y the y to set
	 */
	public void setY(int y) {
		this.y = y;
	}
}
