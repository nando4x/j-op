package com.domux.center.services.restful;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import javax.ws.rs.core.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.domux.center.model.MapItem;
import com.domux.center.model.Node;
import com.nandox.libraries.ErrorGroupMarker;
import com.domux.center.Labels;
import com.domux.center.database.DomuxDataBase;
import com.domux.center.database.PhysicalContainer.MapImage;

/**
 * Resource map restful operation controller to get resources map items and save its changes
 * 
 * @project   domuxCenter
 * 
 * @module    MapService.java
 * 
 * @date      01 apr 2019 - 01 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", allowCredentials="true")
public class MapService extends AbstarctJsendService {
	@ErrorGroupMarker(-2100)
	public enum Error {
		/** Error code database not ready */
		RET_ERR_DBNOTREADY,
		/** Error code saving image data */
		RET_ERR_SAVINGIMAGE,
		/** Error saving map data */
		RET_ERR_SAVIGMAP;
	}

	@Autowired
	@Qualifier("db")
	private DomuxDataBase db;

	/**
	 * getmapstyle service: return map image background.<br>
	 * Response with this jsend data:
	 * 		{
	 *			data: string,  // base64 css background-image rule
	 *		    width: number,   
	 *		    height: number   
	 *		}
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response as String
	 */
	@GetMapping(path = "/getmapstyle", produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String getMapStyle () {
		try {
			HashMap<String,Object> data = new HashMap<String,Object>();
			data.put("data", this.db.getMapImageData());
			data.put("width", this.db.getMapImageWidth());
			data.put("height", this.db.getMapImageHeight());
			return this.responseSuccess(this.toJsonTree(data));
		} catch (Exception e) {
			this.log.error("Database not ready or not inizialized", e);
			return this.responseError(Error.RET_ERR_DBNOTREADY, e);
		}
	}
	/**
	 * getmap service: return to complete map item list.<br>
	 * Response with this jsend data:
	 * 		{
	 *			map:[
	 *		       {
	 *				dxid: string,
	 *		        x: number,
	 *		        y: number
	 *		       }
	 *	 		]
	 *		}
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response as String
	 */
	@GetMapping(path = "/getmap", produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String getMap () {
		try {
			ArrayList<MapItem> data = new ArrayList<MapItem>(db.getMap().values());
			HashMap<String,ArrayList<MapItem>> map = new HashMap<String,ArrayList<MapItem>>();
			map.put("map", data);
			return this.responseSuccess(this.toJsonTree(map));
		} catch (Exception e) {
			this.log.error("Database not ready or not inizialized", e);
			return this.responseError(Error.RET_ERR_DBNOTREADY, e);
		}
	}
	/**
	 * sendmapstyle service: receive map image background and save it on database<br>
	 * Expect this request:
	 * 		{
	 *			data: string,  // base64 css background-image rule
	 *		    width: number,   
	 *		    height: number   
	 *		}
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response (with no data) as String
	 */
	@PostMapping(path = "/sendmapimage",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String sendImage (@RequestBody String json) {
		try {
			MapImage img = this.fromJson(json, MapImage.class);
			// Validate data
			Map<String,String> data = img.validate();
			if ( data.size() > 0 ) {
				this.log.warn("invalid data on saving image map: %s", data.keySet().toString());
				return this.responseFail(this.toJsonTree(data));
			}
			// Save into database
			db.saveMapImage(img);
			return this.responseSuccess(null);
		} catch (Exception e) {
			this.log.error("Error on saving map image", e);
			return this.responseError(Error.RET_ERR_SAVINGIMAGE, e);
		}
	}
	/**
	 * sendmap service: receive map items list and save it on database<br>
	 * Expect this request:
	 * 		[
	 *		  {
	 *			dxid: string,
	 *		    x: number,
	 *		    y: number
	 *		  }
	 *	 	]
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response as String
	 */
	@PostMapping(path = "/sendmap",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String sendMap (@RequestBody String json) {
		try {
			MapItem[] map = this.fromJson(json, MapItem[].class);
			// Validate data
			for ( MapItem i : map ) {
				Map<String,String> fail = i.validate();
				if ( fail != null && fail.size() > 0 ) {
					this.log.warn("invalid data on saving map, id: %s, fields: %s", i.getDxid(), fail.keySet().toString());
					return this.responseFail(this.toJsonTree(fail));
				}
				// validate reference
				try {
					if ( i.getDxid().indexOf('.') >= 1 ) {
						String nid = i.getDxid().substring(0, i.getDxid().indexOf('.'));
						String rid = i.getDxid().substring(i.getDxid().indexOf('.')+1);
						Node n = this.db.searchNodeByDxID(nid);
						if ( n != null && n.getResourceById(rid) != null ) {
							// search if duplicated
							for ( MapItem i1 : map ) {
								if ( i1 != i && i.getDxid().equals(i1.getDxid())) {
									fail.put(i.getDxid(), Labels.ERROR_FIELD_RESOURCE_DUPLICATED);
									this.log.warn("duplicated on saving map id: %s", i.getDxid());
									return this.responseFail(this.toJsonTree(fail));
								}
							}
							continue;
						}
					} 
					throw new NumberFormatException();
				} catch ( NumberFormatException e ) {
					fail.put(i.getDxid(), Labels.ERROR_FIELD_RESOURCE_NOTFOUND);
					this.log.warn("resource not found or malformed dxid on saving map dxid: %s", i.getDxid());
					return this.responseFail(this.toJsonTree(fail));
				}
			}
			// Save into database
			this.db.saveMap(Arrays.asList(map));
			return this.responseSuccess(null);
		} catch (Exception e) {
			this.log.error("Error on saving map", e);
			return this.responseError(Error.RET_ERR_SAVIGMAP, e);
		}
	}
}
