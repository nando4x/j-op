package com.domux.center.database.phyimpl.xml;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Marshaller;

import com.nandox.tomcatext.JAASUserDatabase.User;
import com.domux.center.logging.BaseLogger;
import com.domux.center.database.PhysicalContainer;
import com.domux.center.model.MapItem;
import com.domux.center.model.Node;
import com.domux.center.model.Resource;
/**
 * Xml physical container for database.
 * The XML file follow this schema:
 * 
 *		 <DataBase>
 *		  <Components>
 *		    <Nodes>
 *		      <Node dxid="...">
 *		        <id>...</id>
 *		        <type>...</type>
 *		        <addrBT>...</addrBT>
 *		        <addrI2C>...</addrI2C>
 *		        <addrIP>...</addrIP>
 *		        <capabilities>
 *		          <hasBT>>...</hasBT>
 *		          <hasI2C>...</hasI2C>
 *		          <hasIP>...</hasIP>
 *		        </capabilities>
 *		        <resourceList>
 *		        	<Resource>
 *		          		<id>...</id>
 *		          		<type>...</type>
 *		        	</Resource>
 *		        </resourceList>
 *		      </Node>
 *		    </Nodes>
 *		  </Components>
 *		  <Map>
 *		    <Resource>
 *		      <id>...</id>
 *		      <x>...</x>
 *		      <y>...</y>
 *		    </Resource>
 *		  </Map>
 *		</DataBase>
 * 
 * @project   domuxCenter
 * 
 * @module    XmlContainer.java
 * 
 * @date      02 apr 2019 - 02 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public class XmlContainer extends BaseLogger implements PhysicalContainer {
	private String dbFileName;
	private JAXBContext jaxb;
	private DataBase data;
		
	/**
	 * Constructor
	 * @param	  dbFilePathName	absolute pathname of xml file
	 * @date      02 apr 2019 - 02 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @throws 	  JAXBException	only in case of wrong refactoring code
	 * @throws 	  FileNotFoundException	in case of path of new file not exist
	 */
	public XmlContainer(String dbFilePathName) throws Exception {
		super();
		try {
			this.getLog().info("XML database start initialization");
			this.dbFileName = dbFilePathName;
			this.jaxb = JAXBContext.newInstance(this.getClass().getPackage().getName());
			File f = new File(this.dbFileName);
			File f1 = new File(this.dbFileName+".bak");
			if ( !f.exists() && !f1.exists() ) {
				this.getLog().info("XML database creat new file...");
				try {
					this.createNew();
				} catch (Exception e) {
					this.getLog().error("XML database error creating file: " + this.dbFileName + e.getMessage());
					throw e;
				}
			}
			this.getLog().info("XML database initialized");
		} catch (Exception e) { 
			this.getLog().error("XML database NOT initialized: " + e.getMessage());
			throw e;
		}
	}
	/* (non-Javadoc)
	 * @see com.domux.center.database.PhysicalContainer#loadNodeData()
	 * @throws	FileNotFoundException	if xml file not more exist
	 * @throws	JAXBException	in case of wrong xml schema
	 */
	public Map<String, Node> loadNodeData() throws Exception {
		this.log.info("XML database nodes data loading...");
		Map<String, Node> ret = new HashMap<String, Node>();
		Unmarshaller u = null;
		try {
			if ( this.data == null ) {
				u = this.jaxb.createUnmarshaller();
				this.data = (DataBase)u.unmarshal(new FileInputStream(this.dbFileName));
			}
			// adjust dxid of every resource
			for ( Node n : this.data.components.nodes.getNode() ) {
				for ( Resource r : n.getResourceList() )
					r.setDxid(n.getDxid()+"."+r.getId());
				ret.put(n.getDxid(), n);
			}
			this.log.info("XML database nodes data loaded");
		} catch ( FileNotFoundException e) {
			this.log.error("XML database file not found: "+this.dbFileName);
			throw e;
		} catch ( JAXBException e) {
			this.log.error("XML database loading error: "+e.getMessage());
			throw e;
		}
		return ret;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.database.PhysicalContainer#saveNodeData(java.util.Collection)
	 * @throws 	FileNotFoundException if xml file not more exist
	 * @throws	JAXBException	in case of wrong xml schema
	 * @throws  IOException in case of write  IO error
	 */
	public void saveNodeData(Collection<Node> data) throws Exception {
		this.data.components.nodes.node = new ArrayList<Node>(data);
		this.save();
	}
	/* (non-Javadoc)
	 * @see com.domux.center.database.PhysicalContainer#laodMapData()
	 * @throws	FileNotFoundException	if xml file not more exist
	 * @throws	JAXBException	in case of wrong xml schema
	 */
	public Map<String, MapItem> loadMapData() throws Exception {
		this.log.info("XML database map data loading...");
		Map<String, MapItem> ret = new HashMap<String, MapItem>();
		Unmarshaller u = null;
		try {
			if ( this.data == null ) {
				u = this.jaxb.createUnmarshaller();
				this.data = (DataBase)u.unmarshal(new FileInputStream(this.dbFileName));
			}
			for ( MapItem i : this.data.map.getResource() ) {
				ret.put(i.getDxid(), i);
			}
			this.log.info("XML database map data loaded");
		} catch ( FileNotFoundException e) {
			this.log.error("XML database file not found: "+this.dbFileName);
			throw e;
		} catch ( JAXBException e) {
			this.log.error("XML database loading error: "+e.getMessage());
			throw e;
		}
		return ret;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.database.PhysicalContainer#saveMapData(java.util.Collection)
	 * @throws 	FileNotFoundException if xml file not more exist
	 * @throws	JAXBException	in case of wrong xml schema
	 * @throws  IOException in case of write  IO error
	 */
	public void saveMapData(Collection<MapItem> data) throws Exception {
		this.data.map.resource = new ArrayList<MapItem>(data);
		this.save();
	}
	/* (non-Javadoc)
	 * @see com.domux.center.database.PhysicalContainer#laodImageData()
	 */
	public PhysicalContainer.MapImage loadImageData() {
		return new PhysicalContainer.MapImage(
											this.data.map.imageWidth,
											this.data.map.imageHeight,
											this.data.map.imageData);
	}
	/* (non-Javadoc)
	 * @see com.domux.center.database.PhysicalContainer#saveImageData(com.domux.center.database.PhysicalContainer.MapImage)
	 * @throws 	FileNotFoundException if xml file not more exist
	 * @throws	JAXBException	in case of wrong xml schema
	 * @throws  IOException in case of write  IO error
	 */
	public void saveImageData(MapImage data) throws Exception {
		this.data.map.imageData = data.getData();
		this.data.map.imageWidth = data.getWidth();
		this.data.map.imageHeight = data.getHeight();
		this.save();
	}
	/* (non-Javadoc)
	 * @see com.domux.center.database.PhysicalContainer#getNewId()
	 */
	public int getNewId() throws Exception {
		this.data.idGenerator++;
		return this.data.idGenerator;
	}
	// save database data to xml file
	//
	//
	private void save () throws Exception {
		this.log.info("XML database data saving...");
		Marshaller m = null;
		try {
			// create backup
			OutputStream os = new FileOutputStream(this.dbFileName+".bak");
			Files.copy(Paths.get(this.dbFileName), os);
			os.close();
			m = this.jaxb.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.marshal(this.data, new FileOutputStream(this.dbFileName));
			this.log.info("XML database data saved");
		} catch ( FileNotFoundException e) {
			this.log.error("XML database file not created: "+this.dbFileName);
			throw e;
		} catch ( JAXBException e) {
			this.log.error("XML database saving error: "+e.getMessage());
			throw e;
		} catch ( IOException e) {
			this.log.error("XML database backuping error: "+e.getMessage());
			throw e;
		}
	}
	// Create new xml file with empty xml schema
	//
	//
	private void createNew() throws Exception {
		ObjectFactory of = new ObjectFactory();
		this.data = of.createDataBase();
		this.data.components = of.createDataBaseComponents();
		this.data.components.nodes = of.createDataBaseComponentsNodes();
		this.data.map = of.createDataBaseMap();
		this.data.users = of.createDataBaseUsers();
		User user = new User();
		user.setId(0);
		user.setName("admin");
		user.setPassword("admin");
		user.setRole("admin");
		this.data.users.user = new ArrayList<User>();
		this.data.users.user.add(user);
		Marshaller m = null;
		m = this.jaxb.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		m.marshal(this.data, new FileOutputStream(this.dbFileName));
	}
}
