package com.domux.center.devices;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import com.domux.center.devices.DomuxProtocol.Command;
import com.domux.center.devices.DomuxProtocol.Service;
import com.domux.center.devices.channels.DomuxTCPIP;
import com.domux.center.devices.channels.DomuxBlueTooth;
import com.domux.center.devices.channels.DomuxSerial;
import com.domux.center.devices.nodes.NodeFactory;
import com.domux.center.logging.BaseLogger;
import com.domux.center.model.Node;
import com.domux.center.monitoring.MonitorEvent;
import com.nandox.libraries.Return;
import com.nandox.libraries.Configuration;

/**
 * Basically implementation of DeviceManager:<br>
 * discovery nodes on all physical channel: bluetooth, I2C bus and tcpip network (LAN o Wifi)  
 * 
 * @project   domuxCenter
 * 
 * @module    DeviceManagerImpl.java
 * 
 * @date      16 apr 2019 - 16 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public class DeviceManagerImpl extends BaseLogger implements DeviceManager, Runnable {
	private static final String EVENTMSG_START_DISCOVERY = "node discovery start";
	private static final String EVENTMSG_END_DISCOVERY = "node discovery end";
	private static final String EVENTMSG_ERROR_DISCOVERY = "node discovery error";
	private static final String EVENTMSG_START_DOMUX = "domux session start";
	private static final String EVENTMSG_END_DOMUX = "domux session end";
	private static final String EVENTMSG_ERROR_DOMUX = "domux session error";
	private DomuxProtocol dmxp;
	private MonitorEvent monitor;
	private String port;
	private String initBaud;
	/**
	 * Constructor
	 * @param	  monitor event monitor to use
	 * @date      16 apr 2019 - 16 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public DeviceManagerImpl(MonitorEvent monitor, String port, String baud) {
		this.dmxp = new DomuxProtocol();
		this.monitor = monitor;
		this.port = port;
		this.initBaud = (baud!=null&&!baud.isEmpty()?baud:"9600");
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DeviceManager#discoveryNodes
	 */
	private final ArrayList<Node> ret = new ArrayList<Node>();
	private CountDownLatch sync;
	public Collection<Node> discoveryNodes() {
		try {
			ret.clear();
			sync = new CountDownLatch(3);
			Thread th1 = new Thread(this,"discoveryTCP");
			th1.start();
			Thread th2 = new Thread(this,"discoveryBlueTooth");
			th2.start();
			Thread th3 = new Thread(this,"discoverySerial");
			th3.start();
			sync.await(5,TimeUnit.MINUTES);
			sync = null;
		} catch (Exception e) {
			log.error("Error on discevery threads", e);
		}
		return ret;
	}
	/* Discovery Thread by type: tcp, bluetooth, ... 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		String name = Thread.currentThread().getName();
		if ( "discoveryTCP".equals(name) ) {
			ret.addAll(this.discoveryTCPIP());
		}	
		if ( "discoveryBlueTooth".equals(name) ) {
			try {
			ret.addAll(this.discoveryBlueTooth());
			} catch (NoClassDefFoundError r) {
				r = null;
			}
		}	
		if ( "discoverySerial".equals(name) ) {
			ret.addAll(this.discoverySerial());
		}	
		this.sync.countDown();
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.DeviceManager#executeDomuxProtocolCommand(com.domux.center.model.Node, com.domux.center.devices.DomuxProtocol.Service, com.domux.center.devices.DomuxProtocol.Command, java.lang.String)
	 */
	public Return executeDomuxProtocolCommand(Node node, Service service, Command cmd, String data) {
		return this.executeDomuxProtocolCommand(node, service, cmd, data, false);
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DeviceManager#executeDomuxProtocolCommand(com.domux.center.model.Node, com.domux.center.devices.DomuxProtocol.Service, com.domux.center.devices.DomuxProtocol.Command, java.lang.String, boolean)
	 */
	public Return executeDomuxProtocolCommand(Node node, Service service, Command cmd, String data, boolean prvSess) {
		DomuxChannel ch = null;
		Integer trId = null;
		log.debug("Executing %s on %s", cmd.getValue(), node.getName());
		try {
			synchronized(node) {
				trId = this.monitor.registerEvent(trId, MonitorEvent.Type.NETWORK, EVENTMSG_START_DOMUX, node, cmd);
				log.debug("Get channel on %s", node.getName());
				ch = this.getActiveChannel(node);
				Return r = new Return(Return.RET_OK,"");
				if ( !prvSess ) {
					log.debug("Open domux session on %s", node.getName());
					r = dmxp.openSession(ch, service);
				}
				if ( r.getCode() == Return.RET_OK ) {
					log.debug("Send command %s on %s", cmd.getValue(), node.getName());
					r = dmxp.sendCommand(ch, cmd, data);
					if ( !prvSess ) {
						log.debug("Close domux session on %s", node.getName());
						dmxp.closeSession(ch);
					}
				}
				if ( r.getCode() == Return.RET_OK ) {
					this.monitor.registerEvent(trId, MonitorEvent.Type.NETWORK, EVENTMSG_END_DOMUX, node, cmd);
				} else
					this.monitor.registerEvent(trId, MonitorEvent.Type.NETWORKERROR, EVENTMSG_ERROR_DOMUX, node, r);
				return r;
			}
		} catch (Exception e) {
			this.monitor.registerEvent(trId, MonitorEvent.Type.NETWORKERROR, EVENTMSG_ERROR_DOMUX, node, e);
			return new Return(DeviceManager.Error.ERR_CHANNEL_ALLOCATION,DeviceManager.Error.ERR_CHANNEL_ALLOCATION.name(),e);
		} finally {
			if ( ch != null ) {
				try {
					ch.close();
				} catch (Exception e) {
					this.monitor.registerEvent(trId, MonitorEvent.Type.NETWORKERROR, EVENTMSG_ERROR_DOMUX, node, e);
				}
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DeviceManager#defineCmdCacheable(java.lang.String, java.lang.String)
	 */
	public void defineCmdCacheable(String service, String cmd) {
		// TODO Auto-generated method stub
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.DeviceManager#identifyNode(com.domux.center.model.Node)
	 */
	public Return identifyNode(Node node) {
		Return r = this.executeDomuxProtocolCommand(node, DomuxProtocol.Service.REGISTRATION, DomuxProtocol.Command.GETREGISTRATION, null);
		if ( r.getCode() == Return.RET_OK ) {
			try {
				Configuration reg = new Configuration(r.getApplMsg());
				NodeFactory fact = new NodeFactory(this);
				Node n = fact.createNodeFromConfiguration(reg);
				if ( !node.getDxid().equals(n.getDxid()) ) {
					return new Return(Return.RET_NOTHING, null);
				}
			} catch (Exception e) {
				// TODO:
			}
		} 
		return r;
	}
	// discovery node on tcpip channel
	//
	//
	private Collection<Node> discoveryTCPIP () {
		ArrayList<Node> ret = new ArrayList<Node>();
		String[] range = DomuxTCPIP.getAddressRange(this.monitor, this.log);
		for ( int ix=0; ix<range.length; ix++ ) {
			if ( DomuxTCPIP.ping(range[ix]) ) {
				Integer trId = null;
				log.debug("creating TCP channel %s", range[ix]);
				DomuxTCPIP ch = null;
				try {
					ch = new DomuxTCPIP(range[ix]);
					Node node = this.discoveryNode(ch, trId);
					if ( node != null ) {
						node.setAddrIP(range[ix]);
						node.setLastChannel(Node.PhysicalChannel.IP);
						ret.add(node);
					}
				} catch (Exception e) {
					log.error("Error creating TCP channel %s", e, range[ix]);
				} finally {
					if ( ch != null )
						try {
							ch.close();
						} catch (Exception e ) {
							log.error("Error closing TCP channel %s", e, range[ix]);
						}
				}
			}
		}
		return ret;
	}
	// discovery node on bluetooth channel
	//
	//
	private Collection<Node> discoveryBlueTooth () {
		ArrayList<Node> ret = new ArrayList<Node>();
		DomuxBlueTooth ch = null;
		String lastUrl = null;
		try {
			String urls[] = DomuxBlueTooth.getDevicesURL(this.monitor, this.log);
			for ( String url : urls ) {
				lastUrl = url;
				Integer trId = null;
				ch = new DomuxBlueTooth(url);
				Node node = this.discoveryNode(ch, trId);
				if ( node != null ) {
					node.setAddrBT(url);
					node.setLastChannel(Node.PhysicalChannel.BT);
					ret.add(node);
				} else 
					DomuxBlueTooth.removeURL(url);
				try {
					ch.close();
				} catch (Exception e ) {
					log.error("Error closing Bluetooth channel %s", e, url);
				}
			}
		} catch (Exception e) {
			e = null;
		} finally {
			if ( ch != null )
				try {
					ch.close();
				} catch (Exception e ) {
					log.error("Error closing Bluetooth channel %s", e, lastUrl);
				}
		}
		return ret;
	}
	// discovery node on serial channel
	//
	//
	private Collection<Node> discoverySerial () {
		ArrayList<Node> ret = new ArrayList<Node>();
		DomuxSerial ch = null;
		try {
			if ( this.port != null && !this.port.isEmpty() ) {
				//Integer trId = null;
				ch = new DomuxSerial(this.port, this.initBaud);
				Node node = this.discoveryNode(ch, null);
				if ( node != null ) {
					node.setLastChannel(Node.PhysicalChannel.SERIAL);
					ret.add(node);
				}
			}
		} catch (Exception e) {
			log.error("Detect Serial port %s", e, this.port);
		} finally {
			if ( ch != null )
				try {
					ch.close();
				} catch (Exception e ) {
					log.error("Error closing Serial channel %s", e, this.port);
				}
		}
		return ret;
	}
	// discovery a single node on specific channel
	// return a new Node object creating it by factory
	//
	private Node discoveryNode(DomuxChannel ch, Integer transId) {
		try {
			log.debug("open session registration on channel %s", ch.getClass().getCanonicalName());	
			this.monitor.registerEvent(transId, MonitorEvent.Type.NETWORK, EVENTMSG_START_DISCOVERY );
			Return r = dmxp.openSession(ch, DomuxProtocol.Service.REGISTRATION);
			if ( r.getCode() == Return.RET_OK ) {
				log.debug("get registration");	
				r = dmxp.sendCommand(ch, DomuxProtocol.Command.GETREGISTRATION, null);
				if ( r.getCode() == Return.RET_OK ) {
					Configuration reg = new Configuration(r.getApplMsg());
					log.debug("open session configuration");	
					r = dmxp.openSession(ch, DomuxProtocol.Service.CONFIGURATION);
					if ( r.getCode() == Return.RET_OK ) {
						log.debug("get configuration");	
						r = dmxp.sendCommand(ch, DomuxProtocol.Command.GETCONFIG, null);
						if ( r.getCode() == Return.RET_OK ) {
							log.debug("close session and create node");	
							dmxp.closeSession(ch);
							Configuration cfg = new Configuration(r.getApplMsg()!=null?r.getApplMsg():"",reg);
							// create node
							NodeFactory fact = new NodeFactory(this);
							Node node = fact.createNodeFromConfiguration(cfg);
							if ( node != null )
								log.debug("created node %s of type %s",node.getName(), node.getType());
							else
								log.debug("fake node");	
							this.monitor.registerEvent(transId, MonitorEvent.Type.NETWORK, EVENTMSG_END_DISCOVERY);
							return node;
						}	
					}
				}
			}
			this.monitor.registerEvent(transId, MonitorEvent.Type.NETWORKERROR, EVENTMSG_ERROR_DISCOVERY, null, r);
			log.debug("error code %s, message:  %s",""+r.getCode(),r.getApplMsg());	
		} catch (Exception e) {
			log.warn("error in discovery node on channel %s", e, ch.getClass().getCanonicalName());	
		}
		return null;
	}
	//
	//
	//
	private DomuxChannel getActiveChannel(Node node) throws Exception {
		Node.PhysicalChannel[] scan = new Node.PhysicalChannel[Node.PhysicalChannel.values().length-1];
		switch ( node.getLastChannel() ) {
			case IP:
				scan[0] = Node.PhysicalChannel.IP;
				scan[1] = node.getCapabilities().hasBT()?Node.PhysicalChannel.BT:Node.PhysicalChannel.NOTHING;
				scan[2] = node.getCapabilities().hasI2C()?Node.PhysicalChannel.I2C:Node.PhysicalChannel.NOTHING;
				scan[3] = node.getCapabilities().hasSerial()?Node.PhysicalChannel.SERIAL:Node.PhysicalChannel.NOTHING;
				break;
			case BT:
				scan[0] = Node.PhysicalChannel.BT;
				scan[1] = node.getCapabilities().hasIP()?Node.PhysicalChannel.IP:Node.PhysicalChannel.NOTHING;
				scan[2] = node.getCapabilities().hasI2C()?Node.PhysicalChannel.I2C:Node.PhysicalChannel.NOTHING;
				scan[3] = node.getCapabilities().hasSerial()?Node.PhysicalChannel.SERIAL:Node.PhysicalChannel.NOTHING;
				break;
			case I2C:
				scan[0] = Node.PhysicalChannel.I2C;
				scan[1] = node.getCapabilities().hasIP()?Node.PhysicalChannel.IP:Node.PhysicalChannel.NOTHING;
				scan[2] = node.getCapabilities().hasBT()?Node.PhysicalChannel.BT:Node.PhysicalChannel.NOTHING;
				scan[3] = node.getCapabilities().hasSerial()?Node.PhysicalChannel.SERIAL:Node.PhysicalChannel.NOTHING;
				break;
			case SERIAL:
				scan[0] = Node.PhysicalChannel.SERIAL;
				scan[1] = node.getCapabilities().hasIP()?Node.PhysicalChannel.IP:Node.PhysicalChannel.NOTHING;
				scan[2] = node.getCapabilities().hasBT()?Node.PhysicalChannel.BT:Node.PhysicalChannel.NOTHING;
				scan[3] = node.getCapabilities().hasI2C()?Node.PhysicalChannel.I2C:Node.PhysicalChannel.NOTHING;
				break;
			default:
				int ix = 0;
				if ( node.getCapabilities().hasIP() )
					scan[ix++] = Node.PhysicalChannel.IP;
				if ( node.getCapabilities().hasBT() )
					scan[ix++] = Node.PhysicalChannel.BT;
				if ( node.getCapabilities().hasI2C() )
					scan[ix++] = Node.PhysicalChannel.I2C;
				if ( node.getCapabilities().hasSerial() )
					scan[ix++] = Node.PhysicalChannel.SERIAL;
				break;
		}
		Exception ex = null;
		for ( Node.PhysicalChannel pch : scan ) {
			if ( pch == null )
				continue;
			try {
				switch ( pch ) {
					case IP:
						return new DomuxTCPIP(node.getAddrIP());				
					case BT:
						return new DomuxBlueTooth(node.getAddrBT());
					case SERIAL:
						String baud = node.getBaud();
						DomuxChannel ch =  new DomuxSerial(this.port, (baud!=null&&!baud.isEmpty()?baud:"9600"));
						this.initBaud = baud;
						return ch;
					default:
						break;
				}
			} catch ( Exception e ) {
				ex = e;
			}
		}
		if ( ex != null )
			throw ex;
		return null;
	}
}
