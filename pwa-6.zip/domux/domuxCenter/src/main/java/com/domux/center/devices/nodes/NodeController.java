package com.domux.center.devices.nodes;

import com.domux.center.model.Node;
import com.domux.center.model.Resource;
import com.nandox.libraries.Configuration;
import com.nandox.libraries.Return;

/**
 * Node controller to manage and interface with node device.<br>
 * Every controller implementation known tos manage a own specific resource  
 * 
 * @project   domuxCenter
 * 
 * @module    NodeController.java
 * 
 * @date      30 mar 2019 - 30 mar 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public interface NodeController {
	/**
	 * Return the class that represent resource value
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  ResourceValue specific class
	 */
	public Class<?> getResourceValueClass();
	/**
	 * Read node's resources value from physical device to complete Resource POJO inside the node
	 * @param	  node Node to complete with resource value
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  ResourceValue specific class
	 */
	public Return readResourceValue(Node node);
	/**
	 * Set resource value to physical device
	 * @param	  node Node target
	 * @param	  res resource to write on target
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return    DomuxProtocol response
	 */
	public Return writeResourceValue(Node node, Resource res);
	/**
	 * Fill node's resources value with initial value
	 * @param	  node Node to complete with resource value
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public void fillInitialResourceValue(Node node);
	/**
	 * Create Node from configuration data.<br>
	 * Use this configuration key: DXID, NAME, NODETYPE, RESOURCE.NUM, CFG   
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  node created
	 */
	public Node createNodeFromConfiguration(Configuration cfg);
	/**
	 * Send configuration data to physical device.<br>
	 * Use old node connection data because in the new configuration it's possible that they'r changed<br>
	 * es, changing of ip address  
	 * Use this configuration key: DXID, NAME, NODETYPE, RESOURCE.NUM, CFG
	 * @param	  node node with new configuration to save   
	 * @param	  toUpdate node old connection data   
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception Exception generic to cover all specific implementation exception type<br>
	 * 			  Return to return DomuxProtocol error  
	 */
	public void sendConfigurationToDevice(Node node, Node toUpdate) throws Exception;
	/**
	 * Align configuration of destination node from source node .<br>
	 * @param	  src node source   
	 * @param	  dst node destination   
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public void alignConfiguration(Node src, Node dst);
	/**
	 * Ping node to check connection
	 * @param	  node node with new configuration to save   
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  true if connected
	 */
	public boolean ping(Node node);
}
