package com.domux.center.monitoring;

import java.util.Map;
/**
 * Define an object as monitorable and will be a possible target of one event
 * 
 * @project   domuxCenter
 * 
 * @module    Monitorable.java
 * 
 * @date      21 giu 2019 - 21 giu 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public interface Monitorable {
	/**
	 * List of key that classify and identify a monitorable event target
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	enum ClassifyKey {
		name,
		Class,
		dxid;
	}
	/**
	 * Return data to identify and classify a monitorable object
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  map with key and value as String
	 */
	public Map<ClassifyKey,String> getClassifyData();  
}
