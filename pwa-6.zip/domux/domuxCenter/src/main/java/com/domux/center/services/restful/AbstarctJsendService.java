package com.domux.center.services.restful;

import java.util.HashMap;
import java.util.Calendar;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import com.google.gson.Gson;
import com.google.gson.JsonElement;

import com.nandox.libraries.ExceptionAnalyzer;
import com.nandox.libraries.ErrorGroup;
import com.nandox.libraries.Return;
import com.domux.center.logging.BaseLogger;
import com.domux.center.model.User;
/**
 * Generic rest service controller with jsend standard data format.<br>
 * This is the responses format:
 *  	{
 *			version: '00',
 *			datetime: '2016-10-06T19:58:29Z',
 *			status: "success",
 *			authrole: here will be role name of logged user
 *			data: {...}
 *		}
 *  		
 *  	{
 *			version: '00',
 *			datetime: '2016-10-06T19:58:29Z',
 *			status: "fail",
 *			authrole: here will be role name of logged user
 *			data: {
 *					fieldname: string of error
 *		  	}
 *		}
 *
 *  	{
 *			version: '00',
 *			datetime: '2016-10-06T19:58:29Z',
 *			status: "error",
 *			authrole: here will be role name of logged user
 *			message: string,
 *			code: string
 *		}
 * 
 * @project   domuxCenter
 * 
 * @module    AbstarctJsendService.java
 * 
 * @date      01 apr 2019 - 01 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public abstract class AbstarctJsendService extends BaseLogger {
	private static final String VERSION = "1.0";
	private Gson jsonMng;

	@Autowired
	protected HttpServletRequest request;
	/**
	 * Constructor
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	protected AbstarctJsendService () {
		this.jsonMng = new Gson();
	}
	/**
	 * Convert object to json string data
	 * @param	  src	Object to convert
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json string representation of source object  
	 */
	protected String toJson(Object src) {
		return this.jsonMng.toJson(src);
	}
	/**
	 * Convert object to json element data
	 * @param	  src	Object to convert
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json element (@see com.google.gson.JsonElement) representation of source object  
	 */
	protected JsonElement toJsonTree(Object src) {
		return this.jsonMng.toJsonTree(src);
	}
	/**
	 * Convert json to object by class type
	 * @param	  src	json string to convert
	 * @param	  classOf class to use for conversion
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  a new object derived to conversion  
	 */
	protected <T> T fromJson(String src, Class<T> classOf) {
		return this.jsonMng.fromJson(src, classOf);
	}
	/**
	 * Convert json to object by class type
	 * @param	  src	JsonElement to convert
	 * @param	  classOf class to use for conversion
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  a new object derived to conversion  
	 */
	protected <T> T fromJson(JsonElement src, Class<T> classOf) {
		return this.jsonMng.fromJson(src, classOf);
	}
	/**
	 * Send success response (as Jsend format) of rest service
	 * @param	  data	data to send
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  complete json string of response ready to delivery
	 */
	protected String responseSuccess(JsonElement data) {
		HashMap<String,Object> ret = this.createResponse("success");
		ret.put("data", data);
		return this.jsonMng.toJson(ret);
	}
	/**
	 * Send fail response (as Jsend format) of rest service
	 * @param	  data	data with fields fail
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  complete json string of response ready to delivery
	 */
	protected String responseFail(JsonElement data) {
		HashMap<String,Object> ret = this.createResponse("fail");
		ret.put("data", data);
		return this.jsonMng.toJson(ret);
	}
	/**
	 * Send error response (as Jsend format) of rest service
	 * @param	  code	error code
	 * @param	  msg	error message
	 * @param	  data	optional data
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  complete json string of response ready to delivery
	 */
	protected String responseError(int code, String msg, JsonElement data) {
		HashMap<String,Object> ret = this.createResponse("error");
		ret.put("code", code);
		ret.put("message", msg);
		ret.put("data", data);
		return this.jsonMng.toJson(ret);
	}
	/**
	 * Send exception as error response (as Jsend format) of rest service.<br>
	 * Convert exception extracting the message and stack
	 * @param	  code	error code
	 * @param	  msg	error message
	 * @param	  e		Exception to convert
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  complete json string of response ready to delivery
	 */
	protected String responseError(int code, String msg, Exception e) {
		HashMap<String,String> data = new HashMap<String,String>();
		data.put("stack", ExceptionAnalyzer.getErrorStack(e, this.getClass()));
		return this.responseError(code, msg, this.toJsonTree(data));
	}
	/**
	 * Send exception as error response (as Jsend format) of rest service with unique enumerated error code.<br>
	 * Convert exception extracting the message and stack
	 * @param	  code	error code
	 * @param	  msg	error message
	 * @param	  e		Exception to convert
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  complete json string of response ready to delivery
	 */
	protected String responseError(Enum<?> code, Exception e) {
		if ( e instanceof Return )
			return this.responseError(((Return)e).getCode(),((Return)e).getApplMsg(),e);
		return this.responseError(ErrorGroup.getCode(code),""+code,e);
	}
	// create and assembly response with common fields (status, version, datetime)
	//
	//
	private HashMap<String,Object> createResponse(String status) {
		HashMap<String,Object> ret = new HashMap<String,Object>();
		ret.put("version",VERSION);
		ret.put("status", status);
		for ( int ix=0; ix<User.ACCESSROLES.length; ix++ ) {
			if ( this.request.isUserInRole(User.ACCESSROLES[ix]) ) {
				ret.put("authrole", User.ACCESSROLES[ix]);
				break;
			}
		}
		Calendar d = Calendar.getInstance();
		ret.put("datetime", String.format("%4d-%02d-%02dT%02d:%02d:%02d", 
											d.get(Calendar.YEAR), d.get(Calendar.MONTH)+1, d.get(Calendar.DAY_OF_MONTH),
											d.get(Calendar.HOUR_OF_DAY), d.get(Calendar.MINUTE), d.get(Calendar.SECOND)
										  )
				);
		return ret;
	}
}
