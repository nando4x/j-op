package com.domux.center.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

/**
 * Resource data model POJO
 * 
 * @project   domuxCenter
 * 
 * @module    Resource.java
 * 
 * @date      30 mar 2019 - 30 mar 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "id",
    "name",
    "type"
})
public class Resource implements Serializable {
	private static final long serialVersionUID = -3638017753067340178L;
	/**
	 * Type of resource
	 * @date      30 mar 2019 - 30 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public enum Type {
		/** undefined */
		UNDEF,
		/** represent a simple light */
		LIGHT,
		/** represent a simple electric plug */
		PLUG
	}
    @XmlElement(name = "id", required = true)
	private String id;
    @XmlElement(name = "name", required = true)
	private String name;
    @XmlElement(name = "type", required = true)
	private Type type;
    @XmlTransient
	private String dxid;
    @XmlTransient
    private Object value;

	public Resource() {
	}
	/**
	 * Complete constructor
	 * @param	  id	name identification
	 * @param	  type	type of resource
	 * @param	  value	value of resource, is a generic object
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public Resource(String id, Type type, Object value) {
		this.id = id;
		this.type = type;
		this.value = value;
	}
	/**
	 * Typed constructor
	 * @param	  type	type of resource
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public Resource(Type type) {
		this.type = type;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the type
	 */
	public Type getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(Type type) {
		this.type = type;
	}
	/**
	 * @return the dxid
	 */
	public String getDxid() {
		return dxid;
	}
	/**
	 * @param dxid the dxid to set
	 */
	public void setDxid(String dxid) {
		this.dxid = dxid;
	}
	/**
	 * @return the value
	 */
	public Object getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(Object value) {
		this.value = value;
	}
}
