package com.domux.center.devices.channels;

import jssc.*;

import java.util.HashMap;
import java.util.Map;

import com.domux.center.devices.DomuxChannel;
import com.domux.center.logging.BaseLogger;
import com.nandox.libraries.Return;

/**
 * Implementation of serial channel.<br>
 * The SerialPort is opened only one time and then is push in a pool connection to be reusable by other 
 * request to open the same port.
 * In case of timeout the port is closed and removed from pool
 * 
 * @project   domuxCenter
 * 
 * @module    DomuxSerial.java
 * 
 * @date      27 ago 2019 - 27 ago 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class DomuxSerial extends BaseLogger implements DomuxChannel {
	private static final int NODE_UART_BUFFLEN = 128; 
	private SerialPortConnection serial;
  	private int baud;
  	private int databits;
  	private int stopbits;
  	private int timeout;
	private static Map<String,SerialPortConnection> connPool = new HashMap<String,SerialPortConnection>();

	/**
	 * Constructor
	 * @param	  port serial port to use
	 * @param	  baud serial port baudrate speed
	 * @date      16 apr 2019 - 16 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception Exception generic to cover all java.net.Socket exception type<br>
	 */
	public DomuxSerial(String port, String baud) throws Exception {
		this.timeout = 15000;
		int bdr = Integer.valueOf(baud);
		if ( connPool.get(port) == null || !connPool.get(port).isOpened() ) {
			log.debug("Serial open %s with %s", port, baud);
			this.serial = new SerialPortConnection(port, bdr);
			this.baud = bdr;
			this.databits = SerialPort.DATABITS_8;
			this.stopbits = SerialPort.STOPBITS_1;
			this.serial.openPort();
			this.serial.setParams(this.baud,this.databits,this.stopbits,SerialPort.PARITY_NONE);
			this.serial.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);
			this.serial.purgePort(SerialPort.PURGE_RXCLEAR | SerialPort.PURGE_TXCLEAR);
			Thread.sleep(10000); // wait the device reset
			connPool.put(port, this.serial);
		} else {
			this.serial = connPool.get(port);
			if ( this.serial.baud != bdr ) {
				this.serial.closePort();
				this.baud = bdr;
				this.databits = SerialPort.DATABITS_8;
				this.stopbits = SerialPort.STOPBITS_1;
				this.serial.openPort();
				this.serial.setParams(this.baud,this.databits,this.stopbits,SerialPort.PARITY_NONE);
				this.serial.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);
				this.serial.purgePort(SerialPort.PURGE_RXCLEAR | SerialPort.PURGE_TXCLEAR);
				Thread.sleep(10000); // wait the device reset
			}
		}
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#readData()
	 */
	public Return readData() throws Exception {
		String data = "";
		if ( this.serial != null )	{
			while (true) {
				try {
					int buf;
					buf = this.serial.readBytes(1,this.timeout)[0];
					if ( buf == '\n' )
						continue;
					if ( buf == '\r' ) {
						log.debug("Serial receive: %s", data.replace("\n","").replace("\r",""));
						return new Return(Return.RET_OK,data);
					}
					data += (char)buf;
				} catch (SerialPortTimeoutException e) {
					this.serial.closePort();
					connPool.remove(this.serial.getPortName());
					throw new Return(-1010,e.getMessage());
				} catch (Exception e) {
					throw new Return(-1011,e.getMessage());
				}
			}
		}
		throw new Return(-1012,null);
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#writeData(java.lang.String)
	 */
	public Return writeData(String data) throws Exception {
		if ( this.serial != null )
		{
			//byte buff[] = data.getBytes();
			int len = data.length();
			int inx = 0;
			while ( len > NODE_UART_BUFFLEN ) {
				this.serial.writeBytes(data.substring(inx, inx+NODE_UART_BUFFLEN).getBytes());
				len -= NODE_UART_BUFFLEN;
				inx += NODE_UART_BUFFLEN;
				Thread.sleep(10);
			}
			this.serial.writeBytes(data.substring(inx, inx+len).getBytes());
			log.debug("Serial send: %s", data.replace("\n","").replace("\r",""));
			return new Return(Return.RET_OK,null);
		}
		throw new Return(-1013,null);
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#hasCRC()
	 */
	public boolean hasCRC() {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#close()
	 */
	public void close() throws Exception {
		//this.serial.closePort();
	}
	
	private static class SerialPortConnection extends SerialPort {
		protected int baud;
		public SerialPortConnection(String portName, int baud) {
			super(portName);
			this.baud = baud;;
		}
	}
}
