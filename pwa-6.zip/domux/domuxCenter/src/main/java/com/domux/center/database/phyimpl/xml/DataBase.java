
package com.domux.center.database.phyimpl.xml;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.domux.center.model.Node;
import com.nandox.tomcatext.JAASUserDatabase.User;
import com.domux.center.model.MapItem;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Components">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Nodes">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Node" maxOccurs="unbounded">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="addrBT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="addrI2C" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="addrIP" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="Capabilities">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="BT" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *                                                 &lt;element name="I2C" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *                                                 &lt;element name="IP" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                       &lt;element name="Resource" maxOccurs="unbounded">
 *                                         &lt;complexType>
 *                                           &lt;complexContent>
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                               &lt;sequence>
 *                                                 &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                                 &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                               &lt;/sequence>
 *                                             &lt;/restriction>
 *                                           &lt;/complexContent>
 *                                         &lt;/complexType>
 *                                       &lt;/element>
 *                                     &lt;/sequence>
 *                                     &lt;attribute name="dxid" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Map">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Resource" maxOccurs="unbounded">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="x" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
 *                             &lt;element name="y" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "components",
    "map",
    "users",
    "idGenerator"
})
@XmlRootElement(name = "DataBase")
public class DataBase {

    @XmlElement(name = "Components", required = true)
    protected DataBase.Components components;
    @XmlElement(name = "Map", required = true)
    protected DataBase.Map map;
    @XmlElement(name = "Users", required = true)
    protected DataBase.Users users;
    @XmlElement(name = "idGenerator", required = true)
    protected int idGenerator;

    /**
     * Gets the value of the components property.
     * 
     * @return
     *     possible object is
     *     {@link DataBase.Components }
     *     
     */
    public DataBase.Components getComponents() {
        return components;
    }

    /**
     * Sets the value of the components property.
     * 
     * @param value
     *     allowed object is
     *     {@link DataBase.Components }
     *     
     */
    public void setComponents(DataBase.Components value) {
        this.components = value;
    }

    /**
     * Gets the value of the map property.
     * 
     * @return
     *     possible object is
     *     {@link DataBase.Map }
     *     
     */
    public DataBase.Map getMap() {
        return map;
    }

    /**
     * Sets the value of the map property.
     * 
     * @param value
     *     allowed object is
     *     {@link DataBase.Map }
     *     
     */
    public void setMap(DataBase.Map value) {
        this.map = value;
    }


    /**
	 * @return the users
	 */
	public DataBase.Users getUsers() {
		return users;
	}

	/**
	 * @param users the users to set
	 */
	public void setUsers(DataBase.Users users) {
		this.users = users;
	}

	/**
     * Gets the value of the idGenerator property.
     * 
     * @return int
     *     
     *     
     */
    public int getIdGenerator() {
        return idGenerator;
    }

    /**
     * Sets the value of the idGenerator property.
     * 
     * @param value
     *     
     *     
     */
    public void IdGenerator(int value) {
        this.idGenerator = value;
    }
    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Nodes">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Node" maxOccurs="unbounded">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="addrBT" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="addrI2C" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="addrIP" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="Capabilities">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="BT" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
     *                                       &lt;element name="I2C" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
     *                                       &lt;element name="IP" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                             &lt;element name="Resource" maxOccurs="unbounded">
     *                               &lt;complexType>
     *                                 &lt;complexContent>
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                                     &lt;sequence>
     *                                       &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                       &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                                     &lt;/sequence>
     *                                   &lt;/restriction>
     *                                 &lt;/complexContent>
     *                               &lt;/complexType>
     *                             &lt;/element>
     *                           &lt;/sequence>
     *                           &lt;attribute name="dxid" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "nodes"
    })
    public static class Components {

        @XmlElement(name = "Nodes", required = true)
        protected DataBase.Components.Nodes nodes;

        /**
         * Gets the value of the nodes property.
         * 
         * @return
         *     possible object is
         *     {@link DataBase.Components.Nodes }
         *     
         */
        public DataBase.Components.Nodes getNodes() {
            return nodes;
        }

        /**
         * Sets the value of the nodes property.
         * 
         * @param value
         *     allowed object is
         *     {@link DataBase.Components.Nodes }
         *     
         */
        public void setNodes(DataBase.Components.Nodes value) {
            this.nodes = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Node" maxOccurs="unbounded">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="addrBT" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="addrI2C" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="addrIP" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="Capabilities">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="BT" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
         *                             &lt;element name="I2C" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
         *                             &lt;element name="IP" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                   &lt;element name="Resource" maxOccurs="unbounded">
         *                     &lt;complexType>
         *                       &lt;complexContent>
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                           &lt;sequence>
         *                             &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                             &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                           &lt;/sequence>
         *                         &lt;/restriction>
         *                       &lt;/complexContent>
         *                     &lt;/complexType>
         *                   &lt;/element>
         *                 &lt;/sequence>
         *                 &lt;attribute name="dxid" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "node"
        })
        public static class Nodes {

            @XmlElement(name = "Node", required = true)
            protected List<Node> node;

            /**
             * Gets the value of the node property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the node property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getNode().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link DataBase.Components.Nodes.Node }
             * 
             * 
             */
            public List<Node> getNode() {
                if (node == null) {
                    node = new ArrayList<Node>();
                }
                return this.node;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="addrBT" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="addrI2C" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="addrIP" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="Capabilities">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="BT" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
             *                   &lt;element name="I2C" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
             *                   &lt;element name="IP" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *         &lt;element name="Resource" maxOccurs="unbounded">
             *           &lt;complexType>
             *             &lt;complexContent>
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *                 &lt;sequence>
             *                   &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                   &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *                 &lt;/sequence>
             *               &lt;/restriction>
             *             &lt;/complexContent>
             *           &lt;/complexType>
             *         &lt;/element>
             *       &lt;/sequence>
             *       &lt;attribute name="dxid" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Resource" maxOccurs="unbounded">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="x" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
     *                   &lt;element name="y" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
    	"imageData",
    	"imageWidth",
    	"imageHeight",
        "resource"
    })
    public static class Map {

        @XmlElement(name = "imageData")
        protected String imageData;
        @XmlElement(name = "imageWidth")
        protected int imageWidth;
        @XmlElement(name = "imageHeight")
        protected int imageHeight;
        @XmlElement(name = "Resource", required = true)
        protected List<MapItem> resource;

        public String getImageData() {
        	return this.imageData;
        }
        /**
		 * @return the image_width
		 */
		public int getImageWidth() {
			return imageWidth;
		}
		/**
		 * @param image_width the image_width to set
		 */
		public void setImageWidth(int image_width) {
			this.imageWidth = image_width;
		}
		/**
		 * @return the image_height
		 */
		public int getImageHeight() {
			return imageHeight;
		}
		/**
		 * @param image_height the image_height to set
		 */
		public void setImageHeight(int image_height) {
			this.imageHeight = image_height;
		}
		/**
		 * @param image the image to set
		 */
		public void setImageData(String image) {
			this.imageData = image;
		}
		/**
         * Gets the value of the resource property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the resource property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getResource().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DataBase.Map.Resource }
         * 
         * 
         */
        public List<MapItem> getResource() {
            if (resource == null) {
                resource = new ArrayList<MapItem>();
            }
            return this.resource;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="x" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
         *         &lt;element name="y" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "dxid",
            "x",
            "y"
        })
        public static class Resource {

            @XmlElement(required = true)
            protected String dxid;
            @XmlSchemaType(name = "unsignedByte")
            protected short x;
            @XmlSchemaType(name = "unsignedByte")
            protected short y;

            /**
             * Gets the value of the dxid property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDxid() {
                return dxid;
            }

            /**
             * Sets the value of the dxid property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setId(String value) {
                this.dxid = value;
            }

            /**
             * Gets the value of the x property.
             * 
             */
            public short getX() {
                return x;
            }

            /**
             * Sets the value of the x property.
             * 
             */
            public void setX(short value) {
                this.x = value;
            }

            /**
             * Gets the value of the y property.
             * 
             */
            public short getY() {
                return y;
            }

            /**
             * Sets the value of the y property.
             * 
             */
            public void setY(short value) {
                this.y = value;
            }
        }
    }
    
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "user"
    })
    public static class Users {
        @XmlElement(name = "User", required = true)
        protected List<User> user;

        public List<User> getUser() {
            if (this.user == null) {
            	this.user = new ArrayList<User>();
            }
            return this.user;
        }
    }
}
