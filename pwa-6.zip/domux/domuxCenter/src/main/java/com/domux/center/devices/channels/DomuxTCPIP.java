package com.domux.center.devices.channels;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Arrays;
import java.io.InputStream;
import java.net.Socket;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import org.apache.commons.net.util.SubnetUtils;
import com.domux.center.devices.DomuxChannel;
import com.domux.center.logging.BaseLogger;
import com.domux.center.monitoring.MonitorEvent;
import com.nandox.libraries.Return;
import com.nandox.libraries.logging.Logger;

/**
 * Implementation of network tcpip channel.<br>
 * The channel is specific for a single ip address and use port 10201.
 * This channel don't use CRC checking  
 * 
 * @project   domuxCenter
 * 
 * @module    DomuxTCPIP.java
 * 
 * @date      16 apr 2019 - 16 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class DomuxTCPIP extends BaseLogger implements DomuxChannel {
	/** Domux protocol TCP port */
	public static final int PORT = 10201;
	private Socket sock;
	private static final int TIMEOUT = 20000;
	
	/**
	 * Constructor
	 * @param	  ipAddr tcpip address of node
	 * @date      16 apr 2019 - 16 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception Exception generic to cover all java.net.Socket exception type<br>
	 */
	public DomuxTCPIP(String ipAddr) throws Exception {
		this.sock = new Socket(ipAddr,PORT);
		this.sock.setSoTimeout(TIMEOUT);
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#readData()
	 */
	public Return readData() throws Exception {
		InputStream in = this.sock.getInputStream();
		byte[] chr = new byte[1];
		String data = "";
		while ( in.read(chr) > 0 ) {
			if ( (char)chr[0] == '\n' )
				continue;
			if ( (char)chr[0] == '\r' )
				return new Return(Return.RET_OK,data);
			data += (char)chr[0];
		}
		return new Return(Return.RET_NOTHING,null);
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#writeData(java.lang.String)
	 */
	public Return writeData(String data) throws Exception {
		this.sock.getOutputStream().write(data.getBytes());
		log.debug("TCPIP send: %s", data.replace("\n","").replace("\r",""));
		return new Return(Return.RET_NOTHING,null);
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#hasCRC()
	 */
	public boolean hasCRC() {
		return false;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.DomuxChannel#close()
	 */
	public void close() throws Exception {
		this.sock.close();
	}

	/**
	 * Utility to get all ip addresses range for current host
	 * @param	  monitor	event monitor to use
	 * @param	  log	logger to use
	 * @date      16 apr 2019 - 16 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  array of a standard IPV4 ip address as string (x.x.x.x) 
	 */
	public static String[] getAddressRange (MonitorEvent monitor, Logger log) {
		HashSet<String> range = new HashSet<String>();
		try {
			Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
			while ( nets.hasMoreElements() ) {
				NetworkInterface n = nets.nextElement();
				log.debug("detect TCP interface %s, %s, isUp: %s", n.getName(), n.getDisplayName(), ""+n.isUp() );
				if ( !n.isUp() )
					continue;
				boolean skip = false;// = true;
				for ( InterfaceAddress net : n.getInterfaceAddresses() ) {
					if ( !skip && !net.getAddress().isLoopbackAddress() && net.getAddress().getAddress().length == 4 ) {
						try {
							log.debug("register TCP interface address %s", net.toString());
							int len = net.getNetworkPrefixLength();
							SubnetUtils s = new SubnetUtils(net.getAddress().getHostAddress()+"/"+len);
							range.addAll(Arrays.asList(s.getInfo().getAllAddresses()));
						} catch ( Exception e ) {
							log.debug("ERROR registering TCP interface address %s", net.toString());
						}
					} else {
						range.add("127.0.0.1");
					}
				}
			}
		} catch (Exception e) {
			monitor.registerEvent(null, MonitorEvent.Type.SYSERROR, "detect TCP interface error");
			log.error("Detect TCP interface error", e);
		}
		return range.toArray(new String[0]);
	}
	/**
	 * Utility to ping a specific ipaddr on Domux tcpip port
	 * @param	  ipAddr tcpip address
	 * @date      16 apr 2019 - 16 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  true if port is active
	 */
	public static boolean ping(String ipAddr) {
		Socket sock = new Socket();
		try {
			SocketAddress socketAddress = new InetSocketAddress(ipAddr, PORT);  
			sock.connect(socketAddress, 10);
			sock.close();
			return true;
		} catch (Exception e) {}
		return false;
	}
}
