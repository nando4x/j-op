package com.domux.center.devices.nodes;

import java.util.Arrays;

import com.domux.center.devices.DeviceManager;
import com.domux.center.devices.DomuxProtocol;
import com.domux.center.model.Node;
import com.domux.center.model.Resource;
import com.nandox.libraries.Configuration;
import com.nandox.libraries.ErrorGroup;
import com.nandox.libraries.Return;

/**
 * General node controller for manage all common operations:<br>
 * read and save configuration
 * 
 * @project   domuxCenter
 * 
 * @module    AbstractNode.java
 * 
 * @date      12 apr 2019 - 12 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public abstract class AbstractNode {
	protected final DeviceManager devman;

	/**
	 * Constructor
	 * @param	  devman	device manager to use for communicate with physical node device
	 * @date      12 apr 2019 - 12 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	protected AbstractNode(DeviceManager devman) {
		this.devman = devman;
	}
	/**
	 * Create Node from configuration data.<br>
	 * Use this configuration key: DXID, NAME, NODETYPE, RESOURCE.NUM, IP.ADDR, I2C.ADDR, BT.ADDR.<br>
	 * Set status as UNREGISTERED   
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  Node created
	 */
	protected Node buildNodeFromConfiguration(Configuration cfg) {
		Node n = new Node();
		n.setDxid(cfg.getStringValue("DXID", ""));
		n.setType(cfg.getStringValue("NODETYPE", ""));
		n.setName(cfg.getStringValue("NAME", ""));
		n.setStatus(Node.Status.UNREGISTERED);
		String ip = cfg.getStringValue("IP.ADDR");
		String i2c = cfg.getStringValue("I2C.ADDR");
		String bt = cfg.getStringValue("BT.ADDR");
		String baud = cfg.getStringValue("BAUD");
		n.setCapabilities(new Node.Capabilities(bt!=null,i2c!=null,ip!=null,baud!=null));
		if ( bt != null )
			n.setAddrBT(bt);
		if ( i2c != null )
			n.setAddrI2C(i2c);
		if ( ip != null )
			n.setAddrIP(ip);
		if ( baud != null )
			n.setBaud(baud);
		try {
			Resource[] rs = new Resource[cfg.getIntValue("RESOURCES.NUM", 0)];
			for ( int ix=0; ix<rs.length; ix++ ) {
				rs[ix] = new Resource();
				rs[ix].setId("res"+(ix+1));
				rs[ix].setDxid(n.getDxid()+"."+rs[ix].getId());
				rs[ix].setName(rs[ix].getId());
				rs[ix].setType(Resource.Type.UNDEF);
			}
			n.setResourceList(Arrays.asList(rs));
		} catch (Exception e){}
		return n;
	}
	/**
	 * Create configuration data from Node.<br>
	 * @param	  node Node from read data
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  Configuration data
	 */
	protected Configuration buildConfigurationFromNode(Node node) {
		Configuration cfg = new Configuration();
		cfg.setStringValue("NAME", node.getName());
		if ( node.getCapabilities().hasI2C() )
			cfg.setStringValue("I2C.ADDR", node.getAddrI2C());
		if ( node.getCapabilities().hasIP() )
			cfg.setStringValue("IP.ADDR", node.getAddrIP());
		if ( node.getCapabilities().hasSerial() )
			cfg.setStringValue("BAUD", node.getBaud());
		for ( Resource r : node.getResourceList() ) {
			cfg.setStringValue(r.getId()+".NAME", r.getName());
			cfg.setStringValue(r.getId()+".TYPE", r.getType().name());
		}
		return cfg;
	}
	/**
	 * standard .<br>
	 * @param	  node Node from read data
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  Confiugration data
	 * @exception Exception generic to cover all exception type<br>
	 * 			  Return to return Domux protocol error
	 */
	protected void sendConfigurationToDomux(Node node, Node toUpdate) throws Exception {
		String cfg = this.buildConfigurationFromNode(node).toString();
		Return r = this.devman.executeDomuxProtocolCommand(toUpdate, 
											    DomuxProtocol.Service.CONFIGURATION, DomuxProtocol.Command.SETCONFIG, 
											    cfg.replace("\n", "\r\n"));
		if ( r.getCode() < Return.RET_NOTHING )
			throw r;
	}
	/**
	 * Ping one node.
	 * @param	  node Node from read data
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  true if connected
	 */
	protected boolean sendPing(Node node) {
		Return r = this.devman.executeDomuxProtocolCommand(node, DomuxProtocol.Service.REGISTRATION, DomuxProtocol.Command.PING, "");
		if ( r.getCode() == ErrorGroup.getCode(DeviceManager.Error.ERR_CHANNEL_ALLOCATION) )
			return false;
		return true;
	}
}
