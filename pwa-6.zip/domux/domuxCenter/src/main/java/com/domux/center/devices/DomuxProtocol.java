package com.domux.center.devices;

import com.nandox.libraries.ErrorGroup;
import com.nandox.libraries.ErrorGroupMarker;
import com.nandox.libraries.Return;

/**
 * Manage the domux protocol commands, every commands is grouped by service that have to be open by command
 * STARTSESSION or SS.
 * The domux protocol is a ASCII protocol, every commands terminate with CR char,<br> 
 * this is the commands list    
 *  - SERVICE -            - COMAMAND -               - RESPONSE -
 *    I2C                    CHGADDR xx                 OK/ERROR xxx
 *    CFG                    SETCFG  datastring         OK/ERROR xxx
 *    CFG                    GETCFG						datastring/ERROR xxx
 *    REG					 GETREG  					datastring/ERROR xxx
 * 
 * @project   domuxCenter
 * 
 * @module    DomuxProtocol.java
 * 
 * @date      12 apr 2019 - 12 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class DomuxProtocol {
	/**
	 * List of Domux protocol errors
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	@ErrorGroupMarker(-1000)
	public enum Error {
		/** Error code CRC non verified */
		ERR_CRC,
		/** Error code connection broken */
		ERR_CONNECTION,
		/** Error malformed response */
		ERR_MALFORMED,
		/** Error on network I/O */
		ERR_IONETWORK
	}
	/**
	 * List of Domux protocol Services, value attribute is used a real protocol command  
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	public enum Service {
		/** registration service */
		REGISTRATION("REG"),
		/** configuration service */
		CONFIGURATION("CFG"),
		/** relay node service */
		RELAY("RELAY");
		
		Service(String value) {
			this.value = value;
		}
		private final String value;
		/**
		 * @return the value
		 */
		public String getValue() {
			return value;
		}
	}
	/**
	 * List of Domux protocol Commands, value attribute is used a real protocol command
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	public enum Command {
		/** starts a service session */
		STARTSESSION("STARTSESSION"),
		/** end active session */
		ENDSESSION("ENDSESSION"),
		/** request registration data */
		GETREGISTRATION("GETREG"),
		/** request all configuration data */
		GETCONFIG("GETCFG"),
		/** save all configuration data */
		SETCONFIG("SETCFG"),
		/** send a single configuration key */
		BLKCONFIG("BLKCFG"),
		/** write previous configuration keys sent */
		WRITECONFIG("WRCFG"),
		/** ping to verify connection */
		PING("PING"),
		/** read resources */
		READ("READ"),
		/** fire a resource */
		FIRE("FIRE");
		
		Command(String value) {
			this.value = value;
		}
		private final String value;
		/**
		 * @return the value
		 */
		public String getValue() {
			return value;
		}
	}
	/**
	 * Open session for a specific Domux service
	 * @param	  ch	channel to communication
	 * @param	  serv 	domux service
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  code RET_OK if success or a specific error code if fail. Error can be a protocol returned error<br>
	 * 			  or a DomuxProtocol.Error 
	 */
	public Return openSession(DomuxChannel ch, Service serv ) {
		Return r = this.sendCommand(ch, Command.STARTSESSION, serv.value);
		return r;
	}
	/**
	 * close active session
	 * @param	  ch	channel to communication
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  code RET_OK if success or a specific error code if fail. Error can be a protocol returned error<br>
	 * 			  or a DomuxProtocol.Error 
	 */
	public Return closeSession(DomuxChannel ch) {
		Return r = this.sendCommand(ch, Command.ENDSESSION, null);
		return r;
	}
	/**
	 * Send command to channel for active session
	 * @param	  ch	channel to communication
	 * @param	  cmd 	domux command
	 * @param	  data 	optional data of command
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  can return code RET_OK and relative data if success or a specific error code if fail.
	 * 			  Error can be a protocol returned error<br> or a DomuxProtocol.Error  
	 */
	public Return sendCommand(DomuxChannel ch, Command cmd, String data) {
		Return r;
		int cnt = 1;
		String dcmd = cmd.value + (data!=null&&!data.isEmpty()?" "+data:""); 
		// converte CR e LF
		dcmd = dcmd.replaceAll("\r\n","\\^\\^");
		// aggiunge Checksum
		if ( ch.hasCRC() ) {
			short chs = this.computeCKS(dcmd);
			dcmd += String.format("%04X", chs);
		}
		boolean c_crc;
		try {
			ch.writeData(dcmd+"\n\r");
			r = ch.readData();
			c_crc = (ch.hasCRC()?this.checkCKS(r.getApplMsg()):true);
			while ( (!c_crc || r.getCode() <= 0 || (r.getCode() > 0 && r.getApplMsg().toUpperCase().startsWith("ERROR"))) && cnt < 3) {
				ch.writeData(dcmd+"\n\r");
				r = ch.readData();
				//c_crc = this.checkCKS(r.ApplMsg);
				cnt++;
			}
		} catch ( Exception e ) {
			return new Return(Error.ERR_IONETWORK,Error.ERR_IONETWORK.name(),e);
		}
		if ( r.getCode() == Return.RET_NOTHING)
			r = new Return(Error.ERR_CONNECTION,Error.ERR_CONNECTION.name());
		if ( !c_crc )
			r = new Return(Error.ERR_CRC,Error.ERR_CRC.name());
		return this.parseResponse(r.getApplMsg()!=null?r.getApplMsg().replaceAll("\\^\\^", "\r\n"):null, r.getCode());
	}
	// Parse domux response message and get application message.<br>
	// If response OK return data after OK string, if ERROR return  message into ()
	//
	private Return parseResponse(String resp, int code) {
		if ( resp != null && resp.toUpperCase().startsWith("ERROR") ) {
			int s = resp.indexOf("(");
			int e = resp.lastIndexOf(")");
			try {
				return new Return(Integer.parseInt(resp.substring(s+1, e-1).trim())*-1,resp.substring(6).trim());
			} catch ( Exception ex ) {
				return new Return(ErrorGroup.getCode(Error.ERR_MALFORMED),resp);
			}
		} else if ( !resp.toUpperCase().startsWith("OK") )
			return new Return(ErrorGroup.getCode(Error.ERR_MALFORMED),resp);
		return new Return(Return.RET_OK,resp!=null&&resp.length()>2?resp.substring(2).trim():null);
	}
	// check CRC CheckSum
	//
	//
	private boolean checkCKS(String Data) { 
		try {
			int c = Integer.valueOf(Data.substring(Data.length()-4), 16);
			int x = this.computeCKS(Data.substring(0, Data.length()-4));
			if ( c == x )
				return true;
		} catch ( Exception e ) {}
		return false;
	}
	// Compute CRC CheckSum
	//
	//
	private short computeCKS(String data) {
		short chk = 0;
		for ( int ix=0; data != null && ix<data.length(); ix++ ) {
			chk += data.charAt(ix)*ix;
		}
		return chk;
	}
}
