package com.domux.center.model;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.nandox.libraries.validation.BeanValidable;

/**
 * User data model POJO
 * 
 * @project   domuxCenter
 * 
 * @module    Node.java
 * 
 * @date      30 mar 2019 - 30 mar 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public class User extends BeanValidable  {
	/** list of possible role */
	public static final String ACCESSROLES[] = {"domuxAdmin","domuxManager","domuxUser"};
	
	private Integer id;				// user unique identifier
	@NotNull(message="ERROR_FIELD_USER_NAME_LEN")
	@Size(min=1, max=32, message="ERROR_FIELD_USER_NAME_LEN")
	private String name;			// user name
	@NotNull(message="ERROR_FIELD_USER_PASSWORD_LEN")
	@Size(min=1, max=32, message="ERROR_FIELD_USER_PASSWORD_LEN")
	private String password;		// user password
	@NotNull(message="ERROR_FIELD_ROLE_PASSWORD_LEN")
	@Size(min=1, max=32, message="ERROR_FIELD_ROLE_PASSWORD_LEN")
	private String role;			// user role
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/* (non-Javadoc)
	 * @see com.nandox.libraries.validation.BeanValidable#validate(Class<?>...args)
	 */
	@Override
	public Map<String, String> validate(Class<?>...args) {
		Map<String,String> ret = new HashMap<String,String>();
		if ( this.getRole() == null || Arrays.binarySearch(ACCESSROLES, this.getRole()) < 0 )
			ret.put("role", "ERROR_FIELD_USER_ROLE");
		ret.putAll(super.validate());
		return ret;
	}
}
