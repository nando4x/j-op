package com.domux.center;

public class Labels {
	private Labels() {
	    throw new IllegalStateException("Utility class");
	}
	public static final String ERROR_FIELD_NODE_DUPLICATED = "Esiste gi� un nodo con questo identificativo";
	public static final String ERROR_FIELD_RESOURCE_DUPLICATED = "Esistono due risorse identiche";
	public static final String ERROR_FIELD_RESOURCE_NOTFOUND = "Risorsa non trovata";
	public static final String ERROR_NODE_NOTFOUND = "Nodo non trovato";
	public static final String ERROR_NODE_NOTDELETABLE = "Nodo non cancellabile";
}
