package com.nandox.libraries.logging.log4j2;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.spi.AbstractLogger;
import org.apache.logging.log4j.spi.ExtendedLoggerWrapper;
import com.nandox.libraries.logging.Logger;

/**
 * Log4J implementation of Generic logger.<br>
 * Use log4j wrapper to redifine FQCN
 * 
 * @project   Libraries (Global libraries)
 * 
 * @module    Log4j2Logger.java
 * 
 * @date      19 set 2016 - 19 set 2016
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public class Log4j2Logger extends ExtendedLoggerWrapper implements Logger {
    private static final long serialVersionUID = 575298311063777L;

    private static final String FQCN = Log4j2Logger.class.getName();
	private ExtendedLoggerWrapper log;

	public Log4j2Logger(org.apache.logging.log4j.Logger logger) {
        super((AbstractLogger) logger, logger.getName(), logger.getMessageFactory());
	    this.log = this;
	}

    public static Log4j2Logger create(final Class<?> loggerName) {
        final org.apache.logging.log4j.Logger wrapped = LogManager.getLogger(loggerName);
        return new Log4j2Logger(wrapped);
    }
	
	public void error(String msg, String... args) {
		log.logIfEnabled(FQCN,Level.ERROR,null,Logger.Utils.format(msg, args));
	}
	
	public void error(String msg, Object... args) {
		log.logIfEnabled(FQCN,Level.ERROR,null,Logger.Utils.format(msg, args));
	}
	
	public void error(String msg, Throwable ex, String... args) {
		log.logIfEnabled(FQCN,Level.ERROR,null,Logger.Utils.format(msg, args), ex);
	}
	
	public void info(String msg, String... args) {
	    log.logIfEnabled(FQCN,Level.INFO,null,Logger.Utils.format(msg, args));
	}
	
	public void info(String msg, Throwable ex, String... args) {
		log.logIfEnabled(FQCN,Level.INFO,null,Logger.Utils.format(msg, args), ex);
	}
	
	public boolean isInfoEnabled() {
	    return log.isInfoEnabled();
	}
	
	public void warn(String msg, String... args) {
		log.logIfEnabled(FQCN,Level.WARN,null,Logger.Utils.format(msg, args));
	}
	
	public void warn(String msg, Object... args) {
		log.logIfEnabled(FQCN,Level.WARN,null,Logger.Utils.format(msg, args));
	}
	
	public void warn(String msg, Throwable ex, String... args) {
		log.logIfEnabled(FQCN,Level.WARN,null,Logger.Utils.format(msg, args), ex);
	}
	
	public boolean isDebugEnabled() {
	    return log.isDebugEnabled();
	}
	
	public void debug(String msg, String... args) {
		log.logIfEnabled(FQCN,Level.DEBUG,null,Logger.Utils.format(msg, args));
	}
	
	public void debug(String msg, Object... args) {
		log.logIfEnabled(FQCN,Level.DEBUG,null,Logger.Utils.format(msg, args));
	}
	
	public void debug(String msg, Throwable ex, String... args) {
		log.logIfEnabled(FQCN,Level.DEBUG,null,Logger.Utils.format(msg, args), ex);
	}
	
	public boolean isTraceEnabled() {
	    return log.isTraceEnabled();
	}
	
	public void trace(String msg, String... args) {
		log.logIfEnabled(FQCN,Level.TRACE,null,Logger.Utils.format(msg, args));
	}
	
	public void trace(String msg, Object... args) {
		log.logIfEnabled(FQCN,Level.TRACE,null,Logger.Utils.format(msg, args));
	}
	
	public void trace(String msg, Throwable ex, String... args) {
		log.logIfEnabled(FQCN,Level.TRACE,null,Logger.Utils.format(msg, args), ex);
	}
		
	public void fatal(String msg, String... args) {
		log.logIfEnabled(FQCN,Level.FATAL,null,Logger.Utils.format(msg, args));
	}
	
	public void fatal(String msg, Throwable ex, String... args) {
		log.logIfEnabled(FQCN,Level.FATAL,null,Logger.Utils.format(msg, args), ex);
	}
	
	public boolean isErrorEnabled() {
	    return log.isErrorEnabled();
	}
	
	public boolean isFatalEnabled() {
	    return log.isFatalEnabled();
	}
	
	public boolean isWarnEnabled() {
	    return log.isWarnEnabled();
	}
}
