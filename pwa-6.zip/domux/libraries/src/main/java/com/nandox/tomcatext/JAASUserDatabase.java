package com.nandox.tomcatext;

import java.util.Map;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;

/**
 * Descrizione classe
 * 
 * @project   domuxCenter
 * 
 * @module    JAASUserDatabase.java
 * 
 * @date      23 set 2019 - 23 set 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class JAASUserDatabase implements LoginModule {

	private CallbackHandler handler;
	private Subject subject;
	private JAASUser user;
	private List<JAASRole> roles;
	private AccessValidator validator;

	/* (non-Javadoc)
	 * @see javax.security.auth.spi.LoginModule#abort()
	 */
	public boolean abort() throws LoginException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see javax.security.auth.spi.LoginModule#commit()
	 */
	public boolean commit() throws LoginException {
		subject.getPrincipals().add(user);
	    subject.getPrincipals().addAll(roles);
	    return true;
	}

	/* (non-Javadoc)
	 * @see javax.security.auth.spi.LoginModule#initialize(javax.security.auth.Subject, javax.security.auth.callback.CallbackHandler, java.util.Map, java.util.Map)
	 */
	public void initialize(Subject subject, CallbackHandler callbackHandler, Map<String, ?> sharedState, Map<String, ?> options) {
		if ( options.get("validatorclass") != null ) {
			String clazz = (String)options.get("validatorclass");
			//this.getClass().getClassLoader().loadClass(clazz);
		}
		this.handler = callbackHandler;
	    this.subject = subject;
	}

	/* (non-Javadoc)
	 * @see javax.security.auth.spi.LoginModule#login()
	 */
	public boolean login() throws LoginException {
	    Callback[] callbacks = new Callback[2];
	    callbacks[0] = new NameCallback("login");
	    callbacks[1] = new PasswordCallback("password", true);

	    try {
	      handler.handle(callbacks);
	      String username = ((NameCallback) callbacks[0]).getName();
	      String password = String.valueOf(((PasswordCallback) callbacks[1]).getPassword());

	      
	      if ("admin".equalsIgnoreCase(username) && "password".equals(password)) {
	        user = new JAASUser(username);
	        roles = new ArrayList<JAASRole>();
	        roles.add(new JAASRole("admin"));
	        return true;
	      }

	      throw new FailedLoginException("Authentication failed");
	    }
	    catch (IOException ex) {
	      throw new LoginException(ex.getMessage());
	    }
	    catch (UnsupportedCallbackException ex) {
		      throw new LoginException(ex.getMessage());
		    }
	}

	/* (non-Javadoc)
	 * @see javax.security.auth.spi.LoginModule#logout()
	 */
	public boolean logout() throws LoginException {
		subject.getPrincipals().remove(user);
	    subject.getPrincipals().removeAll(roles);
	    return true;
	}
	
	public static interface AccessValidator {
		public boolean checkCredentials(String username, String password);
	}
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class User {
		@XmlAttribute(name = "id", required = true)
		private Integer id;					// user unique identifier
		@XmlAttribute(name = "name", required = true)
		private String name;			// user name
		@XmlAttribute(name = "password", required = true)
		private String password;		// user password
		@XmlAttribute(name = "role", required = true)
		private String role;			// user role
		/**
		 * @return the id
		 */
		public Integer getId() {
			return id;
		}
		/**
		 * @param id the id to set
		 */
		public void setId(Integer id) {
			this.id = id;
		}
		/**
		 * @return the name
		 */
		public String getName() {
			return name;
		}
		/**
		 * @param name the name to set
		 */
		public void setName(String name) {
			this.name = name;
		}
		/**
		 * @return the password
		 */
		public String getPassword() {
			return password;
		}
		/**
		 * @param password the password to set
		 */
		public void setPassword(String password) {
			this.password = password;
		}
		/**
		 * @return the role
		 */
		public String getRole() {
			return role;
		}
		/**
		 * @param role the role to set
		 */
		public void setRole(String role) {
			this.role = role;
		}

	}

}
