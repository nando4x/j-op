package com.nandox.libraries;

/**
 * Utility class to use with @see(ErrorGroupMarker)  
 * 
 * @project   Libraries (Global libraries)
 * 
 * @module    ErrorGroup.java
 * 
 * @date      01 apr 2019 - 01 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public class ErrorGroup {
	/**
	 * Return error code referred to offset specified by ErrorGroupMarker annotation 
	 * @param	  enu	Enum to process
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  code error translated to offset
	 */
	public static int getCode(Enum<?> enu) {
		ErrorGroupMarker a = enu.getClass().getAnnotation(ErrorGroupMarker.class);
		int offset = 0;
		if ( a != null )
			offset = a.value();
		return offset<0?offset - enu.ordinal():offset + enu.ordinal();
	}
}
