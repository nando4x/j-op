package com.nandox.libraries;

import java.lang.String;
import java.util.Arrays;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Enumeration;
import java.util.HashSet;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;


/**
 * Classe che rappresenta una configurazione derivata dalle properties.
 * <p>Una configurazione, cos� come le properties, � fromata da un insieme di chiavi a cui � associato un valore</p>
 * 
 * @project   Domux
 * 
 * @module    Configuration.java
 * 
 * @date      26/mag/2014 - 26/mag/2014
 * 
 * @author    Fernando
 * 
 * @revisor   Fernando
 */
public class Configuration 
{
  private static final int ERRCODEOFFSET = -1000;
  /** Codice di ritorno con successo */
  public static final int RET_OK = 1;
  /** Codice di ritorno errore d'inizializzazione */
  public static final int RET_ERR_INIT = -0 + ERRCODEOFFSET;
  /** Codice di ritorno errore conversione numerico */
  public static final int RET_ERR_NOTNUMBER = -1 + ERRCODEOFFSET;

  private Properties config;
  private String baseKey;
  private boolean caseSensitive;
  /**
   * Crea configurazione vuota
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   */
  public Configuration()
  {
    this.baseKey = "";
    this.config = new Properties();
    this.caseSensitive = true;
  }
  /**
   * Crea configurazione leggendo un input stream i dati
   * @param     Stream stream di input per lettura dati
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @exception Return come Load()
   */
  public Configuration(InputStream stream) throws Return
  {
    this();
    this.load(stream); 
  }
  /**
   * Crea configurazione leggendo una Stringa
   * @param     Data stringa per lettura dati
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @exception Return come Load()
   */
  public Configuration(String data) throws Return
  {
    this();
    ByteArrayInputStream s = new ByteArrayInputStream( data.getBytes() );
    this.load(s); 
  }
  /**
   * Crea configurazione partendo da una configurzione padre                                           
   * @param     Parent configurazione padre
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @exception Return come Load()
   */
  public Configuration(Configuration parent)
  {
    this.baseKey = "";
    this.config = new Properties( parent.config );
  }
  /**
   * Crea configurazione fondendo quella padre coi dati letti da uno stream.
   * <p>In caso di coincidenza di chiavi vince quella dello stream</p>
   * @param     Stream stream di input per lettura dati
   * @param     Parent configurazione padre
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @exception Return come Load()
   */
  public Configuration(InputStream stream,Configuration parent) throws Return
  {
    this(parent);
    this.load(stream); 
  }
  /**
   * Crea configurazione fondendo quella padre coi dati letti da una stringa.
   * <p>In caso di coincidenza di chiavi vince quella della stringa</p>
   * @param     Data stringa per lettura dati
   * @param     Parent configurazione padre
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @exception Return come Load()
   */
  public Configuration(String data,Configuration parent) throws Return
  {
    this(parent);
    ByteArrayInputStream s = new ByteArrayInputStream( data.getBytes() );
    this.load(s); 
  }
  /**
   * Imposta la base ( il prefisso ) delle chiavi.
   * <p>Es: se si hanno una serie di chiavi con lo stesso prefisso � possibile impostarlo come base<br>
   * e leggere le viarie chivi omettendo il prefisso</p>
   * @param     Key chiave di base
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   */
  public void setBaseKey(String key)
  {
    this.baseKey = key;
  }
  /**
   * Imposta la ricerca in case sensitive o meno.
   * @param     Sensitive se true usa il case sensitive altrimento no
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   */
  public void setCaseSensitive(boolean sensitive)
  {
    this.caseSensitive = sensitive;
  }
  
  /**
   * Carica i dati dallo stream
   * @param     Stream stream di input per lettura dati
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @exception Return pu� tornare uno dei seguenti codici:<br>
   * RET_ERR_INIT (errore di lettura dallo stream)    
   */
  public void load(InputStream stream) throws Return
  {
    try
    {
      this.config.load(stream);
    } catch (Exception e) {
       throw new Return(RET_ERR_INIT,null);
    }
  }
  /**
   * Legge il valore numerico della chiave indicata
   * @param     Key chiave da leggere
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    valore numerico della chiave
   * @exception Return pu� tornare uno dei seguenti codici:<br>
   * RET_ERR_NOTNUMBER (dato non numerico)    
   */
  public float getNumValue(String key) throws Return
  {
    try
    {
      return Float.parseFloat(this.getProperty(this.baseKey+key,null));
    } catch (Exception e) { throw new Return(RET_ERR_NOTNUMBER,null); }
  }
  /**
   * Legge il valore intero della chiave indicata con default utilizzato nel caso in cui il valore<br>non sia definito
   * @param     Key chiave da leggere
   * @param     Def valore di default
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    valore intero della chiave
   * @exception Return pu� tornare uno dei seguenti codici:<br>
   * RET_ERR_NOTNUMBER (dato non numerico)
   */
  public float getNumValue(String key, float def) throws Return
  {
    try
    {
      String s = this.getProperty(this.baseKey+key,null);
      if ( s != null && s.length() > 0 )
        return Float.parseFloat(s);
      else
    	return def;
    } catch (Exception e) { throw new Return(RET_ERR_NOTNUMBER,null); }
  }
  /**
   * Legge il valore intero della chiave indicata
   * @param     Key chiave da leggere
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    valore intero della chiave
   * @exception Return pu� tornare uno dei seguenti codici:<br>
   * RET_ERR_NOTNUMBER (dato non numerico)    
   */
  public int getIntValue(String key) throws Return
  {
    try
    {
      return Integer.parseInt(this.getProperty(this.baseKey+key,null));
    } catch (Exception e) { throw new Return(RET_ERR_NOTNUMBER,null); }
  }
  /**
   * Legge il valore intero della chiave indicata con default utilizzato nel caso in cui il valore<br>non sia definito
   * @param     Key chiave da leggere
   * @param     Def valore di default
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    valore intero della chiave
   * @exception Return pu� tornare uno dei seguenti codici:<br>
   * RET_ERR_NOTNUMBER (dato non numerico)
   */
  public int getIntValue(String key, int def) throws Return
  {
    try
    {
      String s = this.getProperty(this.baseKey+key,null);
      if ( s != null && s.length() > 0 )
        return Integer.parseInt(s);
      else
    	return def;
    } catch (Exception e) { throw new Return(RET_ERR_NOTNUMBER,null); }
  }
  /**
   * Legge il valore stringa della chiave indicata
   * @param     Key chiave da leggere
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    valore stringa della chiave
   */
  public String getStringValue(String key)
  {
    String s = this.getProperty(this.baseKey+key,null);
    if ( s != null ) 
      return s.trim();
    return s;
  }
  /**
   * Legge il valore stringa della chiave indicata con default utilizzato nel caso in cui il valore<br>non sia definito
   * @param     Key chiave da leggere
   * @param     Def valore di default
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    valore stringa della chiave
   */
  public String getStringValue(String key, String def)
  {
    String s = this.getProperty(this.baseKey+key,def);
    if ( s != null ) 
      return s.trim();
    return s;
  }
  /**
   * Legge il valore booleano della chiave indicata
   * @param     Key chiave da leggere
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    valore booleano della chiave
   */
  public boolean getBoolValue(String key)
  {
    String s = this.getProperty(this.baseKey+key,null);
    if ( s != null ) 
      if ( ((s.trim()).toLowerCase()).compareTo("true") == 0 )
        return true;
    return false;
  }
  /**
   * Legge il valore booleano della chiave indicata con default utilizzato nel caso in cui il valore<br>non sia definito
   * @param     Key chiave da leggere
   * @param     Def valore di default
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    valore booleano della chiave
   */
  public boolean getBoolValue(String key, boolean def)
  {
    String s = this.getProperty(this.baseKey+key,null);
    if ( s != null ) 
      if ( (s.trim()).toLowerCase() == "true" )
        return true;
      else
        return false;
    return def;
  }
  /**
   * Legge il valore lista di stringhe della chiave indicata.
   * <p>La lista � composta da stringhe separate dalla ,</p>
   * @param     Key chiave da leggere
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    array stringhe della chiave. L'ultimo elemento della lista viene valorizzato a null
   */
  public String[] getStringList(String key)
  {
    String s = this.getStringValue(key);
    if ( s == null )
      return null;
    try {
      int ix = 0;
      StringTokenizer obj = new StringTokenizer ( " "+s, "," );
      int cnt = obj.countTokens();
      String list[] = new String[cnt];
      // Scandisce lista oggetti e crea le mappe di posizione per ogni oggetto
      while (obj.hasMoreTokens()) {
        list[ix] = obj.nextToken().trim();
        ix++;
      }
      return list;
    } catch ( Exception e ) { return null; }
  }
  /**
   * Legge estensione della chiave indicata.
   * <p>L'estensione � composta da stringa racchiusa tra ( e )</p>
   * @param     Key chiave da leggere
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    valore stringa della chiave
   */
  public String getStringExtension(String key)
  {
    try {
      StringTokenizer obj = new StringTokenizer ( this.getStringValue(key), "(" );
      obj.nextToken();
      obj = new StringTokenizer ( obj.nextToken(),")" );
      return obj.nextToken().trim();
    } catch ( Exception e ) { return null; }
  }
  /**
   * Restituisce lo stream per leggere configurazioni
   * @date      15/11/2007 - 15/11/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    stream di lettura
   */
  @SuppressWarnings("rawtypes")
  public InputStream getInputStream()
  {
      Enumeration e = this.config.propertyNames();
      Properties p = new Properties();
      byte[] buf;
      StringBuilder s = new StringBuilder();
      while ( e.hasMoreElements() )
      {
        String k = (String)e.nextElement();
        String v = this.getProperty(k,null);
        p.setProperty(k,v);
        s.append(k+"="+v+"\n");
      }
      buf = s.toString().getBytes();
      return new ByteArrayInputStream(buf);
  }
  /**
   * Restituisce la lista di tutte le chiavi
   * @date      26/02/2008 - 26/02/2008
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   * @return    Enumerazione delle chiavi
   */
  @SuppressWarnings("rawtypes")
  public Enumeration getKeyList()
  {
    return this.config.propertyNames();
  }
  /**
   * Scrive il valore stringa nella chiave indicata
   * @param     Key chiave da scrivere
   * @param     Val valore da scrivere
   * @date      01/16/2007 - 01/16/2007
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   */
  public void setStringValue(String key,String val)
  {
    config.setProperty(key,val);
  }
  //
  //
  //
  private String getProperty ( String key, String def ) {
	  String value = this.config.getProperty(key);
	  if (null != value)
	   return value;
	  if ( !this.caseSensitive ) {
		  Set<Entry<Object, Object>> s = this.config.entrySet();
		  Iterator<Entry<Object, Object>> it = s.iterator();
		  while (it.hasNext()) {
		   Entry<Object, Object> entry = it.next();
		   if (key.equalsIgnoreCase((String) entry.getKey())) {
		    return (String) entry.getValue();
		   }
		  }
	  }
	  return def;
  }
  //---------------------- override and implementation -----------------------
  /**
   * @see       @see java.lang.Object#toString()
   * @date      10/feb/2009 - 10/feb/2009
   * @author    Fernando Costantino
   * @revisor   Fernando Costantino
   */
  @SuppressWarnings("rawtypes")
  public String toString() {
      Enumeration e = this.config.propertyNames();
      HashSet<String> s = new HashSet<String>();
      while ( e.hasMoreElements() )
      {
        String k = (String)e.nextElement();
        String v = this.getProperty(k,null);
        s.add(k+"="+v);
      }
      Object[] o = s.toArray();
      Arrays.sort(o);
      StringBuilder x = new StringBuilder();
      for ( int ix=0; ix<o.length; ix++ )
    	  x.append(o[ix]+"\n");
      return x.toString();
  }
}