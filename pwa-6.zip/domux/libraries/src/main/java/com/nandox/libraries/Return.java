package com.nandox.libraries;

/**
 * Class to manage and represent any return codes.<br>
 * A return code is composite by Code and a message (ApplMsg), can be managed as an Exception
 * 
 * @project   Libraries (Global libraries)
 * 
 * @module    Return.java
 * 
 * @date      20/mag/2014 - 20/mag/2014
 * 
 * @author    Fernando
 * 
 * @revisor   Fernando
 */
public class Return extends Exception {
	private static final long serialVersionUID = 1L;
	/** Messaggio dell'eccezzione */
	protected String applMsg;
	/** Codice dell'eccezzione */
	protected int code;
	/** Eventuale sorgente dell'eccezzione */
	public String Source;
	/** Codice di ritorno genenrico per esito positivo */
	public static final int RET_OK = 1;
	/** Codice di ritorno genenrico per esito nullo */
	public static final int RET_NOTHING = 0;
	/**
	 * Costruttore
	 * @param	  Code codice eccezzione	  
	 * @param	  ApplMsg messaggio eccezzione	  
	 * @date      20/mag/2014 - 20/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @exception 
	 */
	public Return(int code, String msg) {
		super(code + " - " + msg);
		this.code = code;
		this.applMsg = msg;
	}
	public Return(int code, String msg, Exception cause) {
		super(cause);
		this.code = code;
		this.applMsg = msg;
	}
	public Return(Enum<?> code, String msg) {
		this(ErrorGroup.getCode(code), msg);
	}
	public Return(Enum<?> code, String msg, Exception cause) {
		this(ErrorGroup.getCode(code), msg, cause);
	}
	public int getCode() {
		return code;
	}
	public String getApplMsg() {
		return applMsg;
	}
}
