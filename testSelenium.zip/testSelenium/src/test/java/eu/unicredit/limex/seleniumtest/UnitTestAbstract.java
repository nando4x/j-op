package eu.unicredit.limex.seleniumtest;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

@RunWith(Parameterized.class)
public abstract class UnitTestAbstract {
	protected static WebDriver driver;

	@Parameterized.Parameters(name = "{0}")
    public static Collection<Object[]> data() {
    	ArrayList<Object[]> ret = new ArrayList<Object[]>(); 
        try {
        	String singleFile = (String)System.getProperties().get("testfile");
        	if (singleFile != null ) {
        		URL furl = UnitTestAbstract.class.getResource((singleFile));
        		if ( furl != null ) {
        			ret.add(new Object[] {singleFile, furl.getFile()});
        		} else {
        			throw new FileNotFoundException(singleFile);
        		}
        	} else {
        		ret = scanPackegeHierarchical(".");
        	}
            return ret;
        } catch (Exception e) {
        	throw new RuntimeException(e);
        }    	
    }
    
    private static ArrayList<Object[]> scanPackegeHierarchical(String startPkg) throws Exception {
    	ArrayList<Object[]> ret = new ArrayList<Object[]>(); 
        InputStream in = UnitTestAbstract.class.getResourceAsStream(startPkg);
        if ( in != null ) {  
	        BufferedReader br = new BufferedReader(new InputStreamReader(in));
	        String resource;
	
	        while ((resource = br.readLine()) != null) {
	        	if ( resource.endsWith(".xml") ) {
	        		ret.add(new Object[] {startPkg+"/"+resource, UnitTestAbstract.class.getResource(startPkg+"/"+resource).getFile()});
	        	} else if ( resource.indexOf('.') < 0 ) { // maybe a package
	        		ret.addAll(scanPackegeHierarchical((startPkg.equals(".")?"":startPkg+"/")+resource));
	        	}
	        }
        }
        return ret;
    }

	@BeforeClass
	public static void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", tryToFindWebDriverPath()+"/chromedriver.exe");
	    driver = new ChromeDriver();
	}
	
	@AfterClass
	public static void tearDown() {
		driver.close();
		driver.quit();
	}
	
	private static String tryToFindWebDriverPath() {
		int len = UnitTestAbstract.class.getPackage().getName().split("[.]").length;
		String path = "";
		while ( len > 0 ) {
			path += "../";
			len--;
		}
		path = UnitTestAbstract.class.getResource(path).getPath();
		len = path.indexOf("/test-classes");
		if ( len > 0 )
			path = path.substring(0, len);
		len = path.indexOf("/target");
		if ( len > 0 )
			path = path.substring(0, len);
		return path;
	}
}
