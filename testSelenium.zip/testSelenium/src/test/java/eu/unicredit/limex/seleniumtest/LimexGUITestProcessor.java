package eu.unicredit.limex.seleniumtest;


import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.junit.Assert.*;

import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.FileInputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import eu.unicredit.limex.seleniumtest.domain.LimexGUITest;
import eu.unicredit.limex.seleniumtest.domain.LimexGUITest.Action;
import eu.unicredit.limex.seleniumtest.domain.LimexGUITest.Action.Navigator;
import eu.unicredit.limex.seleniumtest.domain.LimexGUITest.Action.Assert;

public class LimexGUITestProcessor {
	private JAXBContext jaxb;
	private LimexGUITest limexTest;
	private WebDriver drv;

	/**
	 * Construnctor
	 * @param	  drv Selenium webdriver
	 * @param	  filename XML test file to execute 
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public LimexGUITestProcessor(WebDriver drv, String filename) throws Exception {
		this.jaxb = JAXBContext.newInstance(LimexGUITest.class.getPackage().getName());
		Unmarshaller u = null;
		u = this.jaxb.createUnmarshaller();
		this.limexTest = (LimexGUITest)u.unmarshal(new FileInputStream(filename));
		this.drv = drv;
		this.extend();
	}
	/**
	 * Run this test.<br>
	 * Parsing and execute every actions 
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public void runTest() {
		NavigationHelper.openURLandLogin(this.drv, this.limexTest.getUrl(), this.limexTest.getUser(), this.limexTest.getPassword());
		for ( Action act : this.limexTest.getAction() ) {
			this.runSingleAction(act);
			NavigationHelper.gotoHome(this.drv);
		}
		NavigationHelper.logout(this.drv);
	}
	/**
	 * Run a single Action of tes.<br>
	 * Parsing action from to to bottom, submit a form by Navigator Set and check every Assert 
	 * @param	  act	Action of test
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public void runSingleAction(Action act) {
		if ( act.getMenu() != null ) {
			String[] menu = act.getMenu().split("/");
			NavigationHelper.gotoMenu(this.drv, menu);
		}
		WebElement e = null;
		for ( Object o : act.getContent() ) {
			if ( !(o instanceof JAXBElement) )
				continue;
			JAXBElement<?> i = (JAXBElement<?>)o;
			if ( i.getValue() instanceof Navigator ) {
				drv.switchTo().defaultContent();
				NavigationHelper.selectFrame(drv, ((Navigator)i.getValue()).getFrame());
				for ( Navigator.Set s : ((Navigator)i.getValue()).getSet() ) {
					if ( s.getId() != null || s.getName() != null || s.getSelectorcss() != null || s.getXpath() != null ) {
						e = this.seleniumFindElement(s.getId(), s.getName(), s.getSelectorcss(), s.getXpath() );
						if ( NavigationHelper.setElementValue(e, this.evalVariable(s.getValue())) )
							e = null;
					}
				}
				if ( e != null )
					e.submit();
				// switch to new tab if present or remain on current
				String[] wH = drv.getWindowHandles().toArray(new String[0]);
				drv.switchTo().window(wH[wH.length-1]);
				// wait eventually delayed loading
				NavigationHelper.waitDelayedLoading(drv, 60);
			} else if ( i.getValue() instanceof Assert ) {
				Assert ass = (Assert)i.getValue();
				String failMsg = ass.getMessage() != null?ass.getMessage().getValue() : null;
				if ( ass.getFrame() != null && !ass.getFrame().isEmpty() )
					drv.switchTo().defaultContent();
				NavigationHelper.selectFrame(drv,ass.getFrame());
				if ( ass.getText() != null ) {
					String val = ass.getText().getValue();
					if ( ass.getText().getAnywhere() != null && ass.getText().getAnywhere() ) {
						e = drv.findElement(By.tagName("body"));
						assertTrue(failMsg, e.getText().indexOf(val) >= 0);
					} else {
						e = this.seleniumFindElement(ass.getText().getId(), ass.getText().getName(), ass.getText().getSelectorcss(), ass.getText().getXpath(), failMsg);
						assertThat(failMsg, e.getText(), is(val));
					}
				} else if ( ass.getLink() != null ) {
					String val = ass.getLink().getValue(); 
					e = this.seleniumFindElement(ass.getLink().getId(), ass.getLink().getName(), ass.getLink().getSelectorcss(), ass.getLink().getXpath(), failMsg);
					assertThat(failMsg, e.getTagName(), is("a"));
					if ( val != null && !val.isEmpty() )
						assertThat(failMsg, e.getText(), is(val));
				} else if ( ass.getInput() != null ) {
					String val = ass.getInput().getValue(); 
					e = this.seleniumFindElement(ass.getInput().getId(), ass.getInput().getName(), ass.getInput().getSelectorcss(), ass.getInput().getXpath(), failMsg);
					assertThat(failMsg, e.getTagName(), anyOf(is("input"),is("select")));
					if ( !val.isEmpty() )
						assertThat(failMsg, e.getAttribute("value"), is(val));
				}
			}
		}
	}
	
	private WebElement seleniumFindElement(String id, String name, String css, String xpath ) {
		return this.seleniumFindElement(id, name, css, xpath, null);
	}
	// Find a selenium element identify by in order: id attribute, name attribute, css attribute
	// xpath attribute. If fail show a failMessage (if is present)  
	//
	private WebElement seleniumFindElement(String id, String name, String css, String xpath, String failMessage ) {
		try {
			WebElement e = null;
			if ( id != null && !id.isEmpty())
				e = NavigationHelper.findElement(drv, id, NavigationHelper.SelectorType.ByID);
			else if ( name != null && !name.isEmpty())
				e = NavigationHelper.findElement(drv, name, NavigationHelper.SelectorType.ByName);
			else if ( css != null && !css.isEmpty())
				e = NavigationHelper.findElement(drv, css, NavigationHelper.SelectorType.ByCSSSelector);
			else if ( xpath != null && !xpath.isEmpty())
				e = NavigationHelper.findElement(drv, xpath, NavigationHelper.SelectorType.ByXPath);
			return e;
		} catch (Exception e ) {
			if ( failMessage != null && !failMessage.isEmpty() )
				fail(failMessage);
			else
				throw e;
		}
		return null;
	}
	// Extends a test merging this test with those defined in extends attribute
	//
	private void extend() throws Exception {
		if ( this.limexTest.getExtend() != null && !this.limexTest.getExtend().isEmpty() ) {
			String fname = this.getClass().getResource(this.limexTest.getExtend()).getFile();
			JAXBContext jaxb = JAXBContext.newInstance(LimexGUITest.class.getPackage().getName());
			Unmarshaller u = jaxb.createUnmarshaller();
			LimexGUITest lGTsup = (LimexGUITest)u.unmarshal(new FileInputStream(fname));
			for ( Action a : this.limexTest.getAction() ) {
				Action asup = this.searcAction(lGTsup, a.getMenu());
				if ( asup != null) {
					for ( Object o : a.getContent() ) {
						if ( !(o instanceof JAXBElement) )
							continue;
						JAXBElement<?> i = (JAXBElement<?>)o;
						if ( i.getValue() instanceof Navigator ) {
							Navigator nav = ((Navigator)i.getValue());
							Navigator navsup = this.searchNavigator(asup, ((Navigator)i.getValue()).getFrame());
							if ( navsup != null ) {
								for ( Navigator.Set s : nav.getSet() ) {
									Navigator.Set ssup = this.searchSet(navsup, s.getId(), s.getName(), s.getSelectorcss(), s.getXpath());
									if ( ssup != null ) {
										ssup.setValue(s.getValue());
									} else
										navsup.getSet().add(s);
								}
							}
						}
					}
				}
			}
			this.limexTest = lGTsup;
		}
	}
	// Search a Action node identify by menu attribute
	//
	private Action searcAction(LimexGUITest ut, String id) {
		for ( Action a : ut.getAction() ) {
			if ( a.getMenu().equals(id) )
				return a;
		}
		return null;
	}
	// Search a Navigator node inside a Action node identify by frame attribute
	//
	private Navigator searchNavigator(Action act, String id) {
		for ( Object o : act.getContent() ) {
			if ( !(o instanceof JAXBElement) )
				continue;
			JAXBElement<?> i = (JAXBElement<?>)o;
			if ( i.getValue() instanceof Navigator ) {
				if ( ((Navigator)i.getValue()).getFrame().equals(id) ) {
					return (Navigator)i.getValue();
				}
			}
		}
		return null;
	}
	// Search a Set node inside a Navigator node identify by in order: id attribute, name attribute, css attribute
	// xpath attribute
	//
	private Navigator.Set searchSet(Navigator nav, String id, String name, String css, String xpath) {
		for ( Navigator.Set s : nav.getSet() ) {
			if( s.getId() != null && s.getId().equals(id) ) {
				return s;
			} else if( s.getName() != null && s.getName().equals(name) ) {
				return s;
			} else if( s.getSelectorcss() != null && s.getSelectorcss().equals(css) ) {
				return s;
			} else if( s.getXpath() != null && s.getXpath().equals(xpath) ) {
				return s;
			}
		}
		return null;
	}
	// Eval a variable. Can be $today or $today plus offset ( es: +1)
	// Offset can be months ( +xm) or years (+xy)
	//
	private String evalVariable(String variable) {
		if ( variable != null ) {
			if (variable.equalsIgnoreCase("$today") ) {
				Date dt = new Date();
				Calendar c = Calendar.getInstance(); 
				c.setTime(dt);
				this.skipHolidays(c);
				return (new SimpleDateFormat("ddMMyyyy")).format(c.getTime());
			} else if (variable.toLowerCase().startsWith("$today") && variable.indexOf('+') > 0) {
				Date dt = new Date();
				Calendar c = Calendar.getInstance(); 
				c.setTime(dt);
				String oper = variable.substring(variable.indexOf('+')+1).trim().toLowerCase();
				int type = Calendar.DATE;
				if ( oper.indexOf('m') > 0 ) {
					type = Calendar.MONTH;
					oper = oper.substring(0, oper.indexOf('m') ).trim();
				} else if ( oper.indexOf('y') > 0 ) {
					type = Calendar.YEAR;
					oper = oper.substring(0, oper.indexOf('y') ).trim();
				}
				c.add(type, Integer.parseInt(oper));
				this.skipHolidays(c);
				return (new SimpleDateFormat("ddMMyyyy")).format(c.getTime());
			}
		}
		return variable;
	}
	// Adjust date to skip holidays 
	//
	private void skipHolidays(Calendar date) {
		if( date.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY )
			date.add(Calendar.DATE, 1);
		if( date.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY )
			date.add(Calendar.DATE, 2);
	}
}
