package eu.unicredit.limex.seleniumtest;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class StandardGUITest extends UnitTestAbstract {
	private String fname;
	private String id;
	
    public StandardGUITest(String id, String fname) {
    	this.fname = fname;
    	this.id = id;
	    System.out.printf("Start Test: %s \r", this.id);
    }

	@Test
	public void test() {
		try {
			LimexGUITestProcessor ut = new LimexGUITestProcessor(driver, this.fname);
			ut.runTest();
		} catch (Exception ex) {
			ex.printStackTrace();
			fail("Exception: " + ex);
		}
	}

}
