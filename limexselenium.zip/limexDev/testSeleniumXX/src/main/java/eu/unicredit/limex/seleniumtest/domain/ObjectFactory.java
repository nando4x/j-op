
package eu.unicredit.limex.seleniumtest.domain;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the eu.unicredit.limex.seleniumtest.domain package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _LimexGUITestActionAssert_QNAME = new QName("", "Assert");
    private final static QName _LimexGUITestActionNavigator_QNAME = new QName("", "Navigator");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: eu.unicredit.limex.seleniumtest.domain
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link LimexGUITest }
     * 
     */
    public LimexGUITest createLimexGUITest() {
        return new LimexGUITest();
    }

    /**
     * Create an instance of {@link LimexGUITest.Action }
     * 
     */
    public LimexGUITest.Action createLimexGUITestAction() {
        return new LimexGUITest.Action();
    }

    /**
     * Create an instance of {@link LimexGUITest.Action.Navigator }
     * 
     */
    public LimexGUITest.Action.Navigator createLimexGUITestActionNavigator() {
        return new LimexGUITest.Action.Navigator();
    }

    /**
     * Create an instance of {@link LimexGUITest.Action.Assert }
     * 
     */
    public LimexGUITest.Action.Assert createLimexGUITestActionAssert() {
        return new LimexGUITest.Action.Assert();
    }

    /**
     * Create an instance of {@link LimexGUITest.Action.Navigator.Set }
     * 
     */
    public LimexGUITest.Action.Navigator.Set createLimexGUITestActionNavigatorSet() {
        return new LimexGUITest.Action.Navigator.Set();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LimexGUITest.Action.Assert }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Assert", scope = LimexGUITest.Action.class)
    public JAXBElement<LimexGUITest.Action.Assert> createLimexGUITestActionAssert(LimexGUITest.Action.Assert value) {
        return new JAXBElement<LimexGUITest.Action.Assert>(_LimexGUITestActionAssert_QNAME, LimexGUITest.Action.Assert.class, LimexGUITest.Action.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LimexGUITest.Action.Navigator }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Navigator", scope = LimexGUITest.Action.class)
    public JAXBElement<LimexGUITest.Action.Navigator> createLimexGUITestActionNavigator(LimexGUITest.Action.Navigator value) {
        return new JAXBElement<LimexGUITest.Action.Navigator>(_LimexGUITestActionNavigator_QNAME, LimexGUITest.Action.Navigator.class, LimexGUITest.Action.class, value);
    }

}
