
package eu.unicredit.limex.seleniumtest.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlMixed;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "action"
})
@XmlRootElement(name = "LimexGUITest")
public class LimexGUITest {

    @XmlElement(name = "Action")
    protected List<LimexGUITest.Action> action;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "url")
    @XmlSchemaType(name = "anyURI")
    protected String url;
    @XmlAttribute(name = "user")
    protected String user;
    @XmlAttribute(name = "password")
    protected String password;
    @XmlAttribute(name = "extend")
    protected String extend;

    /**
     * Gets the value of the action property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the action property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAction().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LimexGUITest.Action }
     * 
     * 
     */
    public List<LimexGUITest.Action> getAction() {
        if (action == null) {
            action = new ArrayList<LimexGUITest.Action>();
        }
        return this.action;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the url property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUrl() {
        return url;
    }

    /**
     * Sets the value of the url property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUrl(String value) {
        this.url = value;
    }

    /**
     * Gets the value of the user property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUser() {
        return user;
    }

    /**
     * Sets the value of the user property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUser(String value) {
        this.user = value;
    }

    /**
     * Gets the value of the password property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the value of the password property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassword(String value) {
        this.password = value;
    }


    /**
	 * @return the extend
	 */
	public String getExtend() {
		return extend;
	}

	/**
	 * @param extend the extend to set
	 */
	public void setExtend(String extend) {
		this.extend = extend;
	}


	/**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Navigator" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Set" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;simpleContent>
     *                         &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
     *                           &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}byte" />
     *                           &lt;attribute name="name" type="{http://www.w3.org/2001/XMLSchema}string" />
     *                           &lt;attribute name="selectorcss" type="{http://www.w3.org/2001/XMLSchema}string" />
     *                           &lt;attribute name="valuetoset" type="{http://www.w3.org/2001/XMLSchema}string" />
     *                         &lt;/extension>
     *                       &lt;/simpleContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *                 &lt;attribute name="frame" type="{http://www.w3.org/2001/XMLSchema}string" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="Assert" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Text" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="Link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="Input" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="frame" type="{http://www.w3.org/2001/XMLSchema}string" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="menu" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "content"
    })
    public static class Action {

        @XmlElementRefs({
            @XmlElementRef(name = "Navigator", type = JAXBElement.class, required = false),
            @XmlElementRef(name = "Assert", type = JAXBElement.class, required = false)
        })
        @XmlMixed
        protected List<Serializable> content;
        @XmlAttribute(name = "menu")
        protected String menu;

        /**
         * Gets the value of the content property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the content property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getContent().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link JAXBElement }{@code <}{@link LimexGUITest.Action.Assert }{@code >}
         * {@link JAXBElement }{@code <}{@link LimexGUITest.Action.Navigator }{@code >}
         * {@link String }
         * 
         * 
         */
        public List<Serializable> getContent() {
            if (content == null) {
                content = new ArrayList<Serializable>();
            }
            return this.content;
        }

        /**
         * Gets the value of the menu property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMenu() {
            return menu;
        }

        /**
         * Sets the value of the menu property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMenu(String value) {
            this.menu = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Text" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="Link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="Input" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="frame" type="{http://www.w3.org/2001/XMLSchema}string" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
        	"message",	
            "text",
            "link",
            "input"
        })
        public static class Assert {

            @XmlElement(name = "Message")
            protected Message message;
            @XmlElement(name = "Text")
            protected Text text;
            @XmlElement(name = "Link")
            protected Element link;
            @XmlElement(name = "Input")
            protected Element input;
            @XmlAttribute(name = "frame")
            protected String frame;

            /**
			 * @return the message
			 */
			public Message getMessage() {
				return message;
			}

			/**
			 * @param message the message to set
			 */
			public void setMessage(Message message) {
				this.message = message;
			}

			/**
             * Gets the value of the text property.
             * 
             * @return
             *     possible object is
             *     {@link Element }
             *     
             */
            public Text getText() {
                return text;
            }

            /**
             * Sets the value of the text property.
             * 
             * @param value
             *     allowed object is
             *     {@link Element }
             *     
             */
            public void setText(Text value) {
                this.text = value;
            }

            /**
             * Gets the value of the link property.
             * 
             * @return
             *     possible object is
             *     {@link Element }
             *     
             */
            public Element getLink() {
                return link;
            }

            /**
             * Sets the value of the link property.
             * 
             * @param value
             *     allowed object is
             *     {@link Element }
             *     
             */
            public void setLink(Element value) {
                this.link = value;
            }

            /**
             * Gets the value of the input property.
             * 
             * @return
             *     possible object is
             *     {@link Element }
             *     
             */
            public Element getInput() {
                return input;
            }

            /**
             * Sets the value of the input property.
             * 
             * @param value
             *     allowed object is
             *     {@link Element }
             *     
             */
            public void setInput(Element value) {
                this.input = value;
            }

            /**
             * Gets the value of the frame property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFrame() {
                return frame;
            }

            /**
             * Sets the value of the frame property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFrame(String value) {
                this.frame = value;
            }

            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "value"
            })
            public static class Message {
                @XmlValue
                protected String value;
				/**
				 * @return the value
				 */
				public String getValue() {
					return value;
				}
				/**
				 * @param value the value to set
				 */
				public void setValue(String value) {
					this.value = value;
				}

            }
            public static class Text extends Element {
                @XmlAttribute(name = "anywhere")
                protected Boolean anywhere;

				/**
				 * @return the anywhere
				 */
				public Boolean getAnywhere() {
					return anywhere;
				}

				/**
				 * @param anywhere the anywhere to set
				 */
				public void setAnywhere(Boolean anywhere) {
					this.anywhere = anywhere;
				}
            }
            
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "value"
            })
            public static class Element {
                @XmlValue
                protected String value;
                @XmlAttribute(name = "id")
                protected String id;
                @XmlAttribute(name = "name")
                protected String name;
                @XmlAttribute(name = "selectorcss")
                protected String selectorcss;
                @XmlAttribute(name = "xpath")
                protected String xpath;
				/**
				 * @return the value
				 */
				public String getValue() {
					return value;
				}
				/**
				 * @param value the value to set
				 */
				public void setValue(String value) {
					this.value = value;
				}
				/**
				 * @return the id
				 */
				public String getId() {
					return id;
				}
				/**
				 * @param id the id to set
				 */
				public void setId(String id) {
					this.id = id;
				}
				/**
				 * @return the name
				 */
				public String getName() {
					return name;
				}
				/**
				 * @param name the name to set
				 */
				public void setName(String name) {
					this.name = name;
				}
				/**
				 * @return the selectorcss
				 */
				public String getSelectorcss() {
					return selectorcss;
				}
				/**
				 * @param selectorcss the selectorcss to set
				 */
				public void setSelectorcss(String selectorcss) {
					this.selectorcss = selectorcss;
				}
				/**
				 * @return the xpath
				 */
				public String getXpath() {
					return xpath;
				}
				/**
				 * @param xpath the xpath to set
				 */
				public void setXpath(String xpath) {
					this.xpath = xpath;
				}
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Set" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;simpleContent>
         *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
         *                 &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}byte" />
         *                 &lt;attribute name="name" type="{http://www.w3.org/2001/XMLSchema}string" />
         *                 &lt;attribute name="selectorcss" type="{http://www.w3.org/2001/XMLSchema}string" />
         *                 &lt;attribute name="valuetoset" type="{http://www.w3.org/2001/XMLSchema}string" />
         *               &lt;/extension>
         *             &lt;/simpleContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *       &lt;attribute name="frame" type="{http://www.w3.org/2001/XMLSchema}string" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "set"
        })
        public static class Navigator {

            @XmlElement(name = "Set")
            protected List<LimexGUITest.Action.Navigator.Set> set;
            @XmlAttribute(name = "frame")
            protected String frame;

            /**
             * Gets the value of the set property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the set property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getSet().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link LimexGUITest.Action.Navigator.Set }
             * 
             * 
             */
            public List<LimexGUITest.Action.Navigator.Set> getSet() {
                if (set == null) {
                    set = new ArrayList<LimexGUITest.Action.Navigator.Set>();
                }
                return this.set;
            }

            /**
             * Gets the value of the frame property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFrame() {
                return frame;
            }

            /**
             * Sets the value of the frame property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFrame(String value) {
                this.frame = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;simpleContent>
             *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
             *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}byte" />
             *       &lt;attribute name="name" type="{http://www.w3.org/2001/XMLSchema}string" />
             *       &lt;attribute name="selectorcss" type="{http://www.w3.org/2001/XMLSchema}string" />
             *       &lt;attribute name="valuetoset" type="{http://www.w3.org/2001/XMLSchema}string" />
             *     &lt;/extension>
             *   &lt;/simpleContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "value"
            })
            public static class Set {

                @XmlValue
                protected String value;
                @XmlAttribute(name = "id")
                protected String id;
                @XmlAttribute(name = "name")
                protected String name;
                @XmlAttribute(name = "selectorcss")
                protected String selectorcss;
                @XmlAttribute(name = "xpath")
                protected String xpath;

                /**
                 * Gets the value of the value property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getValue() {
                    return value;
                }

                /**
                 * Sets the value of the value property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setValue(String value) {
                    this.value = value;
                }

                /**
                 * Gets the value of the id property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getId() {
                    return id;
                }

                /**
                 * Sets the value of the id property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setId(String value) {
                    this.id = value;
                }

                /**
                 * Gets the value of the name property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getName() {
                    return name;
                }

                /**
                 * Sets the value of the name property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setName(String value) {
                    this.name = value;
                }

                /**
                 * Gets the value of the selectorcss property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getSelectorcss() {
                    return selectorcss;
                }

                /**
                 * Sets the value of the selectorcss property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setSelectorcss(String value) {
                    this.selectorcss = value;
                }

				/**
				 * @return the xpath
				 */
				public String getXpath() {
					return xpath;
				}

				/**
				 * @param xpath the xpath to set
				 */
				public void setXpath(String xpath) {
					this.xpath = xpath;
				}
             }
        }
    }
}
