package eu.unicredit.limex.seleniumtest;

import java.io.FileOutputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/**
 * Helper class for limex navigation (es: login, logut, go home, etc. etc. )  
 * 
 * @project   Limex
 * 
 * @module    NavigationHelper.java
 * 
 * @date      24 Oct 2019 - 24 Oct 2019
 * 
 * @author    Fernando Costantino (ee38938)
 * 
 * @revisor   Fernando Costantino (ee38938)
 */
public class NavigationHelper {
	
	private static final String FRAME_TOP = "Root.Top";
	private static final String LOGIN_USER_ELEMENT_NAME = "j_username";
	private static final String LOGIN_PASSWORD_ELEMENT_NAME = "j_password";
	private static final String HOMELINK_CSS_SELECTOR = "a[href*=\"=de/hvb/rt/business/dialog/fsmain/RtMrStartBusiness.xsl\"][target=\"_top\"";
	private static final String LOGOUTLINK_CSS_SELECTOR = "a[href*=\"RtApLogout.xsl\"][target=\"_top\"";
	private static final String DEALYEDLOADING_CSS_SELECTOR = "div.centered img[src^=\"/trarisk/images/ajax-loader.gif\"] + div.progress";
	private static int delayAfterClick = 0; 
	
	/** Available selector to find an html element */
	public enum SelectorType {
		/** to find element by html id */
		ByID,		
		/** to find element by html name attribute */
		ByName,
		/** to find element by css selector */
		ByCSSSelector,
		/** to find element by DOM xpath rules */
		ByXPath
	}
	/**
	 * Open a limex url (es: https://riskqsu.internal.unicreditgroup.eu/trarisk) and do the login
	 * @param	  drv	Selenium web driver
	 * @param	  url 	url to open 
	 * @param	  user  login user 
	 * @param	  password login password
	 * @param	  outputPagePath (optional) path where output page (login and home) 
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public static void openURLandLogin (WebDriver drv, String url, String user, String password, String outputPagePath) {
		drv.get(url);
		outputCurrentPageOnFile(drv, outputPagePath, "login");
		WebElement e;
		try {
			// need when try to open local url (if running GUI on local machine)
			e = drv.findElement(By.partialLinkText("Risk - Application"));
			e.click();
		} catch (Exception ex ) {}
		if ( user != null ) {
			e = drv.findElement(By.name(LOGIN_USER_ELEMENT_NAME));
			e.sendKeys(user);
			e = drv.findElement(By.name(LOGIN_PASSWORD_ELEMENT_NAME));
			e.sendKeys(password);
			e.submit();
			outputCurrentPageOnFile(drv, outputPagePath, "home");
		}
	}
	/**
	 * Open a specific limex menu
	 * @param	  drv	Selenium web driver
	 * @param	  menu 	hierarchic menu (es. [CpRisk][Counterparty Analysis]) 
	 * @param	  outputPagePath (optional) path where output page (home_top) 
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public static void gotoMenu(WebDriver drv, String[] menu, String outputPagePath) {
		WebDriver top = null;
		for ( String m : menu ) {
			top = drv.switchTo().frame(FRAME_TOP);
			outputCurrentPageOnFile(top, outputPagePath, "home_top");
			WebElement e = top.findElement(By.partialLinkText(m));
			e.click();
		}
	}
	/**
	 * Goto home limex page
	 * @param	  drv	Selenium web driver
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public static void gotoHome(WebDriver drv) {
		// switch to browser's first tab and close all others
		String[] wH = drv.getWindowHandles().toArray(new String[0]);
		for ( int ix = wH.length-1; ix>0; ix--)
			drv.switchTo().window(wH[ix]).close();
		drv.switchTo().window(wH[0]);
		
		drv.switchTo().defaultContent();
		WebDriver top = drv.switchTo().frame(FRAME_TOP);
		WebElement e = top.findElement(By.cssSelector(HOMELINK_CSS_SELECTOR));
		e.click();
	}
	/**
	 * Logout from limex
	 * @param	  drv	Selenium web driver
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public static void logout(WebDriver drv) {
		drv.switchTo().defaultContent();
		WebDriver top = drv.switchTo().frame(FRAME_TOP);
		WebElement e = top.findElement(By.cssSelector(LOGOUTLINK_CSS_SELECTOR));
		e.click();
	}
	/**
	 * Select an html frame on limex page.<br>
	 * The frame name can be hierarchical separated by '/' char, so the effective frame selected will be the last level of<br> 
	 * hierarchy
	 * @param	  drv	Selenium web driver
	 * @param	  frame	Hierarchical frame name (es: Root.Down/navi)
	 * @param	  outputPagePath (optional) path where output page 
	 * @param	  outputPageName (optional) name of output page 
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  frame selected
	 */
	public static WebDriver selectFrame(WebDriver drv, String frame, String outputPagePath, String outputPageName) {
		String fnavs[] = (frame!=null?frame:"").split("/");
		WebDriver nav = drv;
		for ( int ix=0; fnavs!=null&&ix<fnavs.length&&!fnavs[ix].isEmpty(); ix++ ) {
			nav = nav.switchTo().frame(fnavs[ix]);
		}
		outputCurrentPageOnFile(nav, outputPagePath, outputPageName);
		return nav;
	}
	/**
	 * Find and select an html element.<br>
	 * The element can be found by one of available SelectorType enums 
	 * @param	  drv	Selenium web driver
	 * @param	  frame	Hierarchical frame name (es: Root.Down/navi)
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  @link(org.openqa.selenium.WebElement) reference to html element found
	 * @exception @link(org.openqa.selenium.NoSuchElementException) if element not found
	 */
	public static WebElement findElement(WebDriver drv, String selector, SelectorType type) {
		WebElement e = null;
		switch ( type ) {
			case ByID: 
				e = drv.findElement(By.id(selector));
				break;
			case ByName: 
				e = drv.findElement(By.name(selector));
				break;
			case ByCSSSelector: 
				e = drv.findElement(By.cssSelector(selector));
				break;
			case ByXPath: 
				e = drv.findElement(By.xpath(selector));
				break;
		}
		return e;
	}
	/**
	 * Set value to an html element.<br>
	 * If element is a select html the value can be both option value or option visible text (with this sequence priority).<br>
	 * If element is an input submit or a button don't set the value but click the element 
	 * If element is a link (<a>) don't set the value but click the element 
	 * @param	  element	Selenium web element
	 * @param	  value		String that represent the value to set
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  true if do a submit (in case of element should be a button or input submit)
	 */
	public static boolean setElementValue(WebElement e, String value) {
		if ( e.getTagName().equalsIgnoreCase("select") ) {
			Select select = new Select(e);
			try {
				select.selectByValue(value);
			} catch (Exception ex) {
				select.selectByVisibleText(value);
			}
		} else if (isClickable(e)) {
			e.click();
			return true;
		} else {
			e.sendKeys(value);
		}
		return false;
	}
	/**
	 * Waiting delayed loading (es. Trades list pages).<br>
	 * If in page is present progress status for delayed loading, it wait (for timeout duration) until the real
	 * page is loading and progress status does vanish 
	 * @param	  drv	Selenium web driver
	 * @param	  timeout		timeout [sec] to wait, when expired Exception is risen
	 * @date      24 Oct 2019 - 24 Oct 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception @link(org.openqa.selenium.NoSuchElementException) if element not found
	 */
	public static void waitDelayedLoading(WebDriver drv, int timeout) {
		long start = System.currentTimeMillis();
		while ( System.currentTimeMillis() < (start + (timeout*1000L)) ) {
			try {
				findElement(drv, DEALYEDLOADING_CSS_SELECTOR, SelectorType.ByCSSSelector);
				Thread.sleep(1000);
			} catch (Exception e) {
				return;
			}
		}
	}
	
	public static void setDelayAfterCkick(int delay) {
		delayAfterClick = delay;
	}
	
	public static void outputCurrentPageOnFile(WebDriver drv, String outputPagePath, String pageName) {
		if ( outputPagePath != null && drv != null ) {
			try {
				String page = drv.getPageSource();
				FileOutputStream out = new FileOutputStream(outputPagePath+"/"+pageName+".html");
				out.write(page.getBytes());
				out.close();
			} catch (Exception e) {
				System.out.print(e);
			}
		}
	}
	//
	//
	//
	private static boolean isClickable(WebElement e) {
		if ( e.getTagName().equalsIgnoreCase("input") && e.getAttribute("type").equalsIgnoreCase("submit") )
			return true;
		else if ( e.getTagName().equalsIgnoreCase("button") )
			return true;
		else if ( e.getTagName().equalsIgnoreCase("a") )
			return true;
		return false;
	}
}
