package eu.unicredit.limex.seleniumtest;

import static org.junit.Assert.*;

import java.io.FileOutputStream;
import org.junit.Test;

public class JenkinsCheckTest extends UnitTestAbstract {
	private String url;
	
    public JenkinsCheckTest() {
    	this.url = (String)System.getProperties().get("url");
	    System.out.printf("Start Test: %s \r", this.getClass().getName());
    }

	@Test
	public void test() {
		try {
			driver.get(this.url);
			String outPage = (String)System.getProperties().get("page.output.dir");
			if ( outPage != null) {
				String page = driver.getPageSource();
				FileOutputStream out = new FileOutputStream(outPage+"/page.html");
				out.write(page.getBytes());
				out.close();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			fail("Exception: " + ex);
		}
	}

}
