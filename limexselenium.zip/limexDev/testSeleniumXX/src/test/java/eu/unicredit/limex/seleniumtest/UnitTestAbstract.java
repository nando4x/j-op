package eu.unicredit.limex.seleniumtest;


import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public abstract class UnitTestAbstract {
	protected static WebDriver driver;


	@BeforeClass
	public static void setUp() throws Exception {
		String logpath = (String)System.getProperties().get("logpath");
		if ( logpath != null ) {
			System.setProperty("webdriver.chrome.verboseLogging", "true");
			System.setProperty("webdriver.chrome.logfile", logpath);
		}
		String systemwebdriver = (String)System.getProperties().get("system.webdriver");
		if ( systemwebdriver == null )
			System.setProperty("webdriver.chrome.driver", tryToFindWebDriverPath()+"/chromedriver.exe");
		String options = (String)System.getProperties().get("chrome.options");
		if ( options != null ) {
			ChromeOptions opt = new ChromeOptions();
			for ( String o : options.split(" ") ) {
				opt.addArguments(o.trim());
			}
			String path = (String)System.getProperties().get("chrome.path");
			if ( path != null )
				opt.setBinary(path);
			driver = new ChromeDriver(opt);
		} else
	    	driver = new ChromeDriver();
	}
	
	@AfterClass
	public static void tearDown() {
		driver.close();
		driver.quit();
	}
	
	private static String tryToFindWebDriverPath() {
		int len = UnitTestAbstract.class.getPackage().getName().split("[.]").length;
		String path = "";
		while ( len > 0 ) {
			path += "../";
			len--;
		}
		path = UnitTestAbstract.class.getResource(path).getPath();
		len = path.indexOf("/test-classes");
		if ( len > 0 )
			path = path.substring(0, len);
		len = path.indexOf("/target");
		if ( len > 0 )
			path = path.substring(0, len);
		return path;
	}
}
