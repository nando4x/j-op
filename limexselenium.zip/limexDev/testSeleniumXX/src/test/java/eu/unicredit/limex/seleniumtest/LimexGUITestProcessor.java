package eu.unicredit.limex.seleniumtest;


import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.junit.Assert.*;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.io.FileInputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import eu.unicredit.limex.seleniumtest.domain.LimexGUITest;
import eu.unicredit.limex.seleniumtest.domain.LimexGUITest.Action;
import eu.unicredit.limex.seleniumtest.domain.LimexGUITest.Action.Navigator;
import eu.unicredit.limex.seleniumtest.domain.LimexGUITest.Action.Assert;

public class LimexGUITestProcessor {
	private JAXBContext jaxb;
	private LimexGUITest limexTest;
	private WebDriver drv;
	private String outputPagePath;
	private WebDriver lastFrameSelected;
	private WebElement lastElementSelected;
	private String fname;
	private boolean debugenabled;
	private List<LimexGUITestItem> items;
	
	private static final String URL_DEFAULT="https://riskqsu.internal.unicreditgroup.eu/trarisk";
	private static final String USER_DEFAULT="kone";
	private static final String PASSWORD_DEFAULT="";

	/**
	 * Construnctor
	 * @param	  drv Selenium webdriver
	 * @param	  filename XML test file to execute 
	 * @date      24 Oct 2019 - 17 Gen 2020
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public LimexGUITestProcessor(WebDriver drv, String filename) throws Exception {
		this.jaxb = JAXBContext.newInstance(LimexGUITest.class.getPackage().getName());
		Unmarshaller u = null;
		u = this.jaxb.createUnmarshaller();
		this.limexTest = (LimexGUITest)u.unmarshal(new FileInputStream(filename));
		// extract test name by filename
		String arr[] = filename.split("/");
		this.fname = arr[arr.length-1];
		int end = fname.lastIndexOf(".");
		if ( end > 0 )
			this.fname = this.fname.substring(0, end);
				
		this.drv = drv;
		this.extend();
		this.debugenabled = (System.getProperty("debug") != null);
		this.items = new ArrayList<LimexGUITestItem>();
	}
	/**
	 * @param outputPagePath the outputPagePath to set
	 */
	public void setOutputPagePath(String outputPagePath) {
		this.outputPagePath = outputPagePath;
	}
	/**
	 * Run this test.<br>
	 * Parsing and execute every actions 
	 * @date      24 Oct 2019 - 17 Gen 2020
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public void runTest() {
		try {
			lastFrameSelected = drv;
			NavigationHelper.openURLandLogin(this.drv, 
								this.evalVariable(this.limexTest.getUrl()), 
								this.evalVariable(this.limexTest.getUser()), 
								this.evalVariable(this.limexTest.getPassword()), 
								this.outputPagePath);
			int ix=0;
			for ( Action act : this.limexTest.getAction() ) {
				LimexGUITestItem item = this.addItem(act,null,ix);
				try {
					this.runSingleAction(act);
				} catch (Throwable tr) {
					item.endTiming();
					throw tr;
				}
				item.endTiming();
				NavigationHelper.gotoHome(this.drv);
				ix++;
			}
			NavigationHelper.logout(this.drv);
		} catch (Exception e) {
			if ( lastElementSelected != null && this.debugenabled ) {
				System.out.println("Last element selected:");
				try {
					System.out.println(lastElementSelected.getText());
					System.out.println(lastElementSelected.getTagName());
					System.out.println(lastElementSelected.toString());
				} catch (Exception ex) {}
			}
			NavigationHelper.outputCurrentPageOnFile(lastFrameSelected, outputPagePath, ""+this.fname+"_error", true);
			throw e;
		} catch (AssertionError e) {
			if ( lastElementSelected != null && this.debugenabled ) {
				System.out.println("Last element selected:");
				try {
					System.out.println(lastElementSelected.getText());
					System.out.println(lastElementSelected.getTagName());
					System.out.println(lastElementSelected.toString());
				} catch (Exception ex) {}
			}
			NavigationHelper.outputCurrentPageOnFile(lastFrameSelected, outputPagePath, ""+this.fname+"_assert", true);
			throw e;
		}
	}
	/**
	 * Run a single Action of test.<br>
	 * Parsing action from to to bottom, submit a form by Navigator Set and check every Assert 
	 * @param	  act	Action of test
	 * @date      24 Oct 2019 - 17 Gen 2020
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public void runSingleAction(Action act) {
		int inx = 0;
		if ( act.getMenu() != null ) {
			String[] menu = act.getMenu().split("/");
			NavigationHelper.gotoMenu(this.drv, menu, outputPagePath);
			NavigationHelper.waitDelayedLoading(drv, 60);
		}
		WebElement e = null;
		for ( Object o : act.getContent() ) {
			if ( !(o instanceof JAXBElement) )
				continue;
			JAXBElement<?> i = (JAXBElement<?>)o;
			if ( i.getValue() instanceof Navigator ) {
				LimexGUITestItem item = this.addItem(i.getValue(),act,inx);
				drv.switchTo().defaultContent();
				NavigationHelper.selectFrame(drv, ((Navigator)i.getValue()).getFrame(), outputPagePath, ""+this.fname+"_nav_"+inx);
				int ix = 0;
				for ( Navigator.Set s : ((Navigator)i.getValue()).getSet() ) {
					if ( s.getId() != null || s.getName() != null || s.getSelectorcss() != null || s.getXpath() != null ) {
						LimexGUITestItem sitem = this.addItem(s,i.getValue(),ix);
						lastElementSelected = e = this.seleniumFindElement(s.getId(), s.getName(), s.getSelectorcss(), s.getXpath() );
						if ( NavigationHelper.setElementValue(e, this.evalVariable(s.getValue())) )
							e = null;
						sitem.endTiming();
					}
					ix++;
				}
				if ( e != null )
					e.submit();
				item.endTiming();
				this.delayAfter();
				// switch to new tab if present or remain on current
				String[] wH = drv.getWindowHandles().toArray(new String[0]);
				drv.switchTo().window(wH[wH.length-1]);
				// wait eventually delayed loading
				NavigationHelper.waitDelayedLoading(drv, 60);
			} else if ( i.getValue() instanceof Assert ) {
				LimexGUITestItem item = this.addItem(i.getValue(),act,inx);
				Assert ass = (Assert)i.getValue();
				String failMsg = ass.getMessage() != null?ass.getMessage().getValue() : null;
				if ( ass.getFrame() != null && !ass.getFrame().isEmpty() )
					drv.switchTo().defaultContent();
				lastFrameSelected = NavigationHelper.selectFrame(drv,ass.getFrame(), outputPagePath, ""+this.fname+"_result_"+inx);
				try {
					if ( ass.getText() != null ) {
						String val = ass.getText().getValue();
						if ( ass.getText().getAnywhere() != null && ass.getText().getAnywhere() ) {
							NavigationHelper.findElement(drv, "body *", NavigationHelper.SelectorType.ByCSSSelector);
							lastElementSelected = e = drv.findElement(By.tagName("body"));
							assertTrue(failMsg, e.getText().indexOf(val) >= 0);
						} else {
							lastElementSelected = e = this.seleniumFindElement(ass.getText().getId(), ass.getText().getName(), ass.getText().getSelectorcss(), ass.getText().getXpath(), failMsg);
							assertThat(failMsg, e.getText(), is(val));
						}
					} else if ( ass.getLink() != null ) {
						String val = ass.getLink().getValue(); 
						lastElementSelected = e = this.seleniumFindElement(ass.getLink().getId(), ass.getLink().getName(), ass.getLink().getSelectorcss(), ass.getLink().getXpath(), failMsg);
						assertThat(failMsg, e.getTagName(), is("a"));
						if ( val != null && !val.isEmpty() )
							assertThat(failMsg, e.getText(), is(val));
					} else if ( ass.getInput() != null ) {
						String val = ass.getInput().getValue(); 
						lastElementSelected = e = this.seleniumFindElement(ass.getInput().getId(), ass.getInput().getName(), ass.getInput().getSelectorcss(), ass.getInput().getXpath(), failMsg);
						assertThat(failMsg, e.getTagName(), anyOf(is("input"),is("select")));
						if ( !val.isEmpty() )
							assertThat(failMsg, e.getAttribute("value"), is(val));
					}
				} catch (AssertionError er) {
					item.endTiming();
					throw er;
				}
			}
			inx++;
		}
	}
	/**
	 * Return timing statistics string.<br>
	 * @date      17 Gen 2020 - 17 Gen 2020
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public String getTimingStatisticAsString() {
		String ret = null;
		long time = 0;
		for ( LimexGUITestItem i : this.items ) {
			if ( i.getConfigItem() instanceof Action )
				time += i.getDuration();
		}
		ret = String.format("effective time (without login): %.3f [sec]", (float)time/1000);
		return ret;
	}
	// Find a selenium element identify by in order: id attribute, name attribute, css attribute
	// xpath attribute. If fail show a failMessage (if is present)  
	//
	private WebElement seleniumFindElement(String id, String name, String css, String xpath ) {
		return this.seleniumFindElement(id, name, css, xpath, null);
	}
	private WebElement seleniumFindElement(String id, String name, String css, String xpath, String failMessage ) {
		try {
			WebElement e = null;
			if ( id != null && !id.isEmpty())
				e = NavigationHelper.findElement(drv, id, NavigationHelper.SelectorType.ByID);
			else if ( name != null && !name.isEmpty())
				e = NavigationHelper.findElement(drv, name, NavigationHelper.SelectorType.ByName);
			else if ( css != null && !css.isEmpty())
				e = NavigationHelper.findElement(drv, css, NavigationHelper.SelectorType.ByCSSSelector);
			else if ( xpath != null && !xpath.isEmpty())
				e = NavigationHelper.findElement(drv, xpath, NavigationHelper.SelectorType.ByXPath);
			return e;
		} catch (Exception e ) {
			if ( failMessage != null && !failMessage.isEmpty() )
				fail(failMessage);
			else
				throw e;
		}
		return null;
	}
	// Extends a test merging this test with those defined in extends attribute
	//
	private void extend() throws Exception {
		if ( this.limexTest.getExtend() != null && !this.limexTest.getExtend().isEmpty() ) {
			String fname = this.getClass().getResource(this.limexTest.getExtend()).getFile();
			JAXBContext jaxb = JAXBContext.newInstance(LimexGUITest.class.getPackage().getName());
			Unmarshaller u = jaxb.createUnmarshaller();
			LimexGUITest lGTsup = (LimexGUITest)u.unmarshal(new FileInputStream(fname));
			for ( Action a : this.limexTest.getAction() ) {
				Action asup = this.searchAction(lGTsup, a.getMenu());
				if ( asup != null) {
					for ( Object o : a.getContent() ) {
						if ( !(o instanceof JAXBElement) )
							continue;
						JAXBElement<?> i = (JAXBElement<?>)o;
						if ( i.getValue() instanceof Navigator ) {
							Navigator nav = ((Navigator)i.getValue());
							Navigator navsup = this.searchNavigator(asup, ((Navigator)i.getValue()).getFrame());
							if ( navsup != null ) {
								for ( Navigator.Set s : nav.getSet() ) {
									Navigator.Set ssup = this.searchSet(navsup, s.getId(), s.getName(), s.getSelectorcss(), s.getXpath());
									if ( ssup != null ) {
										ssup.setValue(s.getValue());
									} else
										navsup.getSet().add(s);
								}
							}
						}
					}
				}
			}
			this.limexTest = lGTsup;
		}
	}
	// Search a Action node identify by menu attribute
	//
	private Action searchAction(LimexGUITest ut, String id) {
		for ( Action a : ut.getAction() ) {
			if ( a.getMenu().equals(id) )
				return a;
		}
		return null;
	}
	// Search a Navigator node inside a Action node identify by frame attribute
	//
	private Navigator searchNavigator(Action act, String id) {
		for ( Object o : act.getContent() ) {
			if ( !(o instanceof JAXBElement) )
				continue;
			JAXBElement<?> i = (JAXBElement<?>)o;
			if ( i.getValue() instanceof Navigator ) {
				if ( ((Navigator)i.getValue()).getFrame().equals(id) ) {
					return (Navigator)i.getValue();
				}
			}
		}
		return null;
	}
	// Search a Set node inside a Navigator node identify by in order: id attribute, name attribute, css attribute
	// xpath attribute
	//
	private Navigator.Set searchSet(Navigator nav, String id, String name, String css, String xpath) {
		for ( Navigator.Set s : nav.getSet() ) {
			if( s.getId() != null && s.getId().equals(id) ) {
				return s;
			} else if( s.getName() != null && s.getName().equals(name) ) {
				return s;
			} else if( s.getSelectorcss() != null && s.getSelectorcss().equals(css) ) {
				return s;
			} else if( s.getXpath() != null && s.getXpath().equals(xpath) ) {
				return s;
			}
		}
		return null;
	}
	// Eval a variable. Can be $today or $today plus offset ( es: +1)
	// Offset can be months ( +xm) or years (+xy)
	//
	private String evalVariable(String variable) {
		if ( variable != null ) {
			if (variable.equalsIgnoreCase("$today") ) {
				Date dt = new Date();
				Calendar c = Calendar.getInstance(); 
				c.setTime(dt);
				this.skipHolidays(c);
				return (new SimpleDateFormat("ddMMyyyy")).format(c.getTime());
			} else if (variable.toLowerCase().startsWith("$today") && variable.indexOf('+') > 0) {
				Date dt = new Date();
				Calendar c = Calendar.getInstance(); 
				c.setTime(dt);
				String oper = variable.substring(variable.indexOf('+')+1).trim().toLowerCase();
				int type = Calendar.DATE;
				if ( oper.indexOf('m') > 0 ) {
					type = Calendar.MONTH;
					oper = oper.substring(0, oper.indexOf('m') ).trim();
				} else if ( oper.indexOf('y') > 0 ) {
					type = Calendar.YEAR;
					oper = oper.substring(0, oper.indexOf('y') ).trim();
				}
				c.add(type, Integer.parseInt(oper));
				this.skipHolidays(c);
				return (new SimpleDateFormat("ddMMyyyy")).format(c.getTime());
			} else if (variable.equalsIgnoreCase("$url") ) {
				return (String)System.getProperty("url", URL_DEFAULT);
			} else if (variable.equalsIgnoreCase("$user") ) {
				return (String)System.getProperty("user", USER_DEFAULT);
			} else if (variable.equalsIgnoreCase("$password") ) {
				return (String)System.getProperty("password", PASSWORD_DEFAULT);
			}
		}
		return variable;
	}
	// Adjust date to skip holidays 
	//
	private void skipHolidays(Calendar date) {
		if( date.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY )
			date.add(Calendar.DATE, 1);
		if( date.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY )
			date.add(Calendar.DATE, 2);
	}
	// Check delay after submit 
	//
	private void delayAfter() {
		String delay = System.getProperty("delay.aftersubmit");
		if ( delay != null && !delay.isEmpty() ) {
			int timeout = 0;
			if ( delay != null )
				timeout = Integer.parseInt(delay);
			long start = System.currentTimeMillis();
			while ( System.currentTimeMillis() < (start + (timeout*1000L)) ) {
				try {
					Thread.sleep(100);
				} catch (Exception e) {
				}
			}
		}
	}
	
	private LimexGUITestItem addItem(Object item, Object parent, int index) {
		LimexGUITestItem ret = new LimexGUITestItem(item,parent,index);
		this.items.add(ret);
		ret.startTiming();
		return ret;
	}
}
