package eu.unicredit.limex.seleniumtest;

public class LimexGUITestItem {
	private Object configItem;
	private Object configParent;
	private int positionalIndex;
	private long startTime;
	private long endTime;
	
	public LimexGUITestItem(Object item, Object parent, int positionalIndex) {
		this.configItem = item;
		this.configParent = parent;
		this.positionalIndex = positionalIndex;
	}

	/**
	 * @return the configItem
	 */
	public Object getConfigItem() {
		return configItem;
	}

	/**
	 * @return the startTime
	 */
	public long getStartTime() {
		return startTime;
	}

	/**
	 * @return the endTime
	 */
	public long getEndTime() {
		return endTime;
	}

	public long getDuration() {
		return this.endTime - this.startTime;
	}
	
	public void startTiming() {
		this.startTime = System.currentTimeMillis();
	}
	
	public void endTiming() {
		this.endTime = System.currentTimeMillis();
	}
}
