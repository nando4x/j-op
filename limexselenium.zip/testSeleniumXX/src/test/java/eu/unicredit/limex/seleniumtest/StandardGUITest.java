package eu.unicredit.limex.seleniumtest;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class StandardGUITest extends UnitTestAbstract {
	private String fname;
	private String id;

	@Parameterized.Parameters(name = "{0}")
    public static Collection<Object[]> data() {
    	ArrayList<Object[]> ret = new ArrayList<Object[]>(); 
        try {
        	String singleFile = (String)System.getProperties().get("testfile");
        	if (singleFile != null ) {
        		URL furl = UnitTestAbstract.class.getResource((singleFile));
        		if ( furl != null ) {
        			ret.add(new Object[] {singleFile, furl.getFile()});
        		} else {
        			throw new FileNotFoundException(singleFile);
        		}
        	} else {
        		ret = scanPackegeHierarchical(".");
        	}
            return ret;
        } catch (Exception e) {
        	throw new RuntimeException(e);
        }    	
    }
    
    private static ArrayList<Object[]> scanPackegeHierarchical(String startPkg) throws Exception {
    	ArrayList<Object[]> ret = new ArrayList<Object[]>(); 
        InputStream in = UnitTestAbstract.class.getResourceAsStream(startPkg);
        if ( in != null ) {  
	        BufferedReader br = new BufferedReader(new InputStreamReader(in));
	        String resource;
	
	        while ((resource = br.readLine()) != null) {
	        	if ( resource.endsWith(".xml") ) {
	        		ret.add(new Object[] {startPkg+"/"+resource, UnitTestAbstract.class.getResource(startPkg+"/"+resource).getFile()});
	        	} else if ( resource.indexOf('.') < 0 ) { // maybe a package
	        		ret.addAll(scanPackegeHierarchical((startPkg.equals(".")?"":startPkg+"/")+resource));
	        	}
	        }
        }
        return ret;
    }
	
    public StandardGUITest(String id, String fname) {
    	this.fname = fname;
    	this.id = id;
	    System.out.printf("Start Test: %s \r", this.id);
    }

	@Test
	public void test() {
		try {
			LimexGUITestProcessor ut = new LimexGUITestProcessor(driver, this.fname);
			ut.setOutputPagePath((String)System.getProperties().get("page.output.dir"));
			ut.runTest();
		} catch (Exception ex) {
			ex.printStackTrace();
			fail("Exception: " + ex);
		}
	}

}
