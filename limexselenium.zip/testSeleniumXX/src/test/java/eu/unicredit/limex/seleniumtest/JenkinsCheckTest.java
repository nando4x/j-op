package eu.unicredit.limex.seleniumtest;

import static org.junit.Assert.*;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.io.BufferedReader;
import java.io.File;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class JenkinsCheckTest extends UnitTestAbstract {
	private String url;
	
    public JenkinsCheckTest() {
    	this.url = (String)System.getProperties().get("url");
	    System.out.printf("Start Test: %s \r", this.getClass().getName());
    }

	@Test
	public void test() {
		try {
			File x = new File(".");
			System.out.println(x.getAbsolutePath());
			
			driver.get(this.url);
			String outPage = (String)System.getProperties().get("page.output.dir");
			if ( outPage != null) {
				String page = driver.getPageSource();
				FileOutputStream out = new FileOutputStream(outPage+"/page.html");
				out.write(page.getBytes());
				out.close();
			}
			String intercative = System.getProperty("intercative");
			WebDriver drv = driver;
			WebElement el = null;
			while ( intercative != null ) {
				File f = new File(intercative);
				if ( f.exists() ) {
					BufferedReader in = new BufferedReader(new FileReader(f));
					String cmd = in.readLine();
					in.close();
					f.delete();
					if ( cmd.equalsIgnoreCase("end") )
						break;
					else {
						String data[] = cmd.split(",");
						Method ma[] = NavigationHelper.class.getMethods();
						boolean found = false;
						for ( Method m : ma ) {
							if ( m.getName().equalsIgnoreCase(data[0]) ) {
								Parameter pa[] = m.getParameters();
								Object args[] = new Object[pa.length];
								int ix = 0, inx = 1;
								for (Parameter p : pa ) {
									if ( p.getType() == WebDriver.class )
										args[ix] = drv;
									else if ( p.getType() == WebElement.class )
										args[ix] = el;
									else if ( p.getType() == NavigationHelper.SelectorType.class ) {
										args[ix] = NavigationHelper.SelectorType.valueOf(NavigationHelper.SelectorType.class, data[inx++]);
									} else if ( p.getType().isArray() ) {
										args[ix] = data[inx++].split("/");
									} else 
										args[ix] = data[inx++].trim();
									ix++;
								}
								Object ret = m.invoke(null, args);
								if ( ret != null ) { 
									if ( ret instanceof WebDriver )
										drv = (WebDriver)ret;
									else if ( ret instanceof WebElement )
										el = (WebElement)ret;
								}
								found = true;
								break;
							}
						}
						if ( !found )
							throw new Exception("method not found");
					}
				}
				Thread.sleep(100);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			fail("Exception: " + ex);
		}
	}

}
