package com.nandox.libraries;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation to mark and offset for group errors.<br>
 * Es:  @ErrorGroupMarker(-2001).<br>
 * When use this annotation on enum you can define an offset for all others<br>
 * error code.<br>
 * Then use ErrorGroup class to get numerico code from offset  
 * 
 * @project   Libraries (Global libraries)
 * 
 * @module    ErrorGroupMarker.java
 * 
 * @date      01 apr 2019 - 01 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
@Documented
@Target({ TYPE })
@Retention(RUNTIME)
public @interface ErrorGroupMarker {
	int value() default 0;
}
