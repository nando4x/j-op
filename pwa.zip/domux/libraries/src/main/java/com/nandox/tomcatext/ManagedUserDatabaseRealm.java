package com.nandox.tomcatext;

import java.util.Iterator;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;

import java.util.ArrayList;

import org.apache.catalina.User;
import org.apache.catalina.Engine;
import org.apache.catalina.Host;
import org.apache.catalina.Realm;
import org.apache.catalina.Role;
import org.apache.catalina.Server;
import org.apache.catalina.Service;
import org.apache.catalina.users.MemoryUserDatabase;
import org.apache.catalina.realm.UserDatabaseRealm;
/**
 * Class to manage tomcat native database users (tomcat_users.xml file).<br>
 * This class must to be used in tomcat server.xml configuration as unique Realm:
 * 
 * 		<Realm className="com.nandox.tomcatext.ManagedUserDatabaseRealm" resourceName="UserDatabase"/>
 * 
 * Remember to setting the path of this class in catalina common.loader property
 * To access to this class from your application you must use the Commander class<br>
 * (got by getInstance static method) and this class directly. With Commnader is possible
 * to get Users list, add user. modify user, save all to tomcat_users.xml file
 *  
 * @project   domuxCenter
 * 
 * @module    ManagedUserDatabaseRealm.java
 * 
 * @date      05 ago 2019 - 05 ago 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class ManagedUserDatabaseRealm extends UserDatabaseRealm {
	private static Commander cmd = null;
	/* (non-Javadoc)
	 * @see com.nandox.tomcatext.ManagedUserDatabaseRealm.Commander#getUsers()
	 */
	@SuppressWarnings("unchecked")
	public User[] getUsers () {
		Iterator<User> i = this.database.getUsers();
		ArrayList<User> ua = new ArrayList<User>(); 
		while (i.hasNext()) {
			User u = i.next();
			ua.add(u);
		}
		return ua.toArray(new User[0]);
	}
	/* (non-Javadoc)
	 * @see com.nandox.tomcatext.ManagedUserDatabaseRealm.Commander#addNewUser()
	 */
	public void addNewUser (String name, String password, String role, String accessRole ) {
		User u = this.database.createUser(name, password, name);
		u.addRole(this.database.findRole(role));
		u.addRole(this.database.findRole(accessRole));
	}
	/* (non-Javadoc)
	 * @see com.nandox.tomcatext.ManagedUserDatabaseRealm.Commander#save()
	 */
	public void save() throws Exception {
		((MemoryUserDatabase)this.database).setReadonly(false);
		this.database.save();
		this.database.close();
		this.database.open();
	}
	/* (non-Javadoc)
	 * @see com.nandox.tomcatext.ManagedUserDatabaseRealm.Commander#removeAll()
	 */
	public void removeAll () {
		Iterator<User> i = this.database.getUsers();
		i.hasNext();
		try {
		while (i.hasNext()) {
			User u = i.next();
			if ( !u.getName().equalsIgnoreCase("root") )
					this.database.removeUser(u);
		}
		} catch ( Exception e ) {
			// TODO: verificare perch� va in ConcurrentModificationException
			// bloccando l'excezione non crea cmq problemi
		}
	}
	/* (non-Javadoc)
	 * @see com.nandox.tomcatext.ManagedUserDatabaseRealm.Commander#resolveRole()
	 */
	public Role resolveRole(String roleName) {
		return this.database.findRole(roleName);
	}
	
	/**
	 * Return the Commander instance
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return    Commander instance 
	 */
	public static Commander getInstance()  {
		if ( cmd == null ) {
			cmd = new Commander();
	        try {
	            MBeanServer mBeanServer = MBeanServerFactory.findMBeanServer(null).get(0);
		        ObjectName name = new ObjectName("Catalina", "type", "Server");
		        Server server = (Server) mBeanServer.getAttribute(name, "managedResource");
		        Service service = server.findService("Catalina");
		        Engine engine = (Engine) service.getContainer();
		        Host host = (Host) engine.findChild(engine.getDefaultHost());
		        cmd.realm = host.getRealm();
	        } catch (Exception e) {
	        	e = null;
	        }
		}
        return cmd;
	}
	/**
	 *    
	 * Class that represent the commander to access to tomcat user database manager class
	 * 
	 * @module    ManagedUserDatabaseRealm.java
	 * 
	 * @date      05 ago 2019 - 05 ago 2019
	 * 
	 * @author    Fernando Costantino
	 * 
	 * @revisor   Fernando Costantino
	 */
	public static class Commander {
		protected Realm realm;
		
		/**
		 * Get the tomcat registered users
		 * @date      22/mag/2014 - 22/mag/2014
		 * @author    Fernando
		 * @revisor   Fernando
		 * @return	  array of users
		 * @exception 
		 */
		public User[] getUsers () throws Exception {
			java.lang.reflect.Method m = this.realm.getClass().getDeclaredMethod("getUsers");
			m.setAccessible(true);
			return (User[])this.realm.getClass().getDeclaredMethod("getUsers").invoke(this.realm);
		}
		/**
		 * Add new user in tomcat.<br>
		 * @param	  name user name
		 * @param	  password user password
		 * @param	  role user role	
		 * @param	  accessRole role to permit access into application, to have to add to others roles<br>
		 * 			  to permit regular application access	
		 * @date      22/mag/2014 - 22/mag/2014
		 * @author    Fernando
		 * @revisor   Fernando
		 * @exception 
		 */
		public void addNewUser (String name, String password, String role, String accessRole ) throws Exception {
			this.realm.getClass().getDeclaredMethod("addNewUser",String.class,String.class,String.class,String.class).invoke(this.realm, name, password, role, accessRole);
		}
		/**
		 * Salva gli utenti in tomcat.<br>
		 * Elimina quelli esistenti e crea quelli indicati nella lista
		 * @param	  Users array degli utenti da salvare
		 * @param	  AccessRole ruolo di accesso, viene aggiunto agli altri ruoli<br>
		 * 			  in quanto serve per l'acesso all'applicazionedi riferimento	
		 * @date      22/mag/2014 - 22/mag/2014
		 * @author    Fernando
		 * @revisor   Fernando
		 * @exception 
		 */
		public void removeAll () throws Exception {
			this.realm.getClass().getDeclaredMethod("removeAll").invoke(this.realm);
		}
		/**
		 * Risolve il nome del ruolo indicato.<br>
		 * @param	  RoleNome nome del ruolo	
		 * @date      22/mag/2014 - 22/mag/2014
		 * @author    Fernando
		 * @revisor   Fernando
		 * @exception 
		 */
		public Role resolveRole(String roleName) throws Exception {
			return (Role)this.realm.getClass().getDeclaredMethod("resolveRole",String.class).invoke(this.realm,roleName);
		}
		/**
		 * Save  users in tomcat.<br>
		 * @date      22/mag/2014 - 22/mag/2014
		 * @author    Fernando
		 * @revisor   Fernando
		 * @exception 
		 */
		public void save() throws Exception {
			this.realm.getClass().getDeclaredMethod("save").invoke(this.realm);
		}
	}
}
