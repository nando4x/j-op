package com.nandox.libraries;

/**
 * Classe utilizzata per analizzare un'exception 
 * 
 * @project   MagLogConsole
 * 
 * @module    ExceptionAnalyzer.java
 * 
 * @date      01/feb/2012 - 01/feb/2012
 * 
 * @author    Fernando
 * 
 * @revisor   Fernando
 */
public class ExceptionAnalyzer {
	private ExceptionAnalyzer() {
	    throw new IllegalStateException("Utility class");
	}
	/**
	 * Restituisce classi e metodi dello stack, solo  
	 * @param	  e eccezione
	 * @return    Classe e metodi dello stack separati da CR  
	 * @date      01/feb/2012 - 01/feb/2012
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	public static String getErrorStack(Exception e) {
		return getErrorStack(e,null);
	}
	/**
	 * Restituisce classi e metodi dello stack, solo  
	 * @param	  e eccezione
	 * @param	  classOf class 
	 * @return    Classe e metodi dello stack separati da CR  
	 * @date      01/feb/2012 - 01/feb/2012
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	public static String getErrorStack(Exception e, Class<?> classOf) {
		if ( e != null ) {
	    	StackTraceElement[] st = e.getStackTrace();
	    	String s = e.toString()+"\n";
	    	String pk;
	    	if ( classOf==null ) {
	    		pk = ExceptionAnalyzer.class.getPackage().getName();
	    	} else {
	    		pk = classOf.getPackage().getName();
	    	}
			int i1 = pk.indexOf('.');
			i1 = pk.indexOf('.',i1+1);
			pk = pk.substring(0, i1+1);
	    	for ( int ix=0; ix<st.length-1; ix++ ) {
	    		if ( st[ix].getClassName().startsWith(pk) )
	    			s += st[ix].getClassName() + "." + st[ix].getMethodName() + " (line: "+st[ix].getLineNumber()+")\n";
	    	}
			return s;
		}
		return null;
	}
}
