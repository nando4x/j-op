package com.nandox.tomcatext;

import java.security.Principal;

/**
 * Descrizione classe
 * 
 * @project   domuxCenter
 * 
 * @module    JAASRole.java
 * 
 * @date      23 set 2019 - 23 set 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class JAASRole implements Principal {

	private String role;
	
	public JAASRole(String role) {
	    this.role = role;
	}
	/* (non-Javadoc)
	 * @see java.security.Principal#getName()
	 */
	public String getName() {
		return this.role;
	}

}
