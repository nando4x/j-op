package com.nandox.libraries.validation.constraints;

import java.lang.annotation.Documented;
import java.lang.annotation.Target;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import javax.validation.Constraint;
import javax.validation.Payload;

/**
 * Standard Ipv4 Address validation
 * 
 * @project   Libraries (Global libraries)
 * 
 * @module    IpAddress.java
 * 
 * @date      09 apr 2019 - 09 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

@Documented
@Constraint(validatedBy = IpAddressValidator.class)
@Target({ METHOD, FIELD })
@Retention(RUNTIME)
public @interface IpAddress {
    String message() default "Ip address malformed";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
