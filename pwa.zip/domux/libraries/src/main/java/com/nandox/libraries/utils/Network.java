package com.nandox.libraries.utils;

import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;

import org.apache.commons.net.util.SubnetUtils;

import com.nandox.libraries.logging.Logger;

/**
 * Network detection helper to detect own ip address and other
 * 
 * @project   domuxCenter
 * 
 * @module    Network.java
 * 
 * @date      22 nov 2019 - 22 nov 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class Network {

	/**
	 * Return list of ip address of network related to all interfaces 
	 * @param	  monitor	callback to optional momitor
	 * @param	  log	optional logger 
	 * @date      22 nov 2019 - 22 nov 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception
	 * @return	  Array of ip address 
	 */	
	public static String[] getAddressRange (Runnable monitor, Logger log) {
		HashSet<String> range = new HashSet<>();
		try {
			Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
			while ( nets.hasMoreElements() ) {
				NetworkInterface n = nets.nextElement();
				if (log != null) log.debug("detect TCP interface %s, %s, isUp: %s", n.getName(), n.getDisplayName(), ""+n.isUp() );
				if ( !n.isUp() )
					continue;
				boolean skip = false;// = true;
				for ( InterfaceAddress net : n.getInterfaceAddresses() ) {
					if ( !skip && !net.getAddress().isLoopbackAddress() && net.getAddress().getAddress().length == 4 ) {
						try {
							if (log != null) log.debug("register TCP interface address %s", net.toString());
							int len = net.getNetworkPrefixLength();
							SubnetUtils s = new SubnetUtils(net.getAddress().getHostAddress()+"/"+len);
							range.addAll(Arrays.asList(s.getInfo().getAllAddresses()));
						} catch ( Exception e ) {
							if (log != null) log.debug("ERROR registering TCP interface address %s", net.toString());
						}
					} else {
						range.add("127.0.0.1");
					}
				}
			}
		} catch (Exception e) {
			monitor.run();
			if (log != null) log.error("Detect TCP interface error", e);
		}
		return range.toArray(new String[0]);
	}
	/**
	 * Return list of own ip address of all interfaces 
	 * @date      22 nov 2019 - 22 nov 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception
	 * @return	  Array of ip address.<br>
	 * 			  In case of exception the related element contain exception message start with "Exception on" 
	 */	
	public static Address[] getAddressIp (String interfaceName) throws Exception {
		HashSet<Address> range = new HashSet<>();
		Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
		while ( nets.hasMoreElements() ) {
			NetworkInterface n = nets.nextElement();
			if ( !n.isUp() || (interfaceName != null && !interfaceName.isEmpty() && !n.getDisplayName().equals(interfaceName)) )
				continue;
			for ( InterfaceAddress net : n.getInterfaceAddresses() ) {
				if ( !net.getAddress().isLoopbackAddress() && net.getAddress().getAddress().length == 4 ) {
					try {
						range.add(new Address(net.getAddress().getHostAddress(),n.getDisplayName()));
					} catch ( Exception e ) {
						range.add(new Address("Exception on " + net.toString() + " - " + e.getMessage(), null) );
					}
				} else {
					range.add(new Address("127.0.0.1",null));
				}
			}
		}
		return range.toArray(new Address[0]);
	}
	public static class Address {
		final String ip;
		final String interfaceName;
		public Address(String ip, String itfName) {
			this.ip = ip;
			this.interfaceName = itfName;
		}
		/**
		 * @return the ip
		 */
		public String getIp() {
			return ip;
		}
		/**
		 * @return the interfaceName
		 */
		public String getInterfaceName() {
			return interfaceName;
		}
		/* (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object o) {
			return this.ip!=null&&this.ip.equals(((Address)o).ip);
		}
		/* (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			return this.ip.hashCode();
		}
	}
}
