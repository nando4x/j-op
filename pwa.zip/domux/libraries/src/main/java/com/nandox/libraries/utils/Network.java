package com.nandox.libraries.utils;

import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;

import org.apache.commons.net.util.SubnetUtils;

import com.domux.center.monitoring.MonitorEvent;
import com.nandox.libraries.logging.Logger;

/**
 * Descrizione classe
 * 
 * @project   domuxCenter
 * 
 * @module    Network.java
 * 
 * @date      22 nov 2019 - 22 nov 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class Network {

	public static String[] getAddressRange (MonitorEvent monitor, Logger log) {
		HashSet<String> range = new HashSet<String>();
		try {
			Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
			while ( nets.hasMoreElements() ) {
				NetworkInterface n = nets.nextElement();
				log.debug("detect TCP interface %s, %s, isUp: %s", n.getName(), n.getDisplayName(), ""+n.isUp() );
				if ( !n.isUp() )
					continue;
				boolean skip = false;// = true;
				for ( InterfaceAddress net : n.getInterfaceAddresses() ) {
					if ( !skip && !net.getAddress().isLoopbackAddress() && net.getAddress().getAddress().length == 4 ) {
						try {
							log.debug("register TCP interface address %s", net.toString());
							int len = net.getNetworkPrefixLength();
							SubnetUtils s = new SubnetUtils(net.getAddress().getHostAddress()+"/"+len);
							range.addAll(Arrays.asList(s.getInfo().getAllAddresses()));
						} catch ( Exception e ) {
							log.debug("ERROR registering TCP interface address %s", net.toString());
						}
					} else {
						range.add("127.0.0.1");
					}
				}
			}
		} catch (Exception e) {
			monitor.registerEvent(null, MonitorEvent.Type.SYSERROR, "detect TCP interface error");
			log.error("Detect TCP interface error", e);
		}
		return range.toArray(new String[0]);
	}

	public static String[] getAddressIp () throws Exception {
		HashSet<String> range = new HashSet<String>();
		Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
		while ( nets.hasMoreElements() ) {
			NetworkInterface n = nets.nextElement();
			if ( !n.isUp() )
				continue;
			for ( InterfaceAddress net : n.getInterfaceAddresses() ) {
				if ( !net.getAddress().isLoopbackAddress() && net.getAddress().getAddress().length == 4 ) {
					try {
						range.add(net.getAddress().getHostAddress());
					} catch ( Exception e ) {
						range.add("Exception on " + net.toString() + " - " + e.getMessage() );
					}
				} else {
					range.add("127.0.0.1");
				}
			}
		}
		return range.toArray(new String[0]);
	}
}
