package com.nandox.libraries.logging;

import java.util.Formatter;

import com.nandox.libraries.logging.log4j2.Log4j2Logger;
/**
 * Generic logger interface.<p>
 * 
 * @project   Libraries (Global libraries)
 * 
 * @module    Logger.java
 * 
 * @date      19 set 2016 - 19 set 2016
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public interface Logger {
	public enum Provider {
		LOG4J2
	}
	void trace(String msg, String... args);
	void trace(String msg, Throwable ex, String... args);
	boolean isTraceEnabled();

	void debug(String msg, String... args);
	void debug(String msg, Throwable ex, String... args);
	boolean isDebugEnabled();
    
	void info(String msg, String... args);
	void info(String msg, Throwable ex, String... args);
	boolean isInfoEnabled();
    
	void warn(String msg, String... args);
	void warn(String msg, Throwable ex, String... args);
	boolean isWarnEnabled();

	void error(String msg, String... args);
	void error(String msg, Throwable ex, String... args);
	boolean isErrorEnabled();

	void fatal(String msg, String... args);
	void fatal(String msg, Throwable ex, String... args);
	boolean isFatalEnabled();
	
	/**
	 * Utilis class to format messages and others
	 * @date      04 ott 2016 - 04 ott 2016
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public static class Utils {
		private Utils() {
		    throw new IllegalStateException("Utility class");
		}
		/**
		 * Format messages (@see java.util.Formatter)
		 * @param	  msg		message to format
		 * @param	  args		variables arguments as String
		 * @date      04 ott 2016 - 04 ott 2016
		 * @author    Fernando Costantino
		 * @revisor   Fernando Costantino
		 * @return	  formatted string 
		 */
		public static String format(String msg, String... args) {
			return format(msg,(Object[])args);
		}
		/**
		 * Format messages (@see java.util.Formatter)
		 * @param	  msg		message to format
		 * @param	  args		variables arguments as Object
		 * @date      04 ott 2016 - 04 ott 2016
		 * @author    Fernando Costantino
		 * @revisor   Fernando Costantino
		 * @return	  formatted string 
		 */
		public static String format(String msg, Object[] args) {
			Formatter fm = new Formatter();
			String s = fm.format(msg, args).toString();
			fm.close();
			return s;
		}
	}
	/**
	 * Logger factory
	 * @date      04 ott 2016 - 04 ott 2016
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public static class Factory {
		private Factory() {
		    throw new IllegalStateException("Utility class");
		}
		/**
		 * Create logger for a specific class with default provider LOG4J 
		 * @param	  clazz		class to log
		 * @date      04 ott 2016 - 04 ott 2016
		 * @author    Fernando Costantino
		 * @revisor   Fernando Costantino
		 * @return	  a new logger 
		 */
		public static Logger getLogger(Class<?> clazz) {
			return getLogger(Provider.LOG4J2, clazz);
		}
		/**
		 * Create logger for a specific class with a passed provider
		 * @param	  provider	logger provider (one of enum Provider) 
		 * @param	  clazz		class to log
		 * @date      04 ott 2016 - 04 ott 2016
		 * @author    Fernando Costantino
		 * @revisor   Fernando Costantino
		 * @return	  a new logger 
		 */
		public static Logger getLogger(Provider provider, Class<?> clazz) {
			switch (provider) {
				default:
					return Log4j2Logger.create(clazz);
			}
		}
	}
}
