package com.nandox.tomcatext;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;
import java.security.KeyStore;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.Server;
import org.apache.catalina.Service;
/**
 * Class to manage tomcat native connectors (server.xml file).<br>
 * To access to this class from your application you must use the Commander class<br>
 * (got by getInstance static method) and this class directly. With Commnader is possible
 * to get Connectors list
 *  
 * @project   domuxCenter
 * 
 * @module    ManagedUserDatabaseRealm.java
 * 
 * @date      05 ago 2019 - 05 ago 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class ManagedConnector {
	private static Commander cmd = null;
	private Connector current;

	/**
	 * Return the Commander instance
	 * @param	  index	connector index to use
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return    Commander instance 
	 */
	public void setCurrentConnector (int index) throws Exception {
		Connector[] conns = getInstance().geConnectors();
		if ( index < conns.length )
			this.current = conns[index];
	}
	/**
	 * Return the number of connectors
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return    connectors number
	 * @exception  
	 */
	public int getConnectorsSize() throws Exception {
		return getInstance().geConnectors().length;
	}
	/**
	 * Return the keystore of connector
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return    keystore associated to connector or null 
	 * @exception the same of {@link java.security.KeyStore#load(java.io.InputStream, char[])}
	 */
	public KeyStore getKeyStore() throws Exception {
		String fname = (String)this.current.getAttribute("keystoreFile");
		if ( fname != null && !fname.isEmpty() ) {
			KeyStore ks = KeyStore.getInstance("pkcs12");

		    // get user password and file input stream
		    String password = (String)this.current.getAttribute("keystorePass");

		    java.io.FileInputStream fis = null;
		    try {
		        fis = new java.io.FileInputStream(fname);
		        ks.load(fis, password.toCharArray());
		    } finally {
		        if (fis != null) {
		            fis.close();
		        }
		    }
		    return ks;
		}
		return null;
	}
	/**
	 * Return an attribute of connectors
	 * @param	  index	connector index to use
	 * @param	  name	attribute name
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return    connectors number 
	 */
	public String getAttribute(int index, String name) throws Exception {
		Connector[] conns = getInstance().geConnectors();
		if ( index < conns.length ) {
			return (String)conns[index].getAttribute(name);
		}
		return null;
	}
	/**
	 * Return the Commander instance
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return    Commander instance 
	 */
	public static Commander getInstance()  {
		if ( cmd == null ) {
			cmd = new Commander();
	        try {
	            MBeanServer mBeanServer = MBeanServerFactory.findMBeanServer(null).get(0);
		        ObjectName name = new ObjectName("Catalina", "type", "Server");
		        Server server = (Server) mBeanServer.getAttribute(name, "managedResource");
		        cmd.service = server.findService("Catalina");
	        } catch (Exception e) {
	        	e = null;
	        }
		}
        return cmd;
	}
	/**
	 *    
	 * Class that represent the commander to access to tomcat connectors
	 * 
	 * @module    ManagedUserDatabaseRealm.java
	 * 
	 * @date      05 ago 2019 - 05 ago 2019
	 * 
	 * @author    Fernando Costantino
	 * 
	 * @revisor   Fernando Costantino
	 */
	public static class Commander {
		protected Service service;
		
		/**
		 * Get the tomcat connectors
		 * @date      22/mag/2014 - 22/mag/2014
		 * @author    Fernando
		 * @revisor   Fernando
		 * @return	  array of users
		 * @exception 
		 */
		public Connector[] geConnectors () throws Exception {
			return (Connector[])this.service.getClass().getDeclaredMethod("findConnectors").invoke(this.service);
		}
	}
}
