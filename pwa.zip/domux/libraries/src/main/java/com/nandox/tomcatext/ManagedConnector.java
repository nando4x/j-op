package com.nandox.tomcatext;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;

import java.net.Inet4Address;
import java.security.KeyStore;
import org.apache.catalina.connector.Connector;

import com.nandox.libraries.logging.Logger;

import org.apache.catalina.Server;
import org.apache.catalina.Service;
import org.apache.catalina.LifecycleEvent;
import org.apache.catalina.LifecycleListener;
import org.apache.catalina.LifecycleState;
/**
 * Class to manage tomcat native connectors (server.xml file).<br>
 * To access to this class from your application you must use the Commander class<br>
 * (got by getInstance static method) and this class directly. With Commnader is possible
 * to get Connectors list
 *  
 * @project   domuxCenter
 * 
 * @module    ManagedUserDatabaseRealm.java
 * 
 * @date      05 ago 2019 - 05 ago 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class ManagedConnector implements LifecycleListener {
	private static Commander cmd = null;
	private Connector current;
	private Logger logger;
	private Thread monitor;
	
	/**
	 * Complete constructor
	 * @param	  logger optional logger
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public ManagedConnector(Logger logger) {
		this.logger = logger;
	}
	/**
	 * Set Connector identify by index position as curent connector
	 * @param	  index	connector index to use
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @exception @link {org.apache.catalina.Service#findConnectors()}   
	 */
	public void setCurrentConnector (int index) throws Exception {
		Connector[] conns = getInstance().geConnectors();
		if ( index < conns.length )
			this.current = conns[index];
	}
	/**
	 * Return the number of connectors
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return    connectors number
	 * @exception  
	 */
	public int getConnectorsSize() throws Exception {
		return getInstance().geConnectors().length;
	}
	/**
	 * Return the keystore of connector using file and password defined on Connector (in server.xml)
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return    keystore associated to connector or null 
	 * @exception the same of {@link java.security.KeyStore#load(java.io.InputStream, char[])}
	 */
	public KeyStore getKeyStore() throws Exception {
		String fname = (String)this.current.getAttribute("keystoreFile");
		if ( fname != null && !fname.isEmpty() ) {
			KeyStore ks = KeyStore.getInstance("pkcs12");

		    // get user password and file input stream
		    String password = (String)this.current.getAttribute("keystorePass");

		    java.io.FileInputStream fis = null;
		    try {
		        fis = new java.io.FileInputStream(fname);
		        ks.load(fis, password.toCharArray());
		    } finally {
		        if (fis != null) {
		            fis.close();
		        }
		    }
		    return ks;
		}
		return null;
	}
	/**
	 * Return an attribute of connectors
	 * @param	  index	connector index to use
	 * @param	  name	attribute name
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return    atribute value
	 * @exception @link {org.apache.catalina.Service#findConnectors()}   
	 * @exception @link {org.apache.catalina.connector.Connector#getAttribute(String)}   
	 */
	public Object getAttribute(int index, String name) throws Exception {
		Connector[] conns = getInstance().geConnectors();
		if ( index < conns.length ) {
			return conns[index].getAttribute(name);
		}
		return null;
	}
	/**
	 * Set an attribute of connectors
	 * @param	  index	connector index to use
	 * @param	  name	attribute name
	 * @param	  data	attribute value
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @exception @link {org.apache.catalina.Service#findConnectors()}   
	 * @exception @link {org.apache.catalina.connector.Connector#setAttribute(String,Object)}   
	 */
	public void setAttribute(int index, String name, Object data) throws Exception {
		Connector[] conns = getInstance().geConnectors();
		if ( index < conns.length ) {
			conns[index].setAttribute(name, data);
		}
	}
	/**
	 * Restart current Connector with new listener ip address.<br>
	 * Use Lifecycle event to wait effective stop, if not restart after 20 sec log a timeout error
	 * @param	  ip	new listener ip address
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @exception @link {org.apache.catalina.Service#findConnectors()}   
	 * @exception @link {org.apache.catalina.connector.Connector#setAttribute(String,Object)}   
	 */
	public void restartCurrentConnector(String ip) throws Exception {
		boolean flg = this.current.getState() == LifecycleState.STARTED;
		if ( flg ) {
			this.current.addLifecycleListener(this);
			this.current.stop();
		}
		this.current.setAttribute( "address", ip);
		if ( flg ) {
			final ManagedConnector _this = this;
			this.monitor = new Thread() {
				public void run() {
					try {
						int cnt = 20 * 10;
						do {
							Thread.sleep(100);
							cnt--;
						} while ( cnt > 0 && _this.monitor != null );
						if ( _this.logger != null && _this.monitor != null )
							_this.logger.error("Restart Connector timeout");
					} catch (Exception e) {
						if ( _this.logger != null )
							_this.logger.error("Error on Connector monitor thread", e);
					}
				}
			};
			this.monitor.start();
		}
	}
	
	/* on before_stop event start again the connector, eventually errors are logged in logger (if defined)
	 * @see org.apache.catalina.LifecycleListener
	 */
	@Override
	public void lifecycleEvent(LifecycleEvent event) {
		if ( event.getType() == "stop" ) {
			try {
				final ManagedConnector _this = this;
				final LifecycleEvent _event = event;
				Thread th = new Thread() {
					public void run() {
						try {
							_event.getLifecycle().start();
							_this.monitor = null;
							_event.getLifecycle().removeLifecycleListener(_this);
						} catch (Exception e) {
							if ( _this.logger != null )
								_this.logger.error("Error on restart Connector", e);
						}
					}
				};
				th.start();
			} catch (Exception e) {
				if ( this.logger != null )
					this.logger.error("Error on Thread \"restart Connector\"", e);
			}
		}
	}
	/**
	 * Return the Commander instance
	 * @date      22/mag/2014 - 22/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return    Commander instance 
	 */
	public static Commander getInstance()  {
		if ( cmd == null ) {
			cmd = new Commander();
	        try {
	            MBeanServer mBeanServer = MBeanServerFactory.findMBeanServer(null).get(0);
		        ObjectName name = new ObjectName("Catalina", "type", "Server");
		        Server server = cmd.server = (Server) mBeanServer.getAttribute(name, "managedResource");
		        cmd.service = server.findService("Catalina");
	        } catch (Exception e) {
	        	e = null;
	        }
		}
        return cmd;
	}
	
	/**
	 *    
	 * Class that represent the commander to access to tomcat connectors
	 * 
	 * @module    ManagedUserDatabaseRealm.java
	 * 
	 * @date      05 ago 2019 - 05 ago 2019
	 * 
	 * @author    Fernando Costantino
	 * 
	 * @revisor   Fernando Costantino
	 */
	public static class Commander {
		protected Service service;
		protected Server server;
		
		/**
		 * Get the tomcat connectors
		 * @date      22/mag/2014 - 22/mag/2014
		 * @author    Fernando
		 * @revisor   Fernando
		 * @return	  array of users
		 * @exception @link {org.apache.catalina.Service#findConnectors()}   
		 */
		public Connector[] geConnectors () throws Exception {
			return (Connector[])this.service.getClass().getDeclaredMethod("findConnectors").invoke(this.service);
		}
	}
}
