package com.nandox.libraries.validation.constraints;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Validator for Ip address.<br>
 * Check if address is IPV4 (x.x.x.x)
 * 
 * @project   Libraries (Global libraries)
 * 
 * @module    IpAddressValidator.java
 * 
 * @date      09 apr 2019 - 09 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class IpAddressValidator implements ConstraintValidator<IpAddress, String> {

	/* (non-Javadoc)
	 * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.Annotation)
	 */
	public void initialize(IpAddress addrIP) {
		//
	}
	/* (non-Javadoc)
	 * @see javax.validation.ConstraintValidator#isValid(java.lang.Object, javax.validation.ConstraintValidatorContext)
	 */
	public boolean isValid(String addrIP, ConstraintValidatorContext ctx) {
		if (addrIP == null || addrIP.isEmpty())
			return true;
	    String ip = addrIP.trim();
	    try {
	        Pattern pattern = Pattern.compile("^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
	        Matcher matcher = pattern.matcher(ip);
	        return matcher.matches();
	    } catch (PatternSyntaxException ex) {
	        return false;
	    }
	}

}
