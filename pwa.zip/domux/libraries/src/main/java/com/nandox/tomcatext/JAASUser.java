package com.nandox.tomcatext;

import java.security.Principal;

/**
 * Descrizione classe
 * 
 * @project   domuxCenter
 * 
 * @module    JAASUser.java
 * 
 * @date      23 set 2019 - 23 set 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class JAASUser implements Principal {

	private String username;
	public JAASUser(String username) {
	    this.username = username;
	}
	/* (non-Javadoc)
	 * @see java.security.Principal#getName()
	 */
	public String getName() {
		// TODO Auto-generated method stub
		return this.username;
	}

}
