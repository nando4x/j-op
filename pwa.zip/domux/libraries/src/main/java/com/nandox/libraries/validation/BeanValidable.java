package com.nandox.libraries.validation;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.validation.ValidatorFactory;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ConstraintViolation;
/**
 * Validable Bean permit to validate a bean using standard javax.validation 
 * 
 * @project   Libraries (Global libraries)
 * 
 * @module    BeanValidable.java
 * 
 * @date      09 apr 2019 - 09 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public abstract class BeanValidable {

	/**
	 * Validate all bean's properties with relative annotations
	 * @param	  args dynamic arguments for groups validate
	 * @date      30 mar 2019 - 30 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  map whit property name and not validate message
	 */
	public Map<String,String> validate(Class<?>...args) {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<BeanValidable>> violations = validator.validate(this,args);
		Map<String,String> ret = new HashMap<String,String>();
		for ( ConstraintViolation<BeanValidable> v: violations ) {
			ret.put(v.getPropertyPath().toString(), v.getMessage());
		}
		return ret;
	}
}
