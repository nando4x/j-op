package com.domux.center.logging;

import com.nandox.libraries.logging.Logger;

/**
 * Base abstract logger to use for every class
 * 
 * @project   domuxCenter
 * 
 * @module    XmlContainer.java
 * 
 * @date      02 apr 2019 - 02 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public abstract class BaseLogger {
	/** logger */
	protected final Logger log;
	
	/**
	 * Constructor: create logger using a Factory by sub class
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	public BaseLogger() {
		log = Logger.Factory.getLogger(this.getClass());
	}
	/**
	 * @return the log
	 */
	public Logger getLog() {
		return log;
	}
}
