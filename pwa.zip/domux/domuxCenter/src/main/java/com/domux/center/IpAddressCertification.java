package com.domux.center;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

import com.domux.center.logging.BaseLogger;
import com.google.gson.Gson;
import com.nandox.libraries.utils.Network;
import com.nandox.tomcatext.ManagedConnector;

/**
 * Descrizione classe
 * 
 * @project   domuxCenter
 * 
 * @module    Network.java
 * 
 * @date      22 nov 2019 - 22 nov 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public class IpAddressCertification extends BaseLogger {

	public enum TypeIp {
		/** ip address of local interfaces */
		LOCAL,
		/** ip address of public access */
		PUBLIC
	}

	private static final String LOCALE_CERT_FILE = "localip.p12";
	private static final String PUBLIC_CERT_FILE = "publicip.p12";
	private static String inetCachedIP;
	private String mkcertCmd;
	private String detectInetIPUrl;
	private ManagedConnector mc;
	/**
	 * Complete constructor
	 * @param     mkCertCmd complete pathnameo f System command to generate new certificate 
	 * @param	  detectInetIPUrl url to rest for detect public ip
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public IpAddressCertification(String mkCertCmd, String detectInetIPUrl) {
		this.mkcertCmd = mkCertCmd;
		this.detectInetIPUrl = detectInetIPUrl;
		mc = new ManagedConnector(log);
	}
	/**
	 * Check if ip address is changed respect property address of each SSL tomcat connector
	 * @param	  type type of ip address (local or public)
	 * @date      22 nov 2019 - 22 nov 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception {@link com.nandox.tomcatext.ManagedConnector#getConnectorsSize()}
	 * @exception {@link com.nandox.tomcatext.ManagedConnector#getAttribute(int, String)}
	 * @exception {@link com.nandox.libraries.utils.Network#getAddressIp(String)}
	 * @return	  true if some connector address corresponds to some ip address interface
	 */	
	public boolean checkIfIpChanged(TypeIp type) throws Exception {
		int sz = mc.getConnectorsSize();
		String fip = null;
		List<Network.Address> ips = null;
		if ( type == TypeIp.LOCAL ) {
			fip = "/"+LOCALE_CERT_FILE;
			ips =  Arrays.asList(Network.getAddressIp(null));
		} else {
			fip = "/"+PUBLIC_CERT_FILE;
			ips = new ArrayList<>();
			ips.add(new Network.Address(getInetIP(this.detectInetIPUrl), null));
		}
		for ( int ix=0; ix < sz; ix++ ) {
			String fname = (String)mc.getAttribute(ix, "keystoreFile");
			if ( fname != null && fname.endsWith(fip) ) {
				Inet4Address ip4 = (Inet4Address)mc.getAttribute(ix, "address");
				String ip = (ip4!=null?ip4.getHostAddress():"");
				this.log.debug("checking Connector %s", ip);
				if ( ips.contains( new Network.Address(ip,null) ) ) 
					return false;
				break;
			}
		}
		return true;
	}
	
	/**
	 * Update crtificate and relative tomcat Connector with ip address of specified interface 
	 * @param	  type type of ip address (local or public)
	 * @param	  itfName descriptive name of interface for local
	 * @date      22 nov 2019 - 22 nov 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception {@link com.nandox.tomcatext.ManagedConnector#getConnectorsSize()}
	 * @exception {@link com.nandox.tomcatext.ManagedConnector#getAttribute(int, String)}
	 * @exception {@link com.nandox.libraries.utils.Network#getAddressIp(String)}
	 * @exception {@link com.nandox.tomcatext.ManagedConnector#setCurrentConnector(int)}
	 * @exception {@link com.nandox.tomcatext.ManagedConnector#restartCurrentConnector(String)}
	 * @exception {@link com.nandox.tomcatext.ManagedConnector#getAttribute(int, String)}
	 * @exception {@link Runtime#exec(String)}
	 */	
	public void updateCertificate(TypeIp type, String itfName) throws Exception {
		String fip = null;
		Network.Address[] ips = null;
		if ( type == TypeIp.LOCAL ) {
			fip = "/"+LOCALE_CERT_FILE;
			ips =  Network.getAddressIp(itfName);
		} else {
			fip = "/"+PUBLIC_CERT_FILE;
			ips = new Network.Address[1];
			ips[0] = new Network.Address(inetCachedIP, null);
		}
		int sz = mc.getConnectorsSize();
		for ( int ix=0; ix < sz; ix++ ) {
			String fname = (String)mc.getAttribute(ix, "keystoreFile");
			if ( fname != null && fname.endsWith(fip) ) {
				this.log.debug("recertify Connector to new ip: %s", ips[0].getIp());
				mc.setCurrentConnector(ix);
				File f = new File(fname);
				this.log.debug("execute make certificate command...");
				Process p = Runtime.getRuntime().exec(this.mkcertCmd +" "+ ips[0].getIp() + " -ip -out " + f.getAbsolutePath());
				BufferedReader stdIn = new BufferedReader(new InputStreamReader(p.getInputStream()));
				p.waitFor();
				String s = null;
				while ( ( s = stdIn.readLine() ) != null ) {
					this.log.debug(s);
				}
				this.log.debug("restart connector...");
				mc.restartCurrentConnector(ips[0].getIp());
			}
		}
	}
	/**
	 * Return Internet ip address using a public site with rest json.<br>
	 * Every call of this method cache the last ip detected, the can be get the cached with getCachedInteIP 
	 * @param	  detectInetIPUrl complete url of site to use
	 * @date      22 nov 2019 - 22 nov 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  ip address as string
	 * @exception {@link java.net.URL}
	 * @exception {@link java.net.URL#openConnection()}
	 * @exception {@link javax.net.ssl.HttpsURLConnection#getInputStream()}
	 * @exception {@link java.io.BufferedReader#read()}
	 */
	static public String getInetIP(String detectInetIPUrl) throws Exception {
		InputStream in = null;
		try {
			URL url = new URL(detectInetIPUrl);
			HttpsURLConnection https = (HttpsURLConnection)url.openConnection();
			in = https.getInputStream();
			BufferedReader data = new BufferedReader(new InputStreamReader(in));
			String s = "";
			int ch;
			while ( ( ch = data.read()) != -1 )
				s += (char)ch;
			Gson jsonMng = new Gson();
			Map<String,String> json = jsonMng.fromJson(s,Map.class);
			return (inetCachedIP = json.get("ip"));
		} finally {
			if ( in != null )
				in.close();	
		}
	}
	/**
	 * Return last Internet ip address detected
	 * @param	  detectInetIPUrl complete url of site to use
	 * @date      22 nov 2019 - 22 nov 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  ip address as string
	 */
	static public String getCachedInetIP() {
		return inetCachedIP;
	}
}
