package com.domux.center;

public class IpAddressCertification {

	public enum TypeIp {
		LOCALE,
		PUBLIC
	}
	
	public IpAddressCertification() {
		
	}
	
	public boolean checkIfIpChanged(TypeIp ip) {
		return false;
	}
}
