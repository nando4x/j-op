package com.domux.center.monitoring;

import java.util.Calendar;
import java.util.Iterator;
import java.util.Map.Entry;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;

import com.nandox.libraries.utils.Reflection;

public class MonitorEventImpl implements MonitorEvent, MonitorManager {

	static private final int MAX_EVENTS_RETURNED = 100;
	private LinkedList<MonitorEvent.EventData> events = new LinkedList<MonitorEvent.EventData>();
	private String pathStore;
	private int minQueueSizeRetention;
	private int totalConnections;
	private int totalErrorConnections;
	private int dailyErrorConnections;
	private Calendar toDay;
	private boolean runThread = true;
	
	/**
	 * Constructor
	 * @param	  pathStore	absolute pathname of file to store events
	 * @date      02 apr 2019 - 02 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public MonitorEventImpl(String pathStore, final int queueSizeRetention, final int queueFrequencyStore, int minQueueSizeRetention) {
		this.pathStore = pathStore;
		this.minQueueSizeRetention = minQueueSizeRetention;
		this.toDay = Calendar.getInstance();
		this.toDay.set(Calendar.HOUR, 23);
		this.toDay.set(Calendar.MINUTE, 59);
		this.toDay.set(Calendar.SECOND, 59);
		this.toDay.set(Calendar.MILLISECOND, 999);
		// start thread for cyclic store events by frequency (in seconds) or queue size
		final MonitorEventImpl m = this;
		new Thread(new Runnable() {
            public void run() {
            	Calendar c = Calendar.getInstance();
            	c.add(Calendar.SECOND, queueFrequencyStore);
            	while (m.runThread) {
	            	try {
	            		if (c.before(Calendar.getInstance()) || m.events.size() >= queueSizeRetention ) {
		                    m.storeEvents();
		                    c.add(Calendar.SECOND, queueFrequencyStore);
	            		}
		                Thread.sleep(2000);
	            	} catch (Exception e) {	}
            	}
            }
        }).start();
	}
	/* (non-Javadoc)
	 * @see com.domux.center.logging.MonitorEvent#registerEvent(java.lang.Integer, com.domux.center.logging.MonitorEvent.Type, java.lang.String, java.lang.Object, java.lang.Object)
	 */
	public int registerEvent(Integer transId, Type type, String message, Monitorable target, Object data) {
		String cl = Reflection.getCallerClass(this.getClass());
		//System.out.println("MONITORING: "+type+" - " + message + " - "  + target +" - " + data + " - " + cl);
		MonitorEvent.EventData e = new MonitorEvent.EventData();
		e.time = java.util.Calendar.getInstance();
		e.type = type;
		e.message = message;
		e.target = target;
		e.data = data;
		e.callerClassName = cl;
		e.transId = (transId!=null?transId:(""+e.time.getTime().getTime()+
						(e.type!=null?e.type.name():"")+
						(e.message!=null?e.message:"")+
						(e.target!=null?e.target.getClassifyData().toString():"")
						).hashCode());
		synchronized (this.events) {
			this.events.offer(e);
		}
		if ( type == Type.NETWORK || type == Type.NETWORKERROR ) {
			this.totalConnections += (transId==null&&type==Type.NETWORK?1:0);
			if ( type==Type.NETWORKERROR ) {
				if ( e.time.after(this.toDay) ) {
					this.dailyErrorConnections = 0;
					this.toDay.add(Calendar.DATE, 1);
				}
				this.totalErrorConnections++;
				this.dailyErrorConnections++;
			}
		}
		return e.transId;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.logging.MonitorEvent#registerEvent(java.lang.Integer, com.domux.center.logging.MonitorEvent.Type, java.lang.String, java.lang.Object)
	 */
	public int registerEvent(Integer transId, Type type, String message, Monitorable target) {
		return this.registerEvent(transId, type, message, target, null);
	}
	/* (non-Javadoc)
	 * @see com.domux.center.logging.MonitorEvent#registerEvent(java.lang.Integer, com.domux.center.logging.MonitorEvent.Type, java.lang.String)
	 */
	public int registerEvent(Integer transId, Type type, String message) {
		return this.registerEvent(transId, type, message, null, null);
	}
	/* (non-Javadoc)
	 * @see com.domux.center.logging.MonitorEventReader#searchLastByType(com.domux.center.logging.MonitorEvent.Type[])
	 */
	public List<EventData> searchLastByType(Type[] types) {
		ArrayList<EventData> list = new ArrayList<EventData>();
		List<Type> tl = Arrays.asList(types);
		int cnt=0;
		LinkedList<EventData> queue = this.checkpoint(null);
		Iterator<EventData> it = queue.descendingIterator();
		while ( it.hasNext() && cnt < MAX_EVENTS_RETURNED ) {
			EventData e = it.next();
			if ( tl.contains(e.type) ) {
				list.add(e);
				cnt++;
			}
		}
		this.checkpoint(queue);		
		return list;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.monitoring.MonitorManager#getTotalConnections()
	 */
	public int getTotalConnections() {
		return this.totalConnections;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.monitoring.MonitorManager#getTotalErrorConnections()
	 */
	public int getTotalErrorConnections() {
		return this.totalErrorConnections;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.monitoring.MonitorManager#getDailyErrorConnections()
	 */
	public int getDailyErrorConnections() {
		return this.dailyErrorConnections;
	}
	/**
	 * Store event queue to file and clear the queue
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	protected void storeEvents() {
		LinkedList<EventData> queue = this.checkpoint(null);
		EventData e;
		FileOutputStream fo = null;
		try {
			fo = new FileOutputStream(this.pathStore, false);
			while ((e = queue.pop()) != null && queue.size() > this.minQueueSizeRetention) {
				String data = this.serializeEvent(e);
				fo.write(data.getBytes());
			}
			synchronized (this.events) {
				this.events.addAll(0, queue);
			}
		} catch (Exception ex) {
			// rollback
			this.checkpoint(queue);
		} finally {
			if ( fo != null )
				try { fo.close(); } catch (Exception ex) {} 
		}
	}
	//
	//
	//
	private LinkedList<EventData> checkpoint(LinkedList<EventData> tomerge) {
		LinkedList<EventData> ret = null;
		synchronized (this.events) {
			if ( tomerge != null ) {
				tomerge.addAll(this.events);
				ret = this.events = tomerge;
			} else {
				ret = this.events;
				this.events = new LinkedList<EventData>(); 
			}
		}
		return ret;
	}
	//
	//
	//
	private String serializeEvent(EventData event) {
		String ret, sep = "^";
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		ret = df.format(event.time.getTime()) + sep;
		ret += event.type.name() + sep;
		ret += event.transId + sep;
		for ( Entry<Monitorable.ClassifyKey,String>c :  event.target.getClassifyData().entrySet() ) {
			ret += c.getKey().name() + ":" + c.getValue() + ",";
		}
		ret += event.message + sep;
		ret += event.data.toString() + sep;
		ret += event.callerClassName;
		return ret.replace("\r", "\\r").replace("\n", "\\n") + '\r';
	}
	public void shutdown() {
		this.runThread = false;
	}
}
