package com.domux.center.services.restful;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.ws.rs.core.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.domux.center.devices.nodes.NodeFactory;
import com.domux.center.model.*;
import com.nandox.libraries.ErrorGroupMarker;
import com.domux.center.Labels;
import com.domux.center.ControlCenter;
import com.domux.center.database.DomuxDataBase;

/**
 * Node restful operation controller to get nodes list, save a node changes, write a resource value<br> 
 * 
 * @project   domuxCenter
 * 
 * @module    NodeService.java
 * 
 * @date      01 apr 2019 - 01 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", allowCredentials="true")
public class NodeService extends AbstarctJsendService {
	@ErrorGroupMarker(-2000)
	public enum Error {
		/** Error code database not ready */
		RET_ERR_DBNOTREADY,
		/** Error code saving data into database */
		RET_ERR_SAVINGNODE,
		/** Error code deleting data from database */
		RET_ERR_DELETINGNODE,
		/** Error code discovery nodes */
		RET_ERR_DISCOVERY,
		/** Error code setting resoruce value */
		RET_ERR_SETRESOURCE
	}

	@Autowired
	@Qualifier("db")
	private DomuxDataBase db;
	@Autowired
	@Qualifier("controlCenter")
	private ControlCenter cCenter;

	/**
	 * getnodelist service: return to complete nodes list.<br>
	 * Response with this jsend data:
	 * 		{
	 *			nodelist:[
	 *		       {dxid: number,
	 *		        id: string,
	 *		        type: string,
	 *		        status: string,
	 *		        addrI2C: string,
	 *		        addrBT: string,
	 *		        addrIP: string,
	 *		        capabilities: {
	 *		        	hasI2C: boolean,
	 *		        	hasBT: boolean,
	 *		        	hasIP: boolean
     *		        },
	 *	        	resourceList: [
	 *	        	   {dxid: string, id: string, name: string, type: string, value: object},
	 *	        	]
	 *		       }
	 *	 		]
	 *		}
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response as String
	 */
	@GetMapping(path = "/getnodelist",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String getNodeList () {
		try {
			ArrayList<Node> nodes = new ArrayList<Node>(db.getNodes().values());
			nodes.addAll(cCenter.getUnregistered());
			HashMap<String,ArrayList<Node>> nodelist = new HashMap<String,ArrayList<Node>>();
			nodelist.put("nodelist", nodes);
			return this.responseSuccess(this.toJsonTree(nodelist));
		} catch (Exception e) {
			this.log.error("Database not ready or not inizialized", e);
			return this.responseError(Error.RET_ERR_DBNOTREADY,e);
		}
	}
	/**
	 * sendnode service: receive node data and save it on database and physical device<br>
	 * Expect this request:
	 * 		{
	 *		     dxid: string,
	 *		     name: string,
	 *		     type: string,
	 *		     addrI2C: string,
	 *		     addrBT: string,
	 *		     addrIP: string,
	 *	         resourceList: [
	 *	        	   {dxid: string, id: string, name: string, type: string},
	 *	         ]
	 *		}
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response (with no data) as String
	 */
	@PostMapping(path = "/sendnode",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String sendNode (@RequestBody String json) {
		boolean saved = false;
		Node node = null;
		try {
			// Transform request json to node and adapt resource value to specific own class
			node = this.fromJson(json, Node.class);
			Class<?> resVal = NodeFactory.getResourceClass(node.getType());
			for ( Resource r : node.getResourceList() ) {
				Object o = this.fromJson(this.toJsonTree(r.getValue()), resVal);
				r.setValue(o);
			}
			// Validate data
			Map<String,String> data = node.validate();
			if ( data.size() > 0 ) {
				this.log.warn("invalid data on saving node id: %s, fields: %s", node.getName(), data.keySet().toString());
				return this.responseFail(this.toJsonTree(data));
			}
			// check if is duplicated
			Node n = db.searchNodeByName(node.getName());
			if ( n != null && !n.getDxid().equals(node.getDxid()) ) {
				data.clear();
				data.put("name", Labels.ERROR_FIELD_NODE_DUPLICATED);
				this.log.warn("duplicated on saving node name: %s", node.getName());
				return this.responseFail(this.toJsonTree(data));
			}
			// Save node configuration into device
			this.cCenter.saveOnDevice(node);
			saved = true;
			// Save node into database
			synchronized(node) { // to permit atomic operation on node
				db.saveNode(node);
				// if need remove node from unregisters
				if ( node.getStatus() == Node.Status.UNREGISTERED ) {
					n = this.cCenter.searchUnregisterByDxID(node.getDxid());
					if ( n != null ) {
						this.cCenter.getUnregistered().remove(n);
						node.setStatus(Node.Status.REGISTERED);
					}
				}
			}
			return this.responseSuccess(this.toJsonTree(node));
		} catch (Exception e) {
			if ( saved && node != null ) {
				this.cCenter.rollbackOnDevice(node);
				this.log.info("Rollback node saving");
			}
			this.log.error("Error on saving node", e);
			return this.responseError(Error.RET_ERR_SAVINGNODE, e);
		}
	}

	/**
	 * deletenode service: delete node from database by dxid<br>
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response (with no data) as String
	 */
	@PostMapping(path = "/deletenode",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String deleteNode (@RequestBody String json) {
		try {
			String id = this.fromJson(json, String.class);
			Map<String,String> fail = new HashMap<String,String>();
			Node n = this.db.searchNodeByDxID(id);
			if ( n != null && n.getStatus() == Node.Status.UNREGISTERED ) {
				fail.put(id, Labels.ERROR_NODE_NOTDELETABLE);
				return this.responseFail(this.toJsonTree(fail));
			}
			if ( !this.cCenter.deleteNodeFromDataBase(id) ) {
				fail.put(id, Labels.ERROR_NODE_NOTFOUND);
				return this.responseFail(this.toJsonTree(fail));
			}
			return this.responseSuccess(null);
		} catch (Exception e) {
			this.log.error("Error on delete node", e);
			return this.responseError(Error.RET_ERR_DELETINGNODE, e);
		}
	}
	/**
	 * discovery service: discovery nodes<br>
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response (with no data) as String
	 */
	@GetMapping(path = "/discovery",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String discoveryNode () {
		try {
			this.cCenter.discoveryNodes();
			return this.getNodeList();
		} catch (Exception e) {
			this.log.error("Discovery node close with errors", e);
			return this.responseError(Error.RET_ERR_DISCOVERY, e);
		}
	}
	/**
	 * sendresource service: receive resource data and set value to physical device<br>
	 * Expect this request:
	 * 		{
	 *		     dxid: string,
	 *		     id: string,
	 *		     name: string,
	 *		     type: string,
	 *		     value: object
	 *		}
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response (with new resource value) as String
	 */
	@PostMapping(path = "/sendresource",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String sendResource (@RequestBody String json) {
		Resource res = null;
		try {
			Map<String,String> fail = new HashMap<String,String>();
			res = this.fromJson(json, Resource.class);
			// Validate data
			if ( res.getDxid().split("[.]").length <= 1 ) {
				fail.put("dxid", Labels.ERROR_FIELD_RESOURCE_NOTFOUND);
				return this.responseFail(this.toJsonTree(fail));
			}
			String dxid = res.getDxid().split("[.]")[0];
			// get node from database or unregister
			Node n = this.db.searchNodeByDxID(dxid);
			if ( n == null ) {
				n = this.cCenter.searchUnregisterByDxID(dxid);
			}
			if ( n == null ) {
				fail.put("dxid", Labels.ERROR_NODE_NOTFOUND);
				return this.responseFail(this.toJsonTree(fail));
			}
			Class<?> rcl = NodeFactory.getResourceClass(n.getType());
			res.setValue(this.fromJson(this.toJsonTree(res.getValue()),rcl));
			res = this.cCenter.writeResourceValueOnDevice(n, res);
			// update node resource value
			n.getResourceById(res.getId()).setValue(res.getValue());
			return this.responseSuccess(this.toJsonTree(res));
		} catch (Exception e) {
			this.log.error("Error on setting resource value", e);
			return this.responseError(Error.RET_ERR_SETRESOURCE, e);
		}
	}
}
