package com.domux.center.model;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlElementWrapper;
//import javax.xml.bind.annotation.XmlSchemaType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.validation.constraints.Pattern;

import com.domux.center.monitoring.Monitorable;
import com.nandox.libraries.validation.BeanValidable; 
import com.nandox.libraries.validation.constraints.IpAddress;
/**
 * Node data model POJO
 * 
 * @project   domuxCenter
 * 
 * @module    Node.java
 * 
 * @date      30 mar 2019 - 30 mar 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "name",
    "type",
    "addrBT",
    "addrI2C",
    "addrIP",
    "baud",
    "capabilities",
    "resourceList"
})
public class Node extends BeanValidable implements Monitorable, Serializable {
	private static final long serialVersionUID = -7161965077596849504L;

	@NotNull(message="ERROR_FIELD_NODE_NAME")
	@Size(min=1, max=32, message="ERROR_FIELD_NODE_NAME")
    @XmlElement(name = "name", required = true)
	private String name;			// identification node name
    @XmlElement(name = "type", required = true)
	private String type;		// node type
    @XmlElement(name = "addrBT")
	private String addrBT; 		// bluetooth address
    @Pattern(regexp="\\b([89]|[1-8][0-9]|9[0-9]|1[01][0-9]|120)\\b", message="ERROR_FIELD_NODE_ADDRI2C", groups=AddrI2CValidation.class)
    @XmlElement(name = "addrI2C")
	private String addrI2C;		// I2C bus address
    @IpAddress(groups=AddrIPValidation.class, message="ERROR_FIELD_NODE_ADDRIP")
    @XmlElement(name = "addrIP")
	private String addrIP;		// IP Address
    @XmlElement(name = "baud")
	private String baud;		// baudrate
    @XmlElement(name = "capabilities", required = true)
	private Capabilities capabilities;
    @XmlElementWrapper(name="resourceList")
    @XmlElement(name = "Resource", required = true)
	private List<Resource> resourceList;
    @XmlAttribute(name = "dxid", required = true)
    //@XmlSchemaType(name = "unsignedShort")
    protected String dxid = "";
    transient private PhysicalChannel lastChannel;		// last used channel
    @XmlTransient
    private Status status = Status.LOST;		// status of node
	
	public Node() {
		this.name = "";
		this.capabilities = new Capabilities();
	}
    /**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String id) {
		this.name = id;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the addrBT
	 */
	public String getAddrBT() {
		return addrBT;
	}
	/**
	 * @param addrBT the addrBT to set
	 */
	public void setAddrBT(String addrBT) {
		this.addrBT = addrBT;
	}
	/**
	 * @return the addrI2C
	 */
	public String getAddrI2C() {
		return addrI2C;
	}
	/**
	 * @param addrI2C the addrI2C to set
	 */
	public void setAddrI2C(String addrI2C) {
		this.addrI2C = addrI2C;
	}
	/**
	 * @return the addrIP
	 */
	public String getAddrIP() {
		return addrIP;
	}
	/**
	 * @param addrIP the addrIP to set
	 */
	public void setAddrIP(String addrIP) {
		this.addrIP = addrIP;
	}
	/**
	 * @return the baud
	 */
	public String getBaud() {
		return baud;
	}
	/**
	 * @param baud the baud to set
	 */
	public void setBaud(String baud) {
		this.baud = baud;
	}
	/**
	 * @param dxid the dxid to set
	 */
	public void setDxid(String dxid) {
		this.dxid = dxid;
	}
	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}
	/**
	 * @return the lastChannel
	 */
	public PhysicalChannel getLastChannel() {
		return (this.lastChannel==null?PhysicalChannel.NOTHING:this.lastChannel);
	}
	/**
	 * @param lastChannel the lastChannel to set
	 */
	public void setLastChannel(PhysicalChannel lastChannel) {
		this.lastChannel = lastChannel;
	}
	/**
	 * @return the capabilities
	 */
	public Capabilities getCapabilities() {
		return capabilities;
	}
	/**
	 * @param capabilities the capabilities to set
	 */
	public void setCapabilities(Capabilities capabilities) {
		this.capabilities = capabilities;
	}
	/**
	 * @return the resourceList
	 */
	public List<Resource> getResourceList() {
		return resourceList;
	}
	/**
	 * @param resourceList the resourceList to set
	 */
    public void setResourceList(List<Resource> resourceList) {
		this.resourceList = resourceList;
	}
	/**
	 * @param resourceList the resourceList to set
	 */
	public Resource getResourceById(String id) {
		for ( Resource r : this.resourceList ) {
			if ( r.getId().equals(id) )
				return r;
		}
		return null;
	}
	/**
	 * @return the dxid
	 */
	public String getDxid() {
		return dxid;
	}
	/**
	 * Copy data from node to this
	 * @param	  node source node data
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public void copyFrom(Node node) {
		this.setName(node.getName());
		this.setAddrBT(node.getAddrBT());
		this.setAddrIP(node.getAddrIP());
		this.setAddrI2C(node.getAddrI2C());
		this.setBaud(node.getBaud());
		for ( Resource r : this.getResourceList() ) {
			Resource rnew = node.getResourceById(r.getId());
			if ( rnew != null ) {
				r.setName(rnew.getName());
				r.setType(rnew.getType());
			// TODO: come gestire log qui? 
			/*
			} else {
				this.log.warn("Resource %s not found on node %s",r.getId(),node.getName());*/
			}
		}
	}
	/* (non-Javadoc)
	 * @see com.nandox.libraries.validation.BeanValidable#validate(Class<?>...args)
	 */
	@Override
	public Map<String, String> validate(Class<?>...args) {
		Map<String,String> ret = new HashMap<String,String>();
		if ( this.capabilities.hasIP ) {
				ret.putAll(super.validate(AddrIPValidation.class));
		}
		if ( this.capabilities.hasI2C ) {
			ret.putAll(super.validate(AddrI2CValidation.class));
		}
		ret.putAll(super.validate());
		return ret;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.logging.Monitorable#getClassifyData()
	 */
	public Map<ClassifyKey, String> getClassifyData() {
		Map<ClassifyKey, String> ret = new HashMap<ClassifyKey, String>();
		ret.put(ClassifyKey.Class,this.getClass().getName());
		ret.put(ClassifyKey.dxid, this.dxid);
		ret.put(ClassifyKey.name, this.name);
		return ret;
	}
	/**
	 * Node capabilities
	 * @date      30 mar 2019 - 30 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "hasSerial",
        "hasBT",
        "hasI2C",
        "hasIP"
    })
	public static class Capabilities implements Serializable {
		private static final long serialVersionUID = -4351794672731371898L;
		@XmlElement(name = "hasSerial")
		protected final boolean hasSerial;
		@XmlElement(name = "hasBT")
		protected final boolean hasBT;
        @XmlElement(name = "hasI2C")
        protected final boolean hasI2C;
        @XmlElement(name = "hasIP")
        protected final boolean hasIP;
        
        public Capabilities() {
        	this.hasSerial = false;
        	this.hasBT = false;
        	this.hasI2C = false;
        	this.hasIP = false;
        }
        public Capabilities(boolean hasBT, boolean hasI2C, boolean hasIP, boolean hasSerial ) {
        	this.hasSerial = hasSerial;
        	this.hasBT = hasBT;
        	this.hasI2C = hasI2C;
        	this.hasIP = hasIP;
        }
		/**
		 * @return the Serial
		 */
		public boolean hasSerial() {
			return hasSerial;
		}
		/**
		 * @return the bT
		 */
		public boolean hasBT() {
			return hasBT;
		}
		/**
		 * @return the i2C
		 */
		public boolean hasI2C() {
			return hasI2C;
		}
		/**
		 * @return the iP
		 */
		public boolean hasIP() {
			return hasIP;
		}
	}

	/**
	 * Node's status
	 * @date      30 mar 2019 - 30 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public enum Status {
		/** Node is registered */
		REGISTERED,
		/** Node is not registered */
		UNREGISTERED,
		/** Node is lost (no connection) */
		LOST
	}

	/**
	 * Node physical channel used
	 * @date      30 mar 2019 - 30 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public enum PhysicalChannel {
		/** nothing channel */
		NOTHING,
		/** Bluetooth */
		BT,
		/** Bus */
		I2C,
		/** Serial */
		SERIAL,
		/** Internet */
		IP
	}

	public interface AddrIPValidation {}
	public interface AddrI2CValidation {}
}
