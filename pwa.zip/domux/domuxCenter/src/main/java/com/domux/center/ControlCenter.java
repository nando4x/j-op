package com.domux.center;

import java.lang.Thread;
import java.util.Collection;
import java.util.List;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Value;

import com.domux.center.logging.BaseLogger;
import com.domux.center.database.DomuxDataBase;
import com.domux.center.devices.DeviceManager;
import com.domux.center.devices.nodes.NodeController;
import com.domux.center.devices.nodes.NodeFactory;
import com.domux.center.model.Node;
import com.domux.center.model.Resource;
import com.domux.center.monitoring.MonitorEvent;
import com.domux.center.monitoring.MonitorManager;
import com.nandox.libraries.ErrorGroup;
import com.nandox.libraries.Return;

/**
 * Control center: main nodes orchestrator 
 * 
 * @project   domuxCenter
 * 
 * @module    Resource.java
 * 
 * @date      30 mar 2019 - 30 mar 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public class ControlCenter extends BaseLogger {
	private DomuxDataBase database;
	private List<Node>	unregistered;
	private SystemStatus status;
	private DeviceManager devman;
	private MonitorEvent monitor;
	private MonitorManager monitorManager;
	private boolean runThread = true;
	
	@Value("${monitor.ip.changes}")
	private boolean monitorIp;
	
	/**
	 * Complete constructor
	 * @param	  database nodes database
	 * @param	  dev device manager 
	 * @param	  monitor monitor to register events 
	 * @param	  monitor monitor manager to read and manage events 
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public ControlCenter(DomuxDataBase database, DeviceManager devman, MonitorEvent monitor, MonitorManager monitorReader) {
		this.log.info("Starting Control Center...");
		this.database = database;
		this.devman = devman;
		this.monitor = monitor;
		this.monitorManager = monitorReader;
		this.unregistered = new ArrayList<Node>();
		this.status = new SystemStatus();
		// read from DataBase
		try {
			this.database.loadData();
			for ( Node n : this.database.getNodes().values() ) {
				NodeFactory fact = new NodeFactory(this.devman);
				NodeController nc = fact.createController(n.getType());
				nc.fillInitialResourceValue(n);
			}

		} catch ( Exception e ) {
			status.setDbIsInError(true);
		}
		// discovery nodes
		this.discoveryNodes();
		// read nodes resources value
		//this.readResourceValue(this.database.getNodes().values());
		//this.readResourceValue(this.unregistered);
		this.startNodeMonitor();
		if ( this.monitorIp )
			this.startMonitorIp();
	}
	/**
	 * @return the unregistered nodes
	 */
	public List<Node> getUnregistered() {
		return unregistered;
	}
	/**
	 * @return the system status
	 */
	public SystemStatus getStatus() {
		return status;
	}
	/**
	 * @return the monitor manager
	 */
	public MonitorManager getMonitorManager() {
		return this.monitorManager;
	}
	/**
	 * Save node configuration on device:<br>
	 * use channel from address of node in database or unregister to communicate with device 
	 * @param	  node node to save
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception Exception generic to cover all exception type<br>
	 * 			  Return with DomuxDataBase.Error.ERR_NODE_NOTFOUND code if node not fount
	 */
	public void saveOnDevice(Node node) throws Exception {
		// search actual from db or unregister
		Node act;
		if ( node.getStatus() == Node.Status.UNREGISTERED ) {
			act = this.searchUnregisterByDxID(node.getDxid());
		} else {
			act = this.database.searchNodeByDxID(node.getDxid());
		}
		if ( act != null ) {
			NodeFactory fact = new NodeFactory(this.devman);
			NodeController n = fact.createController(node.getType());
			n.sendConfigurationToDevice(node, act);
		} else {
			this.monitor.registerEvent(null, MonitorEvent.Type.SYSERROR, "node to save not found", node);
			throw new Return(DomuxDataBase.Error.ERR_NODE_NOTFOUND,
							 DomuxDataBase.Error.ERR_NODE_NOTFOUND.name());
		}
	}
	/**
	 * Rollback node configuration on device:<br>
	 * save node on database or unregister to device
	 * @param	  node node to save
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public void rollbackOnDevice(Node node) {
		// search actual from db or unregister
		Node act;
		if ( node.getStatus() == Node.Status.UNREGISTERED ) {
			act = this.searchUnregisterByDxID(node.getDxid());
		} else {
			act = this.database.searchNodeByDxID(node.getDxid());
		}
		try {
			if ( act != null ) {
				NodeFactory fact = new NodeFactory(this.devman);
				NodeController n = fact.createController(node.getType());
				n.sendConfigurationToDevice(act, node);
			} else {
				this.monitor.registerEvent(null, MonitorEvent.Type.SYSERROR, "node to rollback not found", node);
			}
		} catch (Exception e) {
			this.monitor.registerEvent(null, MonitorEvent.Type.NETWORKERROR, "error in rollback", node, e);
			this.log.error("Error on rollback node", e);
		}
	}
	/**
	 * Delete node from database and (if not LOST) put into unregister list 
	 * @param	  dxid database identifier
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  true if node found
	 */
	public boolean deleteNodeFromDataBase(String dxid) throws Exception {
		Node n = this.database.searchNodeByDxID(dxid);
		if ( this.database.deleteNode(dxid) ) {
			if ( n.getStatus() != Node.Status.LOST ) { 
				n.setStatus(Node.Status.UNREGISTERED);
				this.unregistered.add(n);
			}
			return true;
		}
		return false;
	}
	/**
	 * Search into unregister by dxid
	 * @param	  dxid database identifier
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  node found, otherwise null
	 */
	public Node searchUnregisterByDxID(String dxid) {
		for ( Node n : this.unregistered ) {
			if ( n.getDxid().equals(dxid) ) {
				return n;
			}
		}
		return null;
	}
	/**
	 * Discovery all connected nodes
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public void discoveryNodes() {
		this.log.info("Start discovery nodes...");
		// Discovery all unregistered
		try {
			Collection<Node> found = this.devman.discoveryNodes();
			// update status and if need add to unregistered
			this.unregistered.clear();
			for ( Node n : found ) {
				Node ndb =  this.database.searchNodeByDxID(n.getDxid());
				if ( ndb != null ) {
					ndb.setStatus(Node.Status.REGISTERED);
					ndb.setLastChannel(n.getLastChannel());
					NodeFactory fact = new NodeFactory(this.devman);
					NodeController nc = fact.createController(n.getType());
					nc.alignConfiguration(n, ndb);
				} else {
					this.unregistered.add(n);
				}
			}
			this.log.info("End discovery nodes");
		} catch (Exception e) {
			this.monitor.registerEvent(null, MonitorEvent.Type.SYSERROR, "discovery node error", null, e);
			this.log.error("Error discovery nodes", e);
		}
	}
	/**
	 * Send node single resource value to physical device:<br>
	 * use channel from address of node in database or unregister to communicate with device 
	 * @param	  node node to save
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  resource updated
	 * @exception Exception generic to cover all exception type<br>
	 * 			  Return in case of error return a specific code 
	 */
	public Resource writeResourceValueOnDevice(Node node, Resource res) throws Exception {
		NodeFactory fact = new NodeFactory(devman);
		NodeController n = fact.createController(node.getType());
		Return ret = n.writeResourceValue(node, res);
		if ( ret.getCode() == Return.RET_OK )
			return res;
		throw ret;
	}
	/**
	 * Update all resources value reading data from real device node by own NodeController 
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	protected void readResourceValue(Collection<Node> nodes) {
		NodeFactory fact = new NodeFactory(this.devman);
		for ( Node node : nodes ) {
			NodeController n = fact.createController(node.getType());
			n.readResourceValue(node);
		}
	}
	// scan all known nodes to test if connected
	//
	//
	private void startNodeMonitor() {
		final ControlCenter center = this;
		Thread nodeMonitor = new Thread() {
			public void run() {
				HashMap<Node,Integer> inerror = new HashMap<Node,Integer>();
				while (center.runThread) {
					try {
						Thread.sleep(2000);
						if ( center.database.getNodes().size() == 0 && center.unregistered.size() == 0  )  {
							continue;
						}
						//continue;
						log.debug("Read node's resoures");
						NodeFactory fact = new NodeFactory(center.devman);
						for ( Node node : center.database.getNodes().values() ) {
							Return ret = center.devman.identifyNode(node);
							if ( ret.getCode() == Return.RET_OK ) {
								NodeController n = fact.createController(node.getType());
								ret = n.readResourceValue(node);
							} else
								ret = new Return(ErrorGroup.getCode(DeviceManager.Error.ERR_CHANNEL_ALLOCATION), null);
							if ( ret.getCode() == ErrorGroup.getCode(DeviceManager.Error.ERR_CHANNEL_ALLOCATION) ) {
								synchronized(node) {
									node.setStatus(Node.Status.LOST);
									Integer i = inerror.get(node);
									i = (i==null?1:i+1);
									inerror.put(node, i);
									if ( i >= 3 )
										center.status.setNetworkInError(true);
									log.info("node disconnected %s", node.getName());
								}
							} else {
								synchronized(node) {
									node.setStatus(Node.Status.REGISTERED);
									inerror.remove(node);
								}
							}
						}
						for ( Node node : new ArrayList<Node>(center.unregistered) ) {
							NodeController n = fact.createController(node.getType());
							Return ret = n.readResourceValue(node);
							if ( ret.getCode() == ErrorGroup.getCode(DeviceManager.Error.ERR_CHANNEL_ALLOCATION) ) {
								center.unregistered.remove(node);
								log.debug("unregistered node disconnected %s", node.getName());
							}
						}
						if ( inerror.size() == 0 )
							center.status.setNetworkInError(false);
						center.status.getNetwork().totalConnections = center.monitorManager.getTotalConnections();
						center.status.getNetwork().totalErrorConnections = center.monitorManager.getTotalErrorConnections();
						center.status.getNetwork().dailyErrorConnections = center.monitorManager.getDailyErrorConnections();
						center.status.getNetwork().totalNodes = center.database.getNodes().size(); 
						center.status.getNetwork().disconnectedNodes = inerror.size(); 
					} catch (Exception e) {
						log.error("Error on controlCenter node monitor", e);
					}
				}
			}
		};
		nodeMonitor.start();
	}
	// check if ip changes and recertificate
	//
	//
	private void startMonitorIp() {
		final ControlCenter center = this;
		Thread nodeMonitor = new Thread() {
			public void run() {
				try {
					IpAddressCertification ipCert = new IpAddressCertification();
					Thread.sleep(9000);
					while (center.runThread) {
						Thread.sleep(9000);
					}
					com.nandox.tomcatext.ManagedConnector mc = new com.nandox.tomcatext.ManagedConnector();
					int sz = mc.getConnectorsSize();
					for ( int ix=0; ix < sz; ix++ ) {
						String fname = mc.getAttribute(ix, "keystoreFile");
						if ( fname != null && fname.endsWith("/ip.p12") ) {
							mc.setCurrentConnector(ix);
							java.security.KeyStore ks = mc.getKeyStore();
							break;
						}
					}
				} catch (Exception e) {
					e = null;
				}
			}
		};
		nodeMonitor.start();
	}
	public void shutdown() {
		this.runThread = false;
	}
}
