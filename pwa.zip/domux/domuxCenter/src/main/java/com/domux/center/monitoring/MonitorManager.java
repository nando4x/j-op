package com.domux.center.monitoring;

import java.util.List;

/**
 * Class to read monitor events 
 * 
 * @project   domuxCenter
 * 
 * @module    MonitorManager.java
 * 
 * @date      21 giu 2019 - 21 giu 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public interface MonitorManager {
	/**
	 * Search and return last 10 event by types
	 * @date      31 mar 2019 - 31 mar 2019
	 * @param	  types Event type array
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  events list
	 */
	public List<MonitorEvent.EventData> searchLastByType(MonitorEvent.Type[] types);
	/**
	 * Getter for total connections amount
	 * @date      31 mar 2019 - 31 mar 2019
	 * @param	  types Event type array
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  total amount of connections
	 */
	public int getTotalConnections();
	/**
	 * Getter for total amount of error connection
	 * @date      31 mar 2019 - 31 mar 2019
	 * @param	  types Event type array
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  total amount of error connections
	 */
	public int getTotalErrorConnections();
	/**
	 * Getter for daily total amount of error connection
	 * @date      31 mar 2019 - 31 mar 2019
	 * @param	  types Event type array
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  total amount of error connections
	 */
	public int getDailyErrorConnections();
}
