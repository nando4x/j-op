package com.domux.center.devices;

import java.util.Collection;
import com.domux.center.model.Node;
import com.domux.center.devices.DomuxProtocol;
import com.nandox.libraries.Return;
import com.nandox.libraries.ErrorGroupMarker;

/**
 * Manager of peripherals devices to connect to physical nodes.<br>
 * Can send/execute domux command and discovery a new node
 * 
 * @project   Domux
 * 
 * @module    DeviceManager.java
 * 
 * @date      30/mag/2014 - 30/mag/2014
 * 
 * @author    Fernando
 * 
 * @revisor   Fernando
 */
public interface DeviceManager {
	@ErrorGroupMarker(-1200)
	public enum Error {
		/** */
		ERR_CHANNEL_ALLOCATION
	}
	/**
	 * Discovery connected nodes enquiring vary physical channel <br>
	 * using GETREG domux protocol command
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  discovered nodes list
	 */
	public Collection<Node> discoveryNodes();
	/**
	 * Execute a domux protocol command:<br>
	 * send command and data and wait response. Open a dedicated session for the command
	 * 
	 * @param	  node node of comunication
	 * @param	  service domux protocol service
	 * @param	  cmd comando domux protocol command
	 * @param	  data eventually data command, null or empty string if no data
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  Code ad message of response (@see com.domux.center.devices.DomuxProtocol#sendCommand)
	 */
	public Return executeDomuxProtocolCommand(Node node, DomuxProtocol.Service service, DomuxProtocol.Command cmd, String data);
	/**
	 * Execute a domux protocol command:<br>
	 * send command and data and wait response. Open a dedicated session for the command or reuse<br> 
	 * a previous active
	 * @param	  node node of communication
	 * @param	  service domux protocol service
	 * @param	  cmd domux protocol command
	 * @param	  data eventually data command, null or empty string if no data
	 * @param	  prvSess if true reuse a previous active session and not open a new
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  Code ad message of response (@see com.domux.center.devices.DomuxProtocol#sendCommand)
	 */
	public Return executeDomuxProtocolCommand(Node node, DomuxProtocol.Service service, DomuxProtocol.Command cmd, String data, boolean prvSess);
	/**
	 * Verify the node identity comparing the dxid of node and dxid of physical device:<br>
	 * @param	  node node of communication
	 * @date      18/set/2019 - 18/set/2019
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  RET_OK if dxid correspond otherwise not correspond or comunication error
	 */
	public Return identifyNode(Node node);
	/**
	 * Define a command to cache
	 * @param	  service domux protocol service
	 * @param	  cmd comando domux protocol command
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	//public void defineCmdCacheable ( String service, String cmd );
}
