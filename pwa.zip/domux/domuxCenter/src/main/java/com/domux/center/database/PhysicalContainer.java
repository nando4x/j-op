package com.domux.center.database;

import java.util.Collection;
import java.util.Map;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.domux.center.model.MapItem;
import com.domux.center.model.Node;
import com.nandox.tomcatext.JAASUserDatabase.User;
import com.nandox.libraries.validation.BeanValidable;

/**
 * Physical database container represents the real data container of DomuxDataBase  
 * 
 * @project   domuxCenter
 * 
 * @module    PhysicalContainer.java
 * 
 * @date      01 apr 2019 - 01 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public interface PhysicalContainer {
	/**
	 * Load nodes from physical database
	 * @date      19/mag/2014 - 19/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  nodes map with database identifier
	 * @exception Exception generic, depending on real implementation 
	 */
	public Map<String,Node> loadNodeData() throws Exception;
	/**
	 * Save nodes to physical database
	 * @param	  data nodes list
	 * @date      19/mag/2014 - 19/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @exception Exception generic, depending on real implementation 
	 */
	public void saveNodeData(Collection<Node> data) throws Exception;
	/**
	 * Load resources map from physical database
	 * @date      19/mag/2014 - 19/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  map 
	 * @exception Exception generic, depending on real implementation 
	 */
	public Map<String,MapItem> loadMapData() throws Exception;
	/**
	 * Save resources map to physical database
	 * @param	  data map item list
	 * @date      19/mag/2014 - 19/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @exception Exception generic, depending on real implementation 
	 */
	public void saveMapData(Collection<MapItem> data) throws Exception;
	/**
	 * Load map background image from physical database
	 * @date      19/mag/2014 - 19/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  data image based on css data base64
	 * @exception Exception generic, depending on real implementation 
	 */
	public PhysicalContainer.MapImage loadImageData() throws Exception;
	/**
	 * Save map background image to physical database
	 * @param	  data nodes list
	 * @date      19/mag/2014 - 19/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @exception Exception generic, depending on real implementation 
	 */
	public void saveImageData(PhysicalContainer.MapImage data) throws Exception;
	/**
	 * Get a new unique identifier
	 * @date      19/mag/2014 - 19/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  new identifier
	 * @exception Exception generic, depending on real implementation 
	 */
	public int getNewId() throws Exception;
	/**
	 * Class to represent the map background image
	 * @date      19/mag/2014 - 19/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	public static class MapImage extends BeanValidable {
		/** image width */
		@NotNull(message = "ERROR_FIELD_MAPIMAGE_WIDTHNULL")
		@Min(value=0,message = "ERROR_FIELD_MAPIMAGE_WIDTHSIZE")
		protected int width;
		/** image height */
		@NotNull(message = "ERROR_FIELD_MAPIMAGE_HEIGHTNULL")
		@Min(value=0,message = "ERROR_FIELD_MAPIMAGE_HEIGHTSIZE")
		protected int height;
		/** image data css base64 */
		protected String data;
		
		/**
		 * Complete constructor
		 * @param	  width	value of width property
		 * @param	  height	value of height property
		 * @param	  data	value of data property
		 * @date      31 mar 2019 - 31 mar 2019
		 * @author    Fernando Costantino
		 * @revisor   Fernando Costantino
		 */
		public MapImage(int width, int height, String data) {
			this.width = width;
			this.height = height;
			this.data = data;
		}
		/**
		 * @return the width
		 */
		public int getWidth() {
			return width;
		}
		/**
		 * @return the height
		 */
		public int getHeight() {
			return height;
		}
		/**
		 * @return the data
		 */
		public String getData() {
			return data;
		}
	}
}
