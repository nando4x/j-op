package com.domux.center.services.restful;

//import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ControllerAdvice;
//import org.springframework.http.ResponseEntity;

import com.domux.center.logging.BaseLogger;

/**
 * Global http request exception handler 
 * 
 * @project   domuxCenter
 * 
 * @module    ExceptionHandlerManager.java
 * 
 * @date      12 giu 2019 - 12 giu 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
@ControllerAdvice
class ExceptionHandlerManager extends BaseLogger {
	
	@ExceptionHandler()
    public void handleIOException(Exception ex) throws Exception {
		this.log.error("request error: %s", ex.toString());
		throw ex;
    }
}
