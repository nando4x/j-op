package com.domux.center.devices;

import com.nandox.libraries.Return;

/**
 * Generic domux physical channel used to communication with real node device.
 * Basically permit to read and write data, some channels (usually a poor quality channel)<br>
 * can use a CRC checking  
 * 
 * @project   DomuxCentre
 * 
 * @module    DomuxChannel.java
 * 
 * @date      26/mag/2014 - 26/mag/2014
 * 
 * @author    Fernando
 * 
 * @revisor   Fernando
 */
public interface DomuxChannel {
	/**
	 * Read data from channel
	 * @date      21/mag/2014 - 21/mag/2014
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return    can return code RET_OK and relative data if success or a specific error code if fail
	 * @exception Exception generic, depending on channel implementation 
	 */
	public Return readData() throws Exception;
	/**
	 * send data to channel
	 * @param	  data data stream as a string
	 * @date      21/mag/2014 - 21/mag/2014
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return    can return code RET_OK if success or a specific error code if fail
	 * @exception Exception generic, depending on channel implementation 
	 */
	public Return writeData(String data) throws Exception;
	/**
	 * check if communication use a CRC checking,<br>
	 * if true is mandatory to append CRC on data and CRC will be present on response data 
	 * @date      21/mag/2014 - 21/mag/2014
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return    true if CRC is mandatory
	 */
	public boolean hasCRC();
	/**
	 * Close channel 
	 * @date      21/mag/2014 - 21/mag/2014
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return    
	 */
	public void close() throws Exception;
}
