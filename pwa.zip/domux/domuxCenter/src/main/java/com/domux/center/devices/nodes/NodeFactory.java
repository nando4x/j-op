package com.domux.center.devices.nodes;

import com.domux.center.devices.DeviceManager;
import com.domux.center.model.Node;
import com.nandox.libraries.Configuration;

/**
 * Class factory for node controller.<br>
 * Generate node controller by own type.
 * Can also create a node POJO by configuration read from physical node device 
 * 
 * @project   domuxCenter
 * 
 * @module    NodeFactory.java
 * 
 * @date      30 mar 2019 - 30 mar 2019
 * 
 * @author    Fernando
 * 
 * @revisor   Fernando
 */
public class NodeFactory {
	private DeviceManager devman;
	/**
	 * Constructor
	 * @param	  devman	Device manager
	 * @date      12 apr 2019 - 12 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public NodeFactory(DeviceManager devman) {
		this.devman = devman;
	}
	/**
	 * Create controller based on type
	 * @param	  type node type
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 * @return	  Controller 
	 */
	public NodeController createController(String type) {
		if ( type != null && type.startsWith("RELAY") ) {
			return new RelayNodeController(this.devman);
		}
		return null;
	}
	/**
	 * Create Node from configuration data.<br>
	 * Use this configuration key: ID, NAME, NODETYPE, RESOURCE.NUM, CFG   
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public Node createNodeFromConfiguration(Configuration cfg) {
		NodeController nc = this.createController(cfg.getStringValue("NODETYPE", ""));
		if ( nc != null )
			return nc.createNodeFromConfiguration(cfg);
		else
			return null;
	}
	/**
	 * Return the class that represent resource value by specific node type
	 * @param	  type node string type
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  ResourceValue specific class, null for unknown types 
	 */
	static public Class<?> getResourceClass(String type) {
		if ( type != null && type.startsWith("RELAY") ) {
			return (new RelayNodeController(null)).getResourceValueClass();
		}
		return null;
	}
}
