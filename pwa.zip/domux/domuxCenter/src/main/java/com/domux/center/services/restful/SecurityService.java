package com.domux.center.services.restful;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.domux.center.database.DomuxDataBase;
import com.domux.center.model.User;
import com.nandox.libraries.ErrorGroupMarker;

/**
 * Security restful operation controller to get users list, save a user changes, add new or delete<br> 
 * 
 * @project   domuxCenter
 * 
 * @module    SecurityService.java
 * 
 * @date      01 apr 2019 - 01 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", allowCredentials="true")
public class SecurityService extends AbstarctJsendService {
	@ErrorGroupMarker(-2200)
	public enum Error {
		/** Error code database not ready */
		RET_ERR_READINGUSER,
		/** Error code saving data into database */
		RET_ERR_SAVINGUSER,
		/** Error code deleting data from database */
		RET_ERR_DELETINGUSER
	}

	@Autowired
	@Qualifier("db")
	private DomuxDataBase db;
	
	/**
	 * getusers service: return to complete users list.<br>
	 * Response with this jsend data:
	 *		[
	 *	       {id: number,
	 *	        name: string,
	 *	        password: string,
	 *	        role: string
	 *		   }
	 *		]
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response as String
	 */
	@GetMapping(path = "/getusers",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String getUsers () {
		try {
			return this.responseSuccess(this.toJsonTree(this.db.getUsers().values()));
		} catch (Exception e) {
			return this.responseError(Error.RET_ERR_READINGUSER, e);
		}
	}
	/**
	 * senduser service: receive user data and save it on users tomcat database<br>
	 * in case of admin user change only password 
	 * Expect this request:
	 * 		{
	 *		     id: number,
	 *		     name: string,
	 *		     password: string,
	 *		     role: string
	 *		}
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response as String: if success complete users list, if wrong validate return fail data,<br>
	 *  		  if error return error data<br>
	 *  		  Possible fail are: new user with already existing name, name null, password null, role not exist 
	 */
	@PostMapping(path = "/senduser",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String setUser (@RequestBody String json) {
		try {
			User user = this.fromJson(json, User.class);
			Map<Integer,User> users = this.getUsersList();
			User userOrg = users.get(user.getId());
			Map<String,String> err = new HashMap<String,String>();
			if ( userOrg == null ) { 
				// New user: validate and add
				err = this.validate(user, true);
				if ( err.isEmpty() )
					this.db.getUsers().put(user.getName(), user);
			} else {
				// Existing user: validate it 
				err = this.validate(user, false);
				if ( err.isEmpty() ) {
					User u = users.get(user.getId());
					// if admin update only password
					if ( "admin".equalsIgnoreCase(userOrg.getName()) ) {
						if ( "admin".equalsIgnoreCase(user.getName()) )
							u.setPassword(user.getPassword());
						else {
							err.put("name", "ERROR_USER_ADMINCANNOTCHANGE");
							return this.responseFail(this.toJsonTree(err));
						}
					} else {
						u.setName(user.getName());
						u.setPassword(user.getPassword());
						u.setRole(user.getRole());
					}
				}
			}
			if ( err.isEmpty() ) {
				this.db.saveUsers();
				return this.responseSuccess(this.toJsonTree(this.db.getUsers().values()));
			} else
				return this.responseFail(this.toJsonTree(err));
		} catch (Exception e) {
			return this.responseError(Error.RET_ERR_SAVINGUSER, e);
		}
	}
	/**
	 * deleteuser service: receive user data and delete it from users tomcat database<br>
	 * Expect this request:
	 * 		{
	 *		     id: number,
	 *		     name: string,
	 *		     password: string,
	 *		     role: string
	 *		}
	 * @date      01 apr 2019 - 01 apr 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  json response (complete users list) as String
	 */
	@PostMapping(path = "/deleteuser",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String deleteUser (@RequestBody String json) {
		try {
			User user = this.fromJson(json, User.class);
			Map<Integer,User> users = this.getUsersList();
			User userOrg = users.get(user.getId());
			Map<String,String> err = new HashMap<String,String>();
			if ( userOrg == null ) { 
				err.put("name", "ERROR_USER_NOTFOUND");
				return this.responseFail(this.toJsonTree(err));
			} else if ( userOrg.getName().equalsIgnoreCase("admin") ) { 
				err.put("name", "ERROR_USER_ADMINCANNOTDELETE");
				return this.responseFail(this.toJsonTree(err));
			} else {
				this.db.getUsers().remove(user.getName());
			}
			this.db.saveUsers();
			return this.responseSuccess(this.toJsonTree(this.db.getUsers().values()));
		} catch (Exception e) {
			return this.responseError(Error.RET_ERR_DELETINGUSER, e);
		}
	}
	// Return users map with id as key 
	//
	//
	private Map<Integer,User> getUsersList() {
    	Map<Integer,User> users = new HashMap<Integer,User>();
        for ( User u : this.db.getUsers().values() ) {
        	users.put(u.getId(), u);
        }
    	return users;
	}

	private Map<String,String> validate(User user, boolean isNew) throws Exception {
		Map<String,String> err = user.validate();
		if ( err.size() == 0 && isNew ) {
			if ( this.db.getUsers().get(user.getName()) != null ) {
				err.put("name", "ERROR_USER_ALREADYEXIST");
			}
		}
		return err;
	}
}
