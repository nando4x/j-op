package com.domux.center.database;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

import com.nandox.libraries.ErrorGroupMarker;
import com.nandox.libraries.Return;
import com.domux.center.logging.BaseLogger;
import com.domux.center.model.User;
import com.domux.center.model.Node;
import com.domux.center.model.Resource;
import com.domux.center.model.MapItem;

/**
 * Nodes database: logical container of  registered and lost nodes.<br>
 * The database use a physical container ({@link com.domux.center.database.PhysicalContainer}) to read and write data on real persistent device<br>
 * (es: xml file)<br>
 * This class permit to read elements: node list, resources map, map background image
 * 
 * @project   domuxCenter
 * 
 * @module    DomuxDataBase.java
 * 
 * @date      30 mar 2019 - 30 mar 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public class DomuxDataBase extends BaseLogger {
	@ErrorGroupMarker(-3000)
	public enum Error {
		/** code error when node to save not found */
		ERR_NODE_NOTFOUND,
		/** code error when try to create an existent node */
		ERR_NODE_ALREADY_EXIST
	}
	private static final String JNDIUSERDB = "java:/comp/env/userdb";
	
	private Map<String,Node> nodes;
	private Map<String,MapItem> map;
	private Map<String,User> users;
	private PhysicalContainer phydb;
	private org.apache.catalina.UserDatabase tomcatUserDB;

	/**
	 * Complete constructor
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public DomuxDataBase() {
		super();
		this.nodes = new HashMap<String,Node>();
		this.map = new HashMap<String,MapItem>();
		this.users = new HashMap<String,User>();
		try {
			this.tomcatUserDB = (org.apache.catalina.UserDatabase)(new javax.naming.InitialContext()).lookup(JNDIUSERDB);	
		} catch ( Exception e ) {
			throw new RuntimeException(e);
		}
	}
	/**
	 * @return the complete collection of nodes, mapped by dxid key
	 */
	public Map<String, Node> getNodes() {
		return nodes;
	}
	/**
	 * @return the complete collection of resources map. This collection is mapped by dxid key
	 */
	public Map<String, MapItem> getMap() {
		return map;
	}
	/**
	 * @return the users
	 */
	public Map<String, User> getUsers() {
		return users;
	}
	/**
	 * @return the physical data container 
	 */
	public PhysicalContainer getPhydb() {
		return phydb;
	}
	/**
	 * @param phydb the the physical data container to set
	 */
	public void setPhydb(PhysicalContainer phydb) {
		this.phydb = phydb;
	}
	/**
	 * Load data from physical container
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception Exception	a specific PhysicalContainer implementation, see {@link com.domux.center.database.PhysicalContainer#loadNodeData()}
	 * 			  and {@link com.domux.center.database.PhysicalContainer#loadMapData()}
	 */
	public void loadData() throws Exception {
		this.log.info("Start database loading data...");
		try {
			this.nodes = this.phydb.loadNodeData();
			this.map = this.phydb.loadMapData();
			this.loadUsers();
		} catch ( Exception e ) {
			this.log.error("Error in database loading data...", e);
			throw e;
		}
	}
	/**
	 * Save node into physical container
	 * @param	  node node data
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception Exception	a specific PhysicalContainer implementation, see {@link com.domux.center.database.PhysicalContainer#saveNodeData()}
	 */
	public void saveNode(Node node) throws Exception {
		// search if existing
		if ( node.getStatus() != Node.Status.UNREGISTERED ) {
			if ( this.nodes.get(node.getDxid()) != null ) {
				// update existing
				Node n = this.nodes.get(node.getDxid());
				/*n.setName(node.getName());
				n.setAddrBT(node.getAddrBT());
				n.setAddrIP(node.getAddrIP());
				for ( Resource r : n.getResourceList() ) {
					Resource rnew = node.getResourceById(r.getId());
					if ( rnew != null ) {
						r.setName(rnew.getName());
						r.setType(rnew.getType());
					} else {
						this.log.warn("Resource %s not found on node %s",r.getId(),node.getName());
					}
				}*/
				n.copyFrom(node);
				node.setStatus(n.getStatus());
			} else {
				throw new Return(Error.ERR_NODE_NOTFOUND,Error.ERR_NODE_NOTFOUND.name());
			}
		} else {
			Node n = this.searchNodeByName(node.getName());
			if ( n == null ) {
				// add passed node
				String id = node.getDxid();
				// set dxid to resources
				for ( Resource r : node.getResourceList() ) {
					r.setDxid(id+"."+r.getId());
				}
				this.nodes.put(node.getDxid(), node);
			} else {
				throw new Return(Error.ERR_NODE_ALREADY_EXIST,Error.ERR_NODE_ALREADY_EXIST.name());
			}
		}
		this.phydb.saveNodeData(this.nodes.values());
	}
	/**
	 * Delete node from physical container and node list
	 * @param	  dxid database node identifier
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return    true if delete, false if node not found
	 * @exception Exception	a specific PhysicalContainer implementation, see {@link com.domux.center.database.PhysicalContainer#saveNodeData()}
	 */
	public boolean deleteNode(String dxid) throws Exception {
		if ( this.nodes.containsKey(dxid) ) {
			this.nodes.remove(dxid);
			this.phydb.saveNodeData(this.nodes.values());
			return true;
		}
		return false;
	}
	/**
	 * Search node by Name
	 * @param	  name node name
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  Node object found, null if not found
	 */
	public Node searchNodeByName(String id) {
		for ( Node n : this.nodes.values() ) {
			if ( n.getName().equals(id) )
				return n;
		}
		return null;
	}
	/**
	 * Search node by DxId
	 * @param	  dxid database node identifier
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  Node object found, null if not found
	 */
	public Node searchNodeByDxID(String dxid) {
		return this.nodes.get(dxid);
	}
	/**
	 * Save resources map data into physical container
	 * @param	  map mapItem data
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception Exception	a specific PhysicalContainer implementation, see {@link com.domux.center.database.PhysicalContainer#saveMapData()}
	 * 			  and {@link com.domux.center.database.PhysicalContainer#loadMapData()}
	 */
	public void saveMap(Collection<MapItem> map) throws Exception {
		this.phydb.saveMapData(map);
		this.map = this.phydb.loadMapData();
	}
	/**
	 * Save map background image into physical container
	 * @param	  image image map data
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception Exception	a specific PhysicalContainer implementation, see {@link com.domux.center.database.PhysicalContainer#saveImageData()}
	 */
	public void saveMapImage(PhysicalContainer.MapImage image) throws Exception {
		this.phydb.saveImageData(image);
	}
	/**
	 * Read map background image data from physical container
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  image data as BASE64 String like css backgound-image rule
	 * @exception Exception	a specific PhysicalContainer implementation, see {@link com.domux.center.database.PhysicalContainer#loadImageData()}
	 */
	public String getMapImageData() throws Exception {
		return this.phydb.loadImageData().getData();
	}
	/**
	 * Read map background image width from physical container
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  image width
	 * @exception Exception	a specific PhysicalContainer implementation, see {@link com.domux.center.database.PhysicalContainer#loadImageData()}
	 */
	public int getMapImageWidth() throws Exception {
		return this.phydb.loadImageData().getWidth();
	}
	/**
	 * Read map background image height from physical container
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  image height
	 * @exception Exception	a specific PhysicalContainer implementation, see {@link com.domux.center.database.PhysicalContainer#loadImageData()}
	 */
	public int getMapImageHeight() throws Exception {
		return this.phydb.loadImageData().getHeight();
	}
	/**
	 * Save users data into tomcat user database
	 * @date      31 mar 2019 - 31 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @exception Exception	a specific tomcat UserDatabase implementation, see {@link org.apache.catalina.UserDatabase}
	 */
	public void saveUsers() throws Exception {
		ArrayList<org.apache.catalina.User> lu = new ArrayList<org.apache.catalina.User>();
		Iterator<org.apache.catalina.User> i = this.tomcatUserDB.getUsers();
		while (i.hasNext()) {
			org.apache.catalina.User uo = i.next();
			String role = uo.getRoles().next().getRolename();
			if ( Arrays.binarySearch(User.ACCESSROLES, role) >= 0 )
				lu.add(uo);
		}
		for ( org.apache.catalina.User u: lu ) {
			this.tomcatUserDB.removeUser(u);
		}
		for ( User u : this.users.values() ) {
			if ( u.getId() == null )
				u.setId((u.getName()+u.getPassword()+u.getRole()).hashCode());
			org.apache.catalina.User u1 = tomcatUserDB.createUser(u.getName(), u.getPassword(), null);
			u1.addRole(this.tomcatUserDB.findRole(u.getRole()));
		}
		this.tomcatUserDB.save();
		this.tomcatUserDB.close();
		this.tomcatUserDB.open();
	}
	// read all user with role ACCESSROLE from tomcat user database
	//
	//
	private void loadUsers() {
		Iterator<org.apache.catalina.User> i = this.tomcatUserDB.getUsers();
		while (i.hasNext()) {
			org.apache.catalina.User u = i.next();
			String role = u.getRoles().next().getRolename();
			if ( Arrays.binarySearch(User.ACCESSROLES, role) >= 0 ) {
				User user = new User();
				user.setName(u.getUsername());
				user.setPassword(u.getPassword());
				user.setRole(role);
				user.setId((user.getName()+user.getPassword()+user.getRole()).hashCode());
				this.users.put(user.getName(), user);
			}
		}
	}
}
