package com.domux.center.services.restful;

import java.util.HashMap;
import java.io.File;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.domux.center.ControlCenter;
import java.util.jar.JarFile;

import java.util.jar.JarEntry;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", allowCredentials="true")
public class CenterBeacon extends AbstarctJsendService {
	@Autowired
	@Qualifier("controlCenter")
	private ControlCenter cCenter;
	
    @Value("${update.destinationPath:***}")
	private String updatePath;

	@GetMapping(path = "/beacon",produces = MediaType.APPLICATION_JSON)
	public @ResponseBody String serve () {
		HashMap<String,String> sign = new HashMap<String,String>();
		sign.put("type", "domuxCenter");
		sign.put("version","1.0");
		return this.toJson(sign);
	}
	
	@PostMapping(value = "/update",produces = MediaType.APPLICATION_JSON)
	public String submit(@RequestParam("updatefile") MultipartFile file) {
		try {
			File f = new File(this.updatePath+"/domuxCenter.tmp");
			f.createNewFile();
			file.transferTo(f);
			this.checkUpdatefile(f);
			File fw = new File(this.updatePath+"/domuxCenter.war");
			fw.delete();
			f.renameTo(fw);
		} catch ( Exception e ) {
			return this.responseError(-1, "", e);
		}
	    return this.responseSuccess(null);
	}
	
	private void checkUpdatefile (File file) throws Exception {	
		JarFile jarFile = new JarFile(file);
		try {
			jarFile.entries();
			if ( jarFile.getJarEntry("WEB-INF/web.xml") == null )
				throw new Exception("File signature wrong");
		} catch (Exception e ) {
			throw e;
		} finally {
			jarFile.close();
		}
	}
}
