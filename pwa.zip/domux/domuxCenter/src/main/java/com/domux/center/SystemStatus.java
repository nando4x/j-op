package com.domux.center;

/**
 * Representation of system status.<br>
 * Flag dbInError is true if database is not correctly loaded
 * 
 * @project   domuxCenter
 * 
 * @module    SystemStatus.java
 * 
 * @date      09 apr 2019 - 09 apr 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public class SystemStatus {
	private String version = "0.0.0-alpha";
	private boolean dbInError;
	private boolean networkInError;
	private NetworkSummary network = new NetworkSummary();

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}
	/**
	 * @return the dbIsInError
	 */
	public boolean isDbInError() {
		return dbInError;
	}
	/**
	 * @param dbIsInError the dbIsInError to set
	 */
	public void setDbIsInError(boolean dbInError) {
		this.dbInError = dbInError;
	}
	/**
	 * @return the networkInError
	 */
	public boolean isNetworkInError() {
		return networkInError;
	}
	/**
	 * @param networkInError the networkInError to set
	 */
	public void setNetworkInError(boolean networkInError) {
		this.networkInError = networkInError;
	}
	/**
	 * @return the network
	 */
	public NetworkSummary getNetwork() {
		return network;
	}

	static public class NetworkSummary {
		protected int totalNodes;
		protected int disconnectedNodes;
		protected int totalConnections;
		protected int totalErrorConnections;
		protected int dailyErrorConnections;
	}
}
