package com.domux.center.monitoring;

import java.io.Serializable;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Represent a single monitoring event generate and stored on events register.<br>
 * Events can be notifications, alarms, errors, system errors, network traffic.
 * More events can link to same transaction, basically the first registration event<br>
 * return the transaction identifier used in the other registration of same transaction
 * 
 * @project   domuxCenter
 * 
 * @module    MonitorEvent.java
 * 
 * @date      09 mag 2019 - 09 mag 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */

public interface MonitorEvent {
	/**
	 * List of event type. clazz attribute represent a grouping of types 
	 * @date      27/mag/2014 - 27/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	enum Type {
		NOTIFY("N"),
		ALLARM("N"),
		NETWORK("N"),
		NETWORKERROR("E"),
		ERROR("E"),
		SYSERROR("E");
		
		private String clazz;
		Type(String clazz) {
			this.clazz = clazz;
		}
	}
	/**
	 * Single event data
	 * @date      19/mag/2014 - 19/mag/2014
	 * @author    Fernando
	 * @revisor   Fernando
	 */
	public static class EventData implements Serializable {
		private static final long serialVersionUID = -2607144071568528591L;
		/** transaction identifier */
		protected int transId;
		/** timestamp of event */
		protected Calendar time;
		/** Event type */
		protected Type type;
		/** Event message */
		protected String message;
		/** Event target */
		protected Monitorable target;
		/** Event data. This is NOT JSON property */
		protected Object data; 
		/** Event target. This is NOT JSON property */
		protected String callerClassName;
		
		/**
		 * Convert event to JSON.<br>
		 * Key returned: 
		 * 		time	event time (dd-MM-yyyy HH:mm:ss)<br>
		 * 		msec	event milliseconds time
		 * 		transid	event transaction identifier
		 * 		type	event type
		 * 		class	event type clazz attribute
		 * 		msg		event message
		 * 		target	evet target classified {@link com.domux.center.monitoring.Monitorable#getClassifyData()}
		 * @date      31 mar 2019 - 31 mar 2019
		 * @author    Fernando Costantino
		 * @revisor   Fernando Costantino
		 * @return	  map with key and value
		 */
		public Map<String,Object> toJSON() {
			Map<String,Object> ret = new HashMap<String,Object>();
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			ret.put("time", df.format(this.time.getTime()));
			ret.put("msec", this.time.getTimeInMillis());
			ret.put("transid", this.transId);
			ret.put("type", this.type.name());
			ret.put("class", this.type.clazz);
			ret.put("msg", this.message);
			ret.put("target", this.target!=null?this.target.getClassifyData():"");
			ret.put("data", this.data!=null?this.data.toString():"");
			return ret;
		}
	}
	/**
	 * Register an event
	 * @date      31 mar 2019 - 31 mar 2019
	 * @param	  transId transaction identifier, if null create a new when return
	 * @param	  type Event type
	 * @param	  message message of event
	 * @param	  target target of event
	 * @param	  data optional event data
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  transaction identifier
	 */
	public int registerEvent(Integer transId, Type type, String message, Monitorable target, Object data);
	/**
	 * Register an event
	 * @date      31 mar 2019 - 31 mar 2019
	 * @param	  transId transaction identifier, if null create a new when return
	 * @param	  type Event type
	 * @param	  message message of event
	 * @param	  target target of event
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  transaction identifier
	 */
	public int registerEvent(Integer transId, Type type, String message, Monitorable target);
	/**
	 * Register an event
	 * @date      31 mar 2019 - 31 mar 2019
	 * @param	  transId transaction identifier, if null create a new when return
	 * @param	  type Event type
	 * @param	  message message of event
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 * @return	  transaction identifier
	 */
	public int registerEvent(Integer transId, Type type, String message);
}
