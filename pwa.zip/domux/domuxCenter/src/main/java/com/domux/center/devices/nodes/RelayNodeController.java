package com.domux.center.devices.nodes;

import com.domux.center.devices.DeviceManager;
import com.domux.center.devices.DomuxProtocol;
import com.domux.center.model.Node;
import com.domux.center.model.Resource;
import com.nandox.libraries.Configuration;
import com.nandox.libraries.Return;

/**
 * Controller specific for all RELAY type node.
 * This node use resource on/off with a simple value boolean
 * 
 * @project   domuxCenter
 * 
 * @module    RelayNodeController.java
 * 
 * @date      30 mar 2019 - 30 mar 2019
 * 
 * @author    Fernando Costantino
 * 
 * @revisor   Fernando Costantino
 */
public class RelayNodeController extends AbstractNode implements NodeController {

	/* (non-Javadoc)
	 * @see com.domux.center.devices.nodes.NodeController#getResourceValueClass()
	 */
	public Class<?> getResourceValueClass() {
		return ResourceOnOff.class;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.NodeController#AbstractNode(com.domux.center.devices.DeviceManager)
	 */
	public RelayNodeController(DeviceManager devman) {
		super(devman);
	}
	/* Use domux command READ to get all device's resources value and populate node POJO 
	 * @see com.domux.center.devices.NodeController#readResourceValue(com.domux.center.model.Node)
	 */
	public Return readResourceValue(Node node) {
		String cmd = "";
		if ( node.getResourceList() != null ) {
			for ( Resource r : node.getResourceList() ) {
				if ( r != null && r.getValue() == null )
					r.setValue(new ResourceOnOff());
				cmd += (cmd.isEmpty()?"":",") + r.getId();
			}
			Return ret = this.devman.executeDomuxProtocolCommand(node, 
				    DomuxProtocol.Service.RELAY, DomuxProtocol.Command.READ,cmd);
			if ( ret.getCode() == Return.RET_OK ) {
				String[] val = ret.getApplMsg().split(",");
				int ix = 0;
				for ( Resource r : node.getResourceList() ) {
					((ResourceOnOff)r.getValue()).isOn = "1".equals(val[ix++]);
				}
			}
			return ret;
		}
		return new Return(Return.RET_OK, null);
	}
	/* Use domux command WRITE to put specific resource value to device 
	 * @see com.domux.center.devices.nodes.NodeController#writeResourceValue(com.domux.center.model.Node, com.domux.center.model.Resource)
	 */
	public Return writeResourceValue(Node node, Resource res) {
		Return r = this.devman.executeDomuxProtocolCommand(node, 
			    DomuxProtocol.Service.RELAY, DomuxProtocol.Command.FIRE, 
			    res.getId()+"="+(((ResourceOnOff)res.getValue()).isOn?"1":"0"));
		if ( r.getCode() == Return.RET_OK ) {
			((ResourceOnOff)res.getValue()).isOn = r.getApplMsg().equals("1");
		}
		return r;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.nodes.NodeController#fillInitialResourceValue(com.domux.center.model.Node)
	 */
	@Override
	public void fillInitialResourceValue(Node node) {
		for ( Resource r : node.getResourceList() ) {
			if ( r != null && r.getValue() == null )
				r.setValue(new ResourceOnOff());
		}
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.nodes.NodeController#createNodeFromConfiguration(com.nandox.libraries.Configuration)
	 */
	public Node createNodeFromConfiguration(Configuration cfg) {
		Node n = this.buildNodeFromConfiguration(cfg);
		// Set resource configurations
		for ( Resource r: n.getResourceList() ) {
			r.setId("RELAY"+(n.getResourceList().indexOf(r)+1));
			r.setDxid(n.getDxid()+"."+r.getId());
			String s = cfg.getStringValue(r.getId()+".NAME", "");
			if ( !s.isEmpty() )
				r.setName(s);
			s = cfg.getStringValue(r.getId()+".TYPE", "");
			if ( !s.isEmpty() )
				r.setType(Enum.valueOf(Resource.Type.class, s));
			if ( r.getValue() == null )
				r.setValue(new ResourceOnOff());
			// set switch duration
			try {
				int time = cfg.getIntValue(r.getId()+".TIME");
				((ResourceOnOff)r.getValue()).switchDuration = time;
			} catch ( Exception e) {
				// TODO: gestire eccezione
			}
		}
		return n;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.nodes.AbstractNode#buildConfigurationFromNode(com.domux.center.model.Node)
	 */
	@Override
	protected Configuration buildConfigurationFromNode(Node node) {
		Configuration cfg = super.buildConfigurationFromNode(node);
		for ( Resource r: node.getResourceList() ) {
			cfg.setStringValue(r.getId()+".TIME", ""+((ResourceOnOff)r.getValue()).switchDuration);
		}
		return cfg;
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.nodes.NodeController#sendConfigurationToDevice(com.domux.center.model.Node, com.domux.center.model.Node)
	 */
	public void sendConfigurationToDevice(Node node, Node toUpdate) throws Exception {
		this.sendConfigurationToDomux(node, toUpdate);
	}

	/* (non-Javadoc)
	 * @see com.domux.center.devices.nodes.NodeController#alignConfiguration(com.domux.center.model.Node, com.domux.center.model.Node)
	 */
	@Override
	public void alignConfiguration(Node src, Node dst) {
		for ( Resource r : src.getResourceList() ) {
			Resource rd = dst.getResourceById(r.getId());
			if ( rd != null ) {
				((ResourceOnOff)rd.getValue()).isOn = ((ResourceOnOff)r.getValue()).isOn; 
				((ResourceOnOff)rd.getValue()).switchDuration = ((ResourceOnOff)r.getValue()).switchDuration; 
			}
		}
	}
	/* (non-Javadoc)
	 * @see com.domux.center.devices.nodes.NodeController#ping(com.domux.center.model.Node)
	 */
	public boolean ping(Node node) {
		return this.sendPing(node);
	}

	/**
	 * Resource whit on off value   
	 * @date      30 mar 2019 - 30 mar 2019
	 * @author    Fernando Costantino
	 * @revisor   Fernando Costantino
	 */
	public static class ResourceOnOff {
		protected boolean isOn;
		protected Integer switchDuration;
	}

}
