package javax.bluetooth;

public class Initializer {
	public static void Restart() {
		try {
			com.intel.bluetooth.BlueCoveImpl.instance().getBluetoothStack().destroy();
			com.intel.bluetooth.BlueCoveImpl.instance().getBluetoothStack().initialize();
		} catch (Exception e) {
			e = null;
		}
	}
}
