var Domux = Domux || {};

(function (libroot) {
	
	// Constant definition
	this.CONST = Object.freeze({
		"$INJECTREF": '#temporary',
		"DEBUG": true,
		"CONFIGPANEL": '#config-nodelist',
		"MAPPANEL": '#config-map-container',
		"HOME": '#mainMap',
		"RESOURCENAMEMAXLEN": 32
	});
	this.URL = Object.freeze({
		"NODELIST": '/domuxCenter/restservice/getnodelist',		
		"DISCOVERY": '/domuxCenter/restservice/discovery',		
		"SENDNODE": '/domuxCenter/restservice/sendnode',		
		"DELETENODE": '/domuxCenter/restservice/deletenode',		
		"MAP": 		'/domuxCenter/restservice/getmap',
		"MAPSTYLE":	"/domuxCenter/restservice/getmapstyle",
		"USERS": 		'/domuxCenter/restservice/getusers',
		"SENDMAPIMAGE": '/domuxCenter/restservice/sendmapimage',
		"SENDMAP": '/domuxCenter/restservice/sendmap',		
		"SENDRESOURCE": '/domuxCenter/restservice/sendresource',		
		"SENDUSER":		'/domuxCenter/restservice/senduser',
		"DELETEUSER": '/domuxCenter/restservice/deleteuser'		
	});
	
	this.defines = Object.freeze({
		"BAUD": window.baudrate	
	}); 
	// private variable
	var nodelist = [];
	var menuPages = {};
	
	var $dom = libroot.Dom;
	var $util = libroot.Utils;
	var $comp = libroot.Component;
	var $ajax = libroot.Ajax;
	
	var globalspinner = new libroot.Component.Globalspinner(libroot.Dom.qry(document,'.nx-spinner'));

	this.wrongAuth = false;
	this.versionPWA = VERSION;
		
	function compositeMap(map,nodelist) {
		var ret = [];
		var res = $util.flat($util.map(nodelist,function(o){
					return o.resourceList;
				  })
		);
		for( var ix=0; ix<map.length; ix++ ) {
			var item = libroot.clone(map[ix]);
			var r = res.find(function(o){ return o.dxid == item.dxid});
			if ( r != null  ) {
				libroot.clone(r,item);
				var dxid = item.dxid.split(".")[0];
				for ( var i=0; i<nodelist.length; i++ ) {
					if ( nodelist[i].dxid == dxid ) {
						item.nodeStatus = nodelist[i].status; 
					}
				}
			}
			ret.push(item);
		}
		return ret;
	}
	
	this.openMenu = function(page) {
		var _this = this;
		if ( !menuPages[page] ) {
			$ajax.ajax(page,{},'GET',{type: 'text/html'}).done = function(response) {
				var el = $dom.qry(document,_this.CONST.$INJECTREF);
				$dom.injectHtml(el,response);
				$comp.initComponents(el);
				var keys = Object.keys(menuPages);
				if ( keys.length > 0 )
					menuPages[keys[keys.length-1]] = false;
				menuPages[page] = true;
			}
		}
	}
	this.closeMenu = function(page) {
		var _this = this;
		var el = $dom.qry(document,_this.CONST.$INJECTREF) || {};
		el.innerHTML = '';
		delete menuPages[page];
		var keys = Object.keys(menuPages);
		if ( keys.length > 0 )
			_this.openMenu(keys[keys.length-1]);
	}
	this.readNodeList = function() {
		var _this = this;
		libroot.Rest.JsendReadData(this.options.addrCenter+this.URL.NODELIST,{}).settransform(function(data){
			return (data.nodelist?data.nodelist:data);
		}).setsuccess(function(data){
			nodelist = data;
			nodelist.forEach(function(o){
				o.resourceList.forEach(function(r){
					r.class = NodeDefinitions[o.type].resourceComponent;
				});
			});
			
		    /*caches.open("domuxData").then(function(cache) {
		    	cache.put("nodelist",new Response(JSON.stringify(nodelist)));
		    })*/

			_this.nodelist = nodelist;
			var v = libroot.Component.getInstance(libroot.Dom.qry(document,_this.CONST.CONFIGPANEL + ' .p-container[tab-id="nodelist"]'));
			if ( v != null )
				v.vueApp.nodes = nodelist;
			v = libroot.Component.getInstance(libroot.Dom.qry(document,_this.CONST.CONFIGPANEL + ' .p-container[tab-id="map"]'));
			if ( v != null )
				v.vueApp.nodes = nodelist;
			v = libroot.Component.getInstance(libroot.Dom.qry(document,'#mainMap'));
			if ( v != null )
				v.vueApp.nodes = nodelist;
		}).seterror(function(code,message,data){
			_this.showError(code,message,data);
		}).setcatch(function(code,message,data){
			/*caches.open('domuxData').then(function(cache) {
				cache.match("nodelist").then(function(response) {
					response.json().then(function(data){
						_this.nodelist = data;
						var v = libroot.Component.getInstance(libroot.Dom.qry(document,_this.CONST.CONFIGPANEL + ' .p-container[tab-id="nodelist"]'));
						if ( v != null )
							v.vueApp.nodes = data;
						v = libroot.Component.getInstance(libroot.Dom.qry(document,_this.CONST.CONFIGPANEL + ' .p-container[tab-id="map"]'));
						if ( v != null )
							v.vueApp.nodes = data;
						v = libroot.Component.getInstance(libroot.Dom.qry(document,'#mainMap'));
						if ( v != null )
							v.vueApp.nodes = data;
					});
				});
			});*/
		});
	};
	this.discoveryNodes = function() {
		var _this = this;
		return libroot.Rest.JsendReadData(this.options.addrCenter+this.URL.DISCOVERY,{}).seterror(function(code,message,data){
			//TODO: 
		}).settransform(function(data){
			return (data.nodelist?data.nodelist:data);
		}).setsuccess(function(data){
			nodelist = data;
			nodelist.forEach(function(o){
				o.resourceList.forEach(function(r){
					r.class = NodeDefinitions[o.type].resourceComponent;
				});
			});
			_this.nodelist = nodelist;
			var v = libroot.Component.getInstance(libroot.Dom.qry(document,_this.CONST.CONFIGPANEL + ' .p-container[tab-id="nodelist"]'));
			if ( v != null )
				v.vueApp.nodes = nodelist;
			v = libroot.Component.getInstance(libroot.Dom.qry(document,_this.CONST.CONFIGPANEL + ' .p-container[tab-id="map"]'));
			if ( v != null )
				v.vueApp.nodes = nodelist;
		}).setcatch(function(status,statusText,response){
			_this.showError(status,statusText);
		});
	};
	this.readMap = function() {
		var _this = this;
		libroot.Rest.JsendReadData(this.options.addrCenter+this.URL.MAP,{}).seterror(function(code,message,data){
			// TODO: manage errror
		}).settransform(function(data){
			return (data.map?data.map:data);
		}).setsuccess(function(data){
		    /*caches.open("domuxData").then(function(cache) {
		    	cache.put("map",new Response(JSON.stringify(data)));
		    })*/
		    
			_this.map = data;
			var v = libroot.Component.getInstance(libroot.Dom.qry(document,_this.CONST.CONFIGPANEL + ' .p-container[tab-id="map"]'));
			if ( v != null )
				v.vueApp.map = compositeMap(_this.map,_this.nodelist);
			v = libroot.Component.getInstance(libroot.Dom.qry(document,_this.CONST.HOME));
			if ( v != null )
				v.vueApp.map = compositeMap(_this.map,_this.nodelist);
		}).setcatch(function(code,message,data){
			/*caches.open('domuxData').then(function(cache) {
				cache.match("map").then(function(response) {
					response.json().then(function(data){
						_this.map = data;
						var v = libroot.Component.getInstance(libroot.Dom.qry(document,_this.CONST.CONFIGPANEL + ' .p-container[tab-id="map"]'));
						if ( v != null )
							v.vueApp.map = compositeMap(_this.map,_this.nodelist);
						v = libroot.Component.getInstance(libroot.Dom.qry(document,_this.CONST.HOME));
						if ( v != null )
							v.vueApp.map = compositeMap(_this.map,_this.nodelist);
					});
				});
			});*/
		});
	};
	this.nodelist = nodelist;
	this.sendNode = function(node) {
		globalspinner.open();
		var _this = this;
		if ( node ) {
			return libroot.Rest.JsendModifyData(this.options.addrCenter+this.URL.SENDNODE,node).seterror(function(code,message,data){
				_this.showError(code,message,data);
			}).setalways(function(data){
				globalspinner.close();
				return data;
			}).setcatch(function(status,statusText,response){
				_this.showError(status,statusText);
			});
		}
	}
	this.deleteNode = function(node) {
		globalspinner.open();
		var _this = this;
		if ( node ) {
			return libroot.Rest.JsendModifyData(this.options.addrCenter+this.URL.DELETENODE,node.dxid).seterror(function(code,message,data){
				_this.showError(code,message,data);
			}).setcatch(function(status,statusText,response){
				_this.showError(status,statusText);
			}).setalways(function(data){
				globalspinner.close();
				return data;
			});
		}
	}
	this.readMapImage = function() {
		var _this = this;
		return libroot.Rest.JsendReadData(this.options.addrCenter+this.URL.MAPSTYLE,{}).seterror(function(code,message,data){
			_this.showError(code,message,data);
		});
	};
	this.readUsers = function() {
		globalspinner.open();
		var _this = this;
		return libroot.Rest.JsendReadData(this.options.addrCenter+this.URL.USERS,{}).seterror(function(code,message,data){
			_this.showError(code,message,data);
		}).setcatch(function(status,statusText,response){
			_this.showError(status,statusText);
		}).setalways(function(data){
			globalspinner.close();
			return data;
		});
	};
	this.sendUser = function(user) {
		globalspinner.open();
		var _this = this;
		if ( user ) {
			return libroot.Rest.JsendModifyData(this.options.addrCenter+this.URL.SENDUSER,user).seterror(function(code,message,data){
				_this.showError(code,message,data);
			}).setcatch(function(status,statusText,response){
				_this.showError(status,statusText);
			}).setalways(function(data){
				globalspinner.close();
				return data;
			});
		}
	}
	this.deleteUser = function(user) {
		globalspinner.open();
		var _this = this;
		if ( user ) {
			return libroot.Rest.JsendModifyData(this.options.addrCenter+this.URL.DELETEUSER,user).seterror(function(code,message,data){
				_this.showError(code,message,data);
			}).setcatch(function(status,statusText,response){
				_this.showError(status,statusText);
			}).setalways(function(data){
				globalspinner.close();
				return data;
			});
		}
	}

	this.sendMapImage = function(image,callbacks) {
		globalspinner.open();
		var _this = this;
		if ( image ) {
			return libroot.Rest.JsendModifyData(this.options.addrCenter+this.URL.SENDMAPIMAGE,image).seterror(function(code,message,data){
				_this.showError(code,message,data);
			}).setalways(function(data){
				globalspinner.close();
				return data;
			}).setfail(function(data){
				if ( callbacks && callbacks.setFailField) {
					callbacks.setFailField.call(callbacks,data);
				}
			}).setcatch(function(status,statusText,response){
				_this.showError(status,statusText);
			});
		}
	}
	this.sendMap = function(map,callbacks) {
		globalspinner.open();
		var _this = this;
		if ( map ) {
			return libroot.Rest.JsendModifyData(this.options.addrCenter+this.URL.SENDMAP,map).seterror(function(code,message,data){
				_this.showError(code,message,data);
			}).setalways(function(data){
				globalspinner.close();
				return data;
			}).setfail(function(data){
				if ( callbacks && callbacks.setFailField) {
					callbacks.setFailField.call(callbacks,data);
				}
			}).setcatch(function(status,statusText,response){
				_this.showError(status,statusText);
			});
		}
	}
	this.sendResource = function(res) {
		var _this = this;
		if ( res ) {
			return libroot.Rest.JsendModifyData(this.options.addrCenter+this.URL.SENDRESOURCE,res).seterror(function(code,message,data){
				_this.showError(code,message,data);
			}).setfail(function(data){
				var keys = Object.keys(data);
				var msg = window.labels['ERROR_FAIL_SETTING_RESOURCE'] || 'ERROR_FAIL_SETTING_RESOURCE';
				msg += '<br>';
				for ( var k in keys ) {
					msg += window.labels[data[keys[k]]] || data[keys[k]];
					msg += '<br>';
				}
				Domux.showWarn('', msg);
				data = null;
			}).setcatch(function(status,statusText,response){
				_this.showError(status,statusText);
			});
		}
	}
	this.showError = function(code,message,data) {
		var modal = new libroot.Component.Modal(libroot.Dom.qry(document,'#dialog-error'));
		libroot.Dom.qry(modal.el,'#dialog-error-message .p-content').innerHTML = message;
		libroot.Dom.qry(modal.el,'#dialog-error-message .p-head .p-title').innerHTML = code;
		libroot.Dom.qry(modal.el,'#dialog-error-stack .p-content').innerHTML = ((data || {}).stack || '').split('\n').join('<br>');
		modal.open();
	}
	this.showWarn = function(code,message) {
		var modal = new libroot.Component.Modal(libroot.Dom.qry(document,'#dialog-warn'));
		libroot.Dom.qry(modal.el,'.p-content').innerHTML = message;
		modal.open();
	}
	this.baseVue = {
		computed: {
			isPhone: function() {
				return libroot.isScreenMobilePhone();
			}
		},
		methods: {
			showFail: function(failData,title) {
				var keys = Object.keys(failData);
				var data = window.labels[title] || title;
				data += '<br>';
				for ( var k in keys ) {
					data += window.labels[failData[keys[k]]] || failData[keys[k]];
					data += '<br>';
				}
				Domux.showWarn('', data);
			}
		}
	}
	this.config = {
		mixins: [this.baseVue],
		data: function() {
			return {
				nodes: [],
				isEditing: false,
				showDetails: false
			}
		},
		computed: {
		},
		methods: {
			toggleEditing: function() {
				this.isEditing = !this.isEditing;
			},
			goBack: function() {
				this.showDetails = false;
			}
		}
	};
	this.resourceComponent = {
		mixins: [this.baseVue],
		props: {
			"value": {},
			"draggable": { type: Boolean, "default": false},
			"styleClass": { type: String },
			"imagePath": { type: String },
			"left": { type: Number},
			"top": { type: Number},
			"allarm": { type: Boolean, "default": false},
		},
		data: function() {
			return {
				fieldsError: {name:''}
			}
		},
		computed: {
			image: function() {
				return this.imagePath+(this.value || {}).type+'.png';
			}
		},
		methods: {
			validate: function(data) {
				if ( data.name == '' || data.name.length > Domux.RESOURCENAMEMAXLEN ) {
					this.fieldsError.name = window.labels['ERROR_FIELD_RESOURCE_NAME'];
					return false;
				}
				return true;
			},
			drag: function(ev) {
 				var el = libroot.Dom.parentSelector(ev.target,'[res-id]');
				if ( el != null )
					ev.dataTransfer.setData("text", el.getAttribute('res-id'));
			}
		}
	};
	this.configNode = {
		mixins: [this.config],
		data: function() {
			return {
				currentNode: {},
				backNode: { name: ''},
				fieldsError: {name:'',
							  addrI2C:'',
							  addrIP:''
						  	 },
				isInDiscovery: false
			}
		},
		computed: {
			currentConfigComponent: function() {
				return NodeDefinitions[this.currentNode.type].configComponent;
			}
		},
		methods: {
			getImgByTypeNode: function (type) {
				var img = 'images/'+NodeDefinitions[type].icon;
				return img;
			},
			getDescrByTypeNode: function(type) {
				return NodeDefinitions[type].description;
			},
			getDescrByStatusNode: function(status) {
				switch (status) {
					case 'REGISTERED':
						return 'Registrato';
						break;
					case 'UNREGISTERED':
						return 'Non Registrato';
						break;
					case 'LOST':
						return 'Scollegato';
						break;
				}
				return '';
			},
			discovery: function() {
				if ( !this.isInDiscovery ) {
					this.isInDiscovery = true;
					var _this = this;
					Domux.discoveryNodes().setsuccess(function(data){
						_this.isInDiscovery = false;
					});
				}
			},
			openNode: function(dxid) {
				this.fieldsError = {name:'',
						  addrI2C:'',
						  addrIP:''
					  	 };
				for ( var ix=0; ix<this.nodes.length; ix++ ) {
					if (this.nodes[ix].dxid == dxid) {
						this.currentNode = libroot.clone(this.nodes[ix]);
						break;
					}
				}
				this.showDetails = true;
				this.isEditing = false;
				Vue.nextTick(function(){
					this.modal = new libroot.Component.Modal(libroot.Dom.qry(this.$el,'.nx-modal'));
					this.modal.onclosing = this.onClosing;
				},this);
			},
			toggleEditing: function() {
				this.isEditing = !this.isEditing;
				if ( this.isEditing ) {
					this.backNode  = libroot.clone(this.currentNode);
				} else {
					this.currentNode = this.backNode;  
					this.fieldsError = {name:'',
							  addrI2C:'',
							  addrIP:''
						  	 };
				}
			},
			saveCurrentNode: function() {
				this.fieldsError = {name:'',
						  addrI2C:'',
						  addrIP:''
					  	 };
				var _this = this;
				Domux.sendNode(this.currentNode).setsuccess(function(data){
					_this.saved(data);
				}).setfail(function(data){
					_this.setFailField(data);
				});
			},
			deleteCurrentNode: function() {
				var _this = this;
				Domux.deleteNode(this.currentNode).setsuccess(function(data){
					_this.saved();
					Vue.nextTick(function(){
						_this.goBack();
					});
				}).setfail(function(data){
					_this.showFail(data,'ERROR_FAIL_NODE_DELETE');
				});
			},
			saved: function(data) {
				if ( data ) {
					this.currentNode.dxid = data.dxid;
					this.currentNode.status = data.status;
				}
				this.isEditing = false;
				Domux.readNodeList();
				Domux.readMap();
			},
			setFailField: function(failData) {
				var keys = Object.keys(failData);
				for ( var k in keys ) {
					this.fieldsError[keys[k]] = window.labels[failData[keys[k]]] || failData[keys[k]];
				}
			}
		},
		watch: {
		},
		mounted: function() {
		}
	}
	this.viewMap = {
		mixins: [this.baseVue],
		data: function() {
			return {
				nodes: [],
				map: [],
				resourcesMapped: [],
				fileBG: {
					name:'',
					file: null,
					data: null,
					height: 0,
					width: 0
				},
				deltaW: '0px',
				deltaH: '0px'
			}
		},
		computed: {
			mapStyle: function() {
				if ( this.fileBG.data != null )
					return {
						'background-image': 'url("'+this.fileBG.data+'")',
						'min-width': 'calc('+this.fileBG.width+'px - ('+this.deltaW+'))',
						'height': 'calc('+this.fileBG.height+'px - ('+this.deltaH+'))',
						   };
				else
					return { 'flex-grow': 1};
			},
			backgroundIsLoaded: function() {
				return this.fileBG.name != '';
			}
		},
		watch: {
			"map": function() {
				this.resourcesMapped = [];
				for ( var ix=0; ix<this.map.length; ix++ ) {
					this.resourcesMapped.push(libroot.clone(this.map[ix]));
				}
			},
			"nodes": function() {
				for ( var ix=0; ix<this.resourcesMapped.length; ix++ ) {
					var dxid = this.resourcesMapped[ix].dxid.split(".")[0];
					for ( var i=0; i<this.nodes.length; i++ ) {
						if (this.nodes[i].dxid == dxid) {
							this.resourcesMapped[ix].nodeStatus = this.nodes[i].status;
							for ( var ir=0; ir<this.nodes[i].resourceList.length; ir++ ) {
								if ( this.nodes[i].resourceList[ir].id == this.resourcesMapped[ix].id ) {
									this.resourcesMapped[ix].value = this.nodes[i].resourceList[ir].value;
									break;
								}
							}
							break;
						}
					}
				}
			}
		},
		mounted: function() {
			var _this = this;
			if ( !Domux.options.initlialized)
				return;
			Domux.readMapImage().setsuccess(function(data){
				_this.fileBG.name = "loaded";
				_this.fileBG.data = data.data;
				_this.fileBG.height = data.height;
				_this.fileBG.width = data.width;
			    /*caches.open("domuxData").then(function(cache) {
			    	cache.put("mapImage",new Response(JSON.stringify(data)));
			    })*/
			}).setcatch(function(code,message,data){
				/*caches.open('domuxData').then(function(cache) {
					cache.match("mapImage").then(function(response) {
						response.json().then(function(data){
							_this.fileBG.name = "loaded";
							_this.fileBG.data = data.data;
							_this.fileBG.height = data.height;
							_this.fileBG.width = data.width;
						});
					});
				});*/
			});
			Domux.readMap();
		}
	}
	this.configMap = {
		mixins: [this.config,this.viewMap],
		data: function() {
			return {
				//map: [],
				showResourceCarousel: false,
				showPanelChangeWidth: false,
				showPanelChangeHeight:false,
				tobeRefreshed: 0
			}
		},
		computed: {
			resourcesFree: function() {
				return $util.difference($util.map(
						$util.flat($util.map(this.nodes,function(o){
							return $util.map(o.resourceList,function(r){
								r.class = NodeDefinitions[o.type].resourceComponent;
								return r;
							});
						})),
						function(o) { 
							return o;
						}
				),this.resourcesMapped,function(a,b){
					return a.dxid == b.dxid;
				});
			},
			enableResize: function() {
				return this.isEditing && this.backgroundIsLoaded;
			}
		},
		methods: {
			getNodeStatusByResource: function(res) {
				var dxid = (res || {dxid:""}).dxid.split(".")[0];
				var node = $util.filter(this.nodes,function(o){
					return o.dxid == dxid;
				});
				return node.length==1?node[0].status:'UNREGISTERED';
			},
			allowDrop: function(ev) {
				if ( !this.isEditing )
					return false;
				ev.preventDefault();
			},
			/*drag: function(ev) {
				ev.dataTransfer.setData("text", ev.target.id);
			},*/
			drop: function(ev) {
				 ev.preventDefault();
				 var data = ev.dataTransfer.getData("text");
				 if ( data != null ) {
					 var arr = $util.concat(this.resourcesFree,this.resourcesMapped).filter(function(o){
						 		return o.dxid == data;
					 		});
					 if ( this.getNodeStatusByResource(arr[0]) == 'UNREGISTERED' ) {
							var data = window.labels['WARNLOCAL_UNDRAGGABLE_RESOURCE'] || 'WARNLOCAL_UNDRAGGABLE_RESOURCE';
							Domux.showWarn('', data);
					 } else if ( arr.length > 0 ) {
						 arr[0].x = ev.offsetX;
						 arr[0].y = ev.offsetY;
						 if ( this.resourcesMapped.filter(function(o){
						 			return o.dxid == arr[0].dxid;
					 			}).length == 0 
						 ) {
							 this.resourcesMapped.push(arr[0]);
						 }
					 }
					 this.tobeRefreshed++;
				 }
			},
			erase: function(ev) {
				 ev.preventDefault();
				 var data = ev.dataTransfer.getData("text");
				 $util.remove(this.resourcesMapped,function(o){
					 return o.dxid == data;
				 });
			},
			onFileChange: function(files) {
				// check size
				this.fileBG.name = files[0].name;
				this.fileBG.file = files[0];
				var _this = this;
			    var img = new Image();
				var reader = new FileReader();
			    reader.onload = function(e) {
			    	_this.fileBG.data = e.target.result;
				    img.src = e.target.result;
			    }
			    img.onload = function(){
			    	_this.fileBG.height = img.height;
			    	_this.fileBG.width = img.width;
			    }
			    reader.readAsDataURL(files[0]);
			},
			clearFile: function() {
				this.fileBG.name = '';
				this.fileBG.file = null;
				this.fileBG.data = null;
		    	this.fileBG.height = 0;
		    	this.fileBG.width = 0;
		    	libroot.Dom.qry(this.$el,'input[type="file"]').value = '';
			},
			changeSize: function(directionW,directionH) {
				switch (directionW+''+directionH) {
					case '00':
						var e = libroot.Dom.qry(this.$el,Domux.CONST.MAPPANEL);
						if ( e != null ) {
							var style = window.getComputedStyle(e);
							//this.deltaW = style.paddingLeft + ' + ' + style.paddingRight; 
							//this.deltaH = style.paddingTop + ' + ' + style.paddingBottom; 
					    	this.fileBG.height = e.clientHeight;
					    	this.fileBG.width = e.clientWidth;
						}
						break;
					case '01':
				    	this.fileBG.height += 10;
						break;
					case '0-1':
				    	this.fileBG.height -= 10;
						break;
					case '10':
				    	this.fileBG.width += 10;
						break;
					case '-10':
				    	this.fileBG.width -= 10;
						break;
				}
			},
			save: function() {
				var map = $util.map(this.resourcesMapped,function(o){
					return { dxid: o.dxid, x: o.x, y: o.y };
				});
				/*Domux.sendMapImage({
					data: this.fileBG.data,
					height: this.fileBG.height,
					width: this.fileBG.width
				},this).and(
						Domux.sendMap(map,this)
				).setsuccess(this.saved);*/
				var _this = this;
				Domux.sendMapImage({
					data: this.fileBG.data,
					height: this.fileBG.height,
					width: this.fileBG.width
				},this).setsuccess(function(){
					Domux.sendMap(map,_this).setsuccess(_this.issaved);
				});
			},
			issaved: function() {
				this.isEditing = false;
			},
			setFailField: function(failData) {
				var keys = Object.keys(failData);
				var data = window.labels['ERROR_FAIL_MAP_DATA'] || 'ERROR_FAIL_MAP_DATA';
				data += '<br>';
				for ( var k in keys ) {
					data += window.labels[failData[keys[k]]] || failData[keys[k]];
					data += '<br>';
				}
				Domux.showWarn('', data);
			}
		},
		watch: {
			'isEditing': function(value) {
				if ( !value ) {
					this.showResourceCarousel = false;
					this.showPanelChangeWidth = false;
					this.showPanelChangeHeight = false;	
				}
			}
		},
		mounted: function() {
			this.changeSize(0,0);
		}
	}
	this.configUsers = {
		mixins: [this.config],
		data: function() {
			return {
				users: [],
				currentUser: {},
				backUser: {name:''},
				fieldsError: {name:'',
							  password:'',
							  role: ''
				  	 		},
				showPassword: false
			}
		},
		computed: {
			isAdmin: function() {
				return this.currentUser.name == 'admin' && this.currentUser.id != 0;
			},
			isNew: function() {
				return this.currentUser.id == 0;
			}
		},
		methods: {
			update: function() {
				var _this = this;
				Domux.readUsers().setsuccess(function(data){
					_this.users = data;
				});
			},
			addUser: function () {
				this.fieldsError = {name:'',
			  			password:'',
			  			role: ''
		  	 			};
				this.isEditing = true;
				this.currentUser = { id: null,
									 name: '',
									 password: '',
									 role: 'user'
									 };
				this.showDetails = true;
			},
			openUser: function(index) {
				this.fieldsError = {name:'',
			  			password:'',
			  			role: ''
		  	 			};
				if ( index >= 0 && index < this.users.length ) {
					this.currentUser = libroot.clone(this.users[index]);
					this.showDetails = true;
				}
			},
			toggleEditing: function() {
				this.isEditing = !this.isEditing;
				if ( this.isEditing ) {
					this.backUser  = libroot.clone(this.currentUser);
				} else {
					this.currentUser = this.backUser;  
					this.fieldsError = {name:'',
							  password:''
						  	 };
				}
			},
			deleteCurrentUser: function() {
				var _this = this;
				Domux.deleteUser(this.currentUser).setsuccess(function(data){
					_this.users = data;
					_this.isEditing = false;
					Vue.nextTick(function(){
						_this.goBack();
					});
				}).setfail(function(data){
					_this.setFailField(data);
				});
			},
			saveCurrentUser: function() {
				this.fieldsError = {name:'',
						  			password:'',
						  			role: ''
					  	 			};
				var _this = this;
				Domux.sendUser(this.currentUser).setsuccess(function(data){
					_this.isEditing = false;
					_this.users = data;
				}).setfail(function(data){
					_this.setFailField(data);
				});
			},
			setFailField: function(failData) {
				var keys = Object.keys(failData);
				for ( var k in keys ) {
					this.fieldsError[keys[k]] = window.labels[failData[keys[k]]] || failData[keys[k]];
				}
			}
		},
		watch: {
			'showPassword': function(value) {
				if ( value )
					nx.Dom.qry(this.$el,'.nx-password input').setAttribute('type','text');
				else
					nx.Dom.qry(this.$el,'.nx-password input').setAttribute('type','password');
			}
		},
		mounted: function() {
			if ( Domux.options.initlialized)
				this.update();
		}
	}
	libroot.Rest.setGlobalCatch(function(status,statusText,response){
		if ( status != 0 && status != 401 && status != 404 )
			Domux.showError(status,statusText);
		if ( status == 401 )
			Domux.wrongAuth = true;
		if ( status == 0 || status == 404 )
			Domux.connectionLost = true;
	});
	libroot.Rest.setGlobalSuccess(function(response){
		Domux.connectionLost = false;
	});
}).call( Domux,nx );

var DefinesPlugin = (function(){
	function install(Vue) {
	    Object.defineProperties(Vue.prototype, {
	    	$define: {
	        	get: function get () {
	        	      return function (key) {
	        	    	return Domux.defines[key];  
	        	      }
	       	    }
	        }
	    });
	};
	var definesPlugin = function() {};
	definesPlugin.install = install;
	definesPlugin.version = "1.0.0";
	return definesPlugin;
})();	

if (typeof window !== 'undefined' && window.Vue) {
    window.Vue.use(DefinesPlugin);
}
