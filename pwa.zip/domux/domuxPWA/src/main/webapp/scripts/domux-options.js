var Domux = Domux || {};

(function (libroot) {
	var CONST = Object.freeze({
		"$INJECTREF": '#temporary',
		"$BAR": '#options #addr_search_bar',
		"CENTERSIGN": 'domuxCenter',
		"NETMASK": 24
	});
	var URL = Object.freeze({
		"OPTIONPAGE": 'pages/options.html',
		"CENTERBEACON": 'https://{0}:8843/domuxCenter/restservice/beacon',
		"UPDATE":'/domuxCenter/restservice/update'
	});

	var $dom = libroot.Dom;
	var $comp = libroot.Component;
	var $ajax = libroot.Ajax;
	
	var optionsOpen = false;
	this.options = {
			addrCenter: location.origin,
			//addrCenter: 'http://localhost:4503',
			user: '',
			password: '',
			initlialized: false
	}
	
	var keys = Object.keys(this.options);
	for ( var k in keys ) {
		if ( keys[k] != '__obj__' && window.localStorage.getItem('domuxOptions.'+keys[k]) != null )
			this.options[keys[k]] = window.localStorage.getItem('domuxOptions.'+keys[k]);
	} 
	if ( this.options.initlialized == 'true')
		this.options.initlialized = true;
	if ( this.options.initlialized == 'false')
		this.options.initlialized = false;
		
	$ajax.setGlobalOptions({'username':this.options.user, "password":this.options.password});
	
	this.openOptions = function() {
		this.openMenu(URL.OPTIONPAGE);
		return;
	};
	this.closeOptions = function() {
		this.closeMenu(URL.OPTIONPAGE);
		return;
	}
	this.saveOptions = function() {
		var keys = Object.keys(this.options);
		var init =  this.options.initlialized;
		this.options.initlialized = true;
		for ( var k in keys ) {
			if ( keys[k] != '__obs__' )
				window.localStorage.setItem('domuxOptions.'+keys[k], this.options[keys[k]]);
		} 
		$ajax.setGlobalOptions({'username':this.options.user, "password":this.options.password});
		Domux.wrongAuth = false;
		if ( !init )
			window.location.reload();
	}
	this.update = function() {
		var globalspinner = new libroot.Component.Globalspinner(libroot.Dom.qry(document,'.nx-spinner'));
		globalspinner.open();
		var req = $ajax.uploadFile(this.options.addrCenter+URL.UPDATE,$dom(document,'#update-input')[0],
				{'username':this.options.user,
			 	 'password':this.options.password
			 	});
		req.done = function(response) {
			globalspinner.close();
			if ( response.status == 'error' )
				Domux.showError(response.code,response.message,response.data);
			else
				libroot.showMessage(labels['LABEL_DIALOG_TITLE_SUCCESS'],labels['TEXT_UPDATE_DONE']);
		};
		req.error = function(status,statusText,response) {
			globalspinner.close();
			Domux.showError(status,statusText);
		};
		req.upload.onprogress = function() {
			console.log('---');
		}
	}
	var inprogress = false;
	this.searchCenter = function() {
		if ( inprogress )
			return;
		inprogress = true;
		var _this = this;
		var el = $dom.qry(document, CONST.$BAR);
		var inx = 1;
		var ret = $ajax.ipAddr.detect(function(ip) {
			$dom(el,'div').setStyle('width','0%');
			$dom.show(el);
		    var _1st = $ajax.ipAddr.rangeFirst(ip,CONST.NETMASK);
		    var last = $ajax.ipAddr.rangeLast(ip,CONST.NETMASK);
		    function scan(ip) {
	        	if ( ip == last ) {
	        		$dom.hide(el);
	                inprogress = false;
	    			libroot.showMessage(labels['LABEL_DIALOG_TITLE_ERROR'],labels['TEXT_CENTER_NOTFOUND']);
	        		return false;
	        	}
    			$dom(el,'div').setStyle('width',inx+'%');
            	inx += 100/(Math.pow(2,32 - CONST.NETMASK)-2);
		        var req = $ajax.ajax(URL.CENTERBEACON.replace('{0}',ip),{},'GET',{timeout:200, username: this.options.user, password: this.options.password});
		        req.done = function(response) {
		        	if ( response.type == CONST.CENTERSIGN && response.version ) {
			        	$dom.hide(el);
			        	_this.options.addrCenter = 'https://'+ip+':8843';
			        	libroot.showMessage(labels['LABEL_DIALOG_TITLE_SUCCESS'],labels['TEXT_CENTER_FOUND']);
						inprogress = false;
		        	} else {
		            	scan($ajax.ipAddr.increment(ip));
		        	} 
		    	}
		        req.error = function(response) {
		        	console.log("endpoint: " + ip);
	            	scan($ajax.ipAddr.increment(ip));
		    	}
	            return $ajax.ipAddr.increment(ip);
		    }
		    scan(_1st);
		},function(){
			libroot.showMessage(labels['LABEL_DIALOG_TITLE_ERROR'],labels['TEXT_CENTER_NOTFOUND']);
			inprogress = false;
		},10000);
		if ( !ret ) {
			libroot.showMessage(labels['LABEL_DIALOG_TITLE_WARNING'],labels['TEXT_BROWSER_NOTSUPPORTED']);
			inprogress = false;
		}
	}
}).call( Domux,nx );
