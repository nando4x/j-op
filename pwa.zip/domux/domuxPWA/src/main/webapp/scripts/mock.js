nx.Mock.define({
	  url: "/domuxCenter/restservice/getnodelist",
	  contentType: "application/json",
	  responseTime: [250, 750],
	  response : function(request){
		console.log('MOCK RESPONSE------- ');
		console.log('request data:');
		console.log(request);
		console.log('---------------------');
		
		if(request.code == 'E'){
			this.responseText = {
				    version: '00',
				    datetime: '2016-10-06T19:58:29Z',
				    status: "error",
				    message: "Generic error",
				    code: "ERR"
			}
			return;
			
		}
		if(request.code == 'F'){
			this.responseText = {
				    version: '00',
				    datetime: '2016-10-06T19:58:29Z',
				    status: "fail",
				    data: {
				    	fields: [{
				    		name: "xxx",
				    		error: "not null"
				    	}]
				    }
			}
			return;
			
		}
		
	
		//mocked response:
		this.responseText = {
			    version: '00',
			    datetime: '2016-10-06T19:58:29Z',
				status: "success",
				data:{
						nodelist:[
						       {dxid: 1,
						        id: 'node1',
						        type: 'RELAY6',
						        status: 'REGISTERED',
						        addrBT: '2312',
						        capabilities: {
						        	hasI2C: false,
						        	hasBT: true,
						        	hasIP: false
						        },
					        	resourceList: [
					        	   {dxid: 1, id: 'RELAY1', name: 'res1', type:'LIGHT', value: {isOn: false}},
					        	   {dxid: 2, id: 'RELAY2', name: 'res2', type:'LIGHT', value: {isOn: false}},
					        	   {dxid: 3, id: 'RELAY3', name: 'res3', type:'LIGHT', value: {isOn: false}},
					        	   {dxid: 4, id: 'RELAY4', name: 'res4', type:'PLUG', value: {isOn: false}},
					        	]
						       },
						       {dxid: 2,
							        id: 'node1',
							        type: 'RELAY6',
							        status: 'UNREGISTERED',
							        addrBT: '2312',
							        capabilities: {
							        	hasI2C: false,
							        	hasBT: true,
							        	hasIP: false
							        },
						        	resourceList: [
						        	   {dxid: 1, id: 'RELAY1', name: 'res1', type:'LIGHT', value: {isOn: false}},
						        	   {dxid: 2, id: 'RELAY2', name: 'res2', type:'LIGHT', value: {isOn: false}},
						        	   {dxid: 3, id: 'RELAY3', name: 'res3', type:'LIGHT', value: {isOn: false}},
						        	   {dxid: 4, id: 'RELAY4', name: 'res4', type:'PLUG', value: {isOn: false}},
						        	]
						       },
						       {dxid: 3,
							        id: 'node1',
							        type: 'RELAY6',
							        status: 'LOST',
							        addrBT: '2312',
							        capabilities: {
							        	hasI2C: false,
							        	hasBT: true,
							        	hasIP: false
							        },
						        	resourceList: [
							        	   {dxid: 1, id: 'RELAY1', name: 'res1', type:'LIGHT', value: {isOn: false}},
							        	   {dxid: 2, id: 'RELAY2', name: 'res2', type:'LIGHT', value: {isOn: false}},
							        	   {dxid: 3, id: 'RELAY3', name: 'res3', type:'LIGHT', value: {isOn: false}},
							        	   {dxid: 4, id: 'RELAY4', name: 'res4', type:'PLUG', value: {isOn: false}},
						        	]
						       }
						]
				}
		}
	  },
	  data: function( request ) {
		  	//here check of data inputs
		    return true;
	  }
});

nx.Mock.define({
	  url: "/domuxCenter/restservice/getmap",
	  contentType: "application/json",
	  responseTime: [250, 750],
	  response : function(request){
		console.log('MOCK RESPONSE------- ');
		console.log('request data:');
		console.log(request);
		console.log('---------------------');
		
		if(request.code == 'E'){
			this.responseText = {
				    version: '00',
				    datetime: '2016-10-06T19:58:29Z',
				    status: "error",
				    message: "Generic error",
				    code: "ERR"
			}
			return;
			
		}
		if(request.code == 'F'){
			this.responseText = {
				    version: '00',
				    datetime: '2016-10-06T19:58:29Z',
				    status: "fail",
				    data: {
				    	fields: [{
				    		name: "xxx",
				    		error: "not null"
				    	}]
				    }
			}
			return;
			
		}
		
	
		//mocked response:
		this.responseText = {
			    version: '00',
			    datetime: '2016-10-06T19:58:29Z',
				status: "success",
				data: {
					map:[
					   {
						   dxid:1,
						   x:100,
						   y:50
					   },
					   {
						   dxid:3,
						   x:250,
						   y:120
					   }
					]
				}
		}
	  },
	  data: function( request ) {
		  	//here check of data inputs
		    return true;
	  }
});
