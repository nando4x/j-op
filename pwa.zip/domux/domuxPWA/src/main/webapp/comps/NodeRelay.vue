<template compile-with="labels">
	<div class="cell-expanded scrollable _desktop">
		<ul class="nx-list _grid">
			<li v-for="(current,index) in resources" @click="openResource(current.id)">
				<div :id="current.dxid"class="p-cell">
	  				<img class="p-icon" :src="getImgByType(current.type, current.value)">
	  				<div class="summary centered">
	  					<div class="p-row">
			  				<label>$(LABEL_CONFIG_TABNODELIST_NAME)</label>
			  				<div class="p-item">{{current.name}}</div>
	  					</div>
	  				</div>
	  			</div>
			</li>
		</ul>
		<div nx-attach-comp="Modal" class="nx-modal"><a class="p-close-icon"></a>
			<div class="summary boxround width_100">
				<div class="p-row">
	  				<label>$(LABEL_CONFIG_TABNODELIST_ID)</label>
	  				<div class="p-item">{{currentResource.dxid}}</div>
				</div>
				<div class="p-row">
	  				<label>$(LABEL_CONFIG_TABNODELIST_NAME)</label>
	  				<input class="p-item nx-input" v-model="currentResource.name" :disabled="!isEditing"
				  		:class="fieldsError.name&&fieldsError.name!=''?'_error':''"/>
	  				<div class="nx-error-tooltip" v-if="fieldsError.name&&fieldsError.name!=''"><div>{{fieldsError.name}}</div></div>
				</div>
				<div class="p-row">
	  				<label>$(LABEL_CONFIG_TABNODERELAY_SWDURATION)</label>
	  				<input class="p-item nx-input" v-model="currentResource.value.switchDuration" :disabled="!isEditing"
				  		:class="fieldsError.switchDuration&&fieldsError.switchDuration!=''?'_error':''"/>
	  				<div class="nx-error-tooltip" v-if="fieldsError.switchDuration&&fieldsError.switchDuration!=''"><div>{{fieldsError.switchDuration}}</div></div>
				</div>
 			</div>
			<div class="flex-container _col">
				<div class="cell-col _sm6 _md6 text-center">
					<div class="boxround">
						<img class="p-image" 
							:class="isEditing?'_editing':''"
							:src="getImgByType(currentResource.type, currentResource.value)"
							@click="isEditing?showResourceTypeCarousel=true:null">
					</div>
					<div class="nx-list _carousel boxround" v-if="showResourceTypeCarousel">
						<a class="p-close-icon" @click="showResourceTypeCarousel=false"></a>
						<div class="p-content">
							<div v-for="type in types"><img :src="getImgByType(type)" style="cursor:pointer" @click="currentResource.type=type"></div>
						</div>
					</div>
				</div>
				<div class="cell-col _sm6 _md6 text-center">
					<div class="">
						<div class="nx-switch">
						    <label>
						      Off
						      <input type="checkbox" v-model="currentResource.value.isOn">
						      <span class="lever"></span>
						      On
						    </label>
						</div>
					</div>
				</div>
			</div>
			<div class="p-button-bar">
				<button @click="closeResource">$(LABEL_CONFIG_TABNODELIST_BUTTONNOTHING)</button>
				<button @click="saveResource" :disabled="!isEditing">$(LABEL_CONFIG_TABNODELIST_BUTTONSAVE)</button>
			</div>
		</div>
	</div>
</template>

<script>
	var libroot = nx;
	this.NodeRelay = {
		mixins: [Domux.resourceComponent],
		template: '',
		props: {
			"isEditing": {
				type: Boolean,
				"default": false
			}
		},
		data: function() {
			return {
				currentResource: {"value": {"isOn":false}},
				backResource: {},
				modal: null,
				showResourceTypeCarousel: false,
				isOn: false,
				fieldsError: {name:'', switchDuration: ''}
			}
		},
		computed: {
			resources: function() {
				this.backResource;
				return (this.value || {}).resourceList;
			},
			types: function() {
				return ['LIGHT','PLUG'];
			}
		},
		methods: {
			getImgByType: function (type, value) {
				var img = 'images/' + type + (value&&value.isOn?'_ON':'') + '.png';
				return img;
			},
			openResource: function(id) {
				for ( var ix=0; ix<this.value.resourceList.length; ix++ ) {
					if (this.value.resourceList[ix].id == id) {
						this.currentResource = libroot.clone(this.value.resourceList[ix]);
						this.backResource = libroot.clone(this.currentResource);
						break;
					}
				}
				this.modal.open();
			},
			closeResource: function(id) {
				this.modal.close();
			},
			validateResource: function(res) {
				if ( this.validate(res) ) {
					this.fieldsError.switchDuration = '';
					if ( res.value.switchDuration && res.value.switchDuration >= RELAY_MIN_SWITCH_DURATION && res.value.switchDuration <= RELAY_MAX_SWITCH_DURATION )
							return true;
					this.fieldsError.switchDuration = window.labels['ERROR_FIELD_RELAY_SWDURATION'];
				}
				return false;
			},
			saveResource: function() {
				if ( this.validateResource(this.currentResource) ) {
					for ( var ix=0; ix<this.value.resourceList.length; ix++ ) {
						if (this.value.resourceList[ix].id == this.currentResource.id) {
							this.value.resourceList[ix] = this.currentResource;
							this.backResource = null;
							break;
						}
					}
					this.modal.close();
				}
			},
			onClosing: function() {
				if ( this.backResource != null )
					this.currentResource = this.backResource;  
			}
		},
		watch: {
			'currentResource.value.isOn': function(value) {
				for ( var ix=0; ix<this.value.resourceList.length; ix++ ) {
					if (this.value.resourceList[ix].id == this.currentResource.id ) {
						if ( this.value.resourceList[ix].value.isOn != value ) {
							var _this = this;
							Domux.sendResource(this.currentResource).setsuccess(function(data){
								if ( data.value ) {
									_this.value.resourceList[ix].value.isOn = data.value.isOn;
									_this.currentResource.value.isOn = data.value.isOn;
								}
							});
						}
						break;
					}
				}
			}
		},
		mounted: function() {
			this.modal = new libroot.Component.Modal(libroot.Dom.qry(this.$el,'.nx-modal'));
			this.modal.onclosing = this.onClosing;
		}
	}
	//nx.Component.registerAsyncVueComp('comp',vueTestComp);
</script>