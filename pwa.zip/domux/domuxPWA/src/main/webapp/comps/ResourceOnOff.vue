<template compile-with="labels">
	<div :res-id="value.dxid" :class="styleClass" :draggable="draggable?'true':'false'" @dragstart="drag" 
		 style="cursor:pointer; position: relative;" 
		 :style="style"
		 @click="click">
		<i v-if="allarm" class="material-icons status-icon">warning</i>
		<div style="position: relative;" :style="loading?'opacity: 0.5':''">
			<svg class="p-spinner" v-if="loading" viewBox="0 0 32 32" width="32" height="32" style="
			    height: 17px;
			    top: 50%;
			    left: 50%;
			    transform: translate(-50%, -50%);">
		    	<circle cx="16" cy="16" r="14" fill="none"></circle>
		    </svg>		
			<img :src="imageStatus">
		</div>
		<div class="">{{value.name}}</div>
	</div>
</template>
<script>
	var libroot = nx;
	this.ResourceOnOff = {
		mixins: [Domux.resourceComponent],
		template: '',
		data: function() {
			return {
				loading: false
			}
		},
		computed: {
			style: function() {
				return (this.left && this.top?{position:'absolute',left:this.left+'px',top:this.top+'px'}:'');
			},
			imageStatus: function() {
				var inx = this.image.lastIndexOf(".");
				if ( inx > 0 ) {
					return this.image.substring(0,inx) + 
						   (this.value.value&&this.value.value.isOn?'_ON':'') +
						  this.image.substr(inx);
				}
				return this.image;
			}
		},
		methods: {
			click: function() {
				if ( this.loading )
					return;
				if ( this.value.nodeStatus == 'LOST' ) {
					Domux.showWarn('', window.labels["WARNLOCAL_NODE_NTCONNECTED"]);
					return;
				}
				this.value.value.isOn = !this.value.value.isOn;
				var _this = this;
				this.loading = true;
				Domux.sendResource(this.value).setsuccess(function(data){
					_this.value.value = data.value;
				}).setalways(function(){
					_this.loading = false;
				});
			}
		},
		mounted: function() {
		}
	}
</script>