if ( (location.search || '').indexOf('?') == 0 ) {
	self.importScripts(location.search.substr(1));	
} else {
	var VERSION = '0';
	var cacheName = 'domux';
	var filesToCache = ['index.html'];
	var services = [];
	var uncached = [];
	var exclude = [];
}

self.addEventListener('install', function(e) {
	self.skipWaiting();
	console.log('[ServiceWorker] Install');
	e.waitUntil(
	    caches.open(cacheName+'.'+VERSION).then(function(cache) {
	    	console.log('[ServiceWorker] Caching app shell: '+cacheName+'.'+VERSION);
	    	return cache.addAll(filesToCache);
	    })
	);
});

self.addEventListener('activate', function(e) {
	console.log('[ServiceWorker] Activate');
	e.waitUntil(
		caches.keys().then(function(keyList) {
			return Promise.all(keyList.map(function(key) {
				if (key !== (cacheName+'.'+VERSION) && key.indexOf(cacheName) >= 0 ) {
					console.log('[ServiceWorker] Removing old cache', key);
					return caches.delete(key);
				}
			}));
		}).then(function(){
			return self.clients.claim();
		})
	);
  //return self.clients.claim();
});

function addToCache(cacheId,request,response) {
    caches.open(cacheId).then(function(cache) {
    	cache.put(request, response);
    });
}

function checkIfContains(url,list) {
	url = url || '';
	for ( var ix in list ) {
		var i = list[ix].indexOf('*');
		if ( i >= 0 ) {
			var arr = list[ix].split('*');
			if ( url.endsWith(arr[1]) ) {
				if ( url.split(arr[0]).length > 1 )
					return true;
			}
		} else if ( url.endsWith(list[ix]) ) {
			return true;
		}
	}
	return false;
}

self.addEventListener('fetch', function(event) {
		if ( checkIfContains(event.request.url,exclude) ) {
			return false;
		} else if ( checkIfContains(event.request.url,uncached) ) {
        	console.log('[Service Worker] Fetch1 from network :', event.request.url);
    	    event.respondWith(fetch(event.request));
    		return false;
    	} else if ( checkIfContains(event.request.url,services) ) {
    		event.respondWith(
		        fetch(event.request).then(function(response) {
		        	console.log('[Service Worker] Fetch2'+(response?' (from network)':'')+' :', event.request.url);
	            	addToCache(cacheName+'.'+VERSION,event.request,response.clone());
		            return response;
		        }).catch(function() {
		        	console.log('[Service Worker] Fetch2 (from cache) :', event.request.url);
		            return caches.match(event.request);
		        })
	        );
    	} else {
    		event.respondWith(
		        caches.match(event.request).then(function(response) {
		        	console.log('[Service Worker] Fetch'+(response?' (from cache)':'')+' :', event.request.url);
		            return response || fetch(event.request).then(function(resp){
			        	console.log('[Service Worker] add to cache: '+ event.request.url);
		            	addToCache(cacheName+'.'+VERSION,event.request,resp.clone());
		                return resp;
		              });
		        })
	        );
    	}
});


/*
‘use strict’;
//Array di configurazione del service worker
var config = {
version: ‘versionesw1::’,
//Risorse da inserire in cache immediatamente - Precaching
staticCacheItems: [
‘/wp-includes/js/jquery/jquery.js’,
‘/wp-content/themes/miotema/logo.png’,
‘/wp-content/themes/miotema/fonts/opensans.woff’,
‘/wp-content/themes/miotema/fonts/fontawesome-webfont.woff2’,
],
};
//Funzione che restituisce una stringa da utilizzare come chiave per la cache
function cacheName (key, opts) {
return `${opts.version}${key}`;
}
//Evento install
self.addEventListener('install', event => {
event.waitUntil(
// Inserisco in cache le URL configurate in config.staticCacheItems
caches.open( cacheName('static', config) ).then(cache => cache.addAll(config.staticCacheItems))
// self.skipWaiting() evita l'attesa, il che significa che il service worker si attiverà immediatamente non appena conclusa l'installazione
.then( () => self.skipWaiting() ) 
);
console.log("Service Worker Installato");
});

self.addEventListener('activate', event => {
	 // Questa funzione elimina dalla cache tutte le risorse la cui chiave non contiene il nome della versione
	 // impostata sul config di questo service worker
	 function clearCacheIfDifferent(event, opts) {
	   return caches.keys().then(cacheKeys => {
	     var oldCacheKeys = cacheKeys.filter(key => key.indexOf(opts.version) !== 0);
	     var deletePromises = oldCacheKeys.map(oldKey => caches.delete(oldKey));
	     return Promise.all(deletePromises);
	   });
	 }
	event.waitUntil(
	 // Se la versione del service worker cambia, svuoto la cache
	 clearCacheIfDifferent(event, config)
	 // Con self.clients.claim() consento al service worker di poter intercettare le richieste (fetch) fin da subito piuttosto che attendere il refresh della pagina
	 .then( () => self.clients.claim() )
	 );
	 console.log("Service Worker Avviato");
	});

net1st
self.addEventListener('fetch', function(event) {
    event.respondWith(
        fetch(event.request).then(function(response) {
            cache.put(event.request, response.clone());
            return response;
        }).catch(function() {
            return caches.match(event.request);
        })
    );
});

cache1st
self.addEventListener('fetch', function(event) {
    event.respondWith(
        caches.match(event.request).then(function(response) {
            return response || fetch(event.request);
        })
    );
});

netonly
self.addEventListener('fetch', function(event) {
    event.respondWith(fetch(event.request));
});

cacheonly
self.addEventListener('fetch', function(event) {
    event.respondWith(caches.match(event.request));
});


parallel
function promiseAny(promises) {
    return new Promise((resolve, reject) => {
        promises = promises.map(p => Promise.resolve(p));
        promises.forEach(p => p.then(resolve));
        promises.reduce((a, b) => a.catch(() => b)).catch(() => reject(Error("All failed")));
    });
};
self.addEventListener('fetch', function(event) {
    event.respondWith(
       promiseAny([caches.match(event.request), fetch(event.request)])
    );
});


parallel recache
var networkDataReceived = false;
var risorsa = '/data.json';
startSpinner();
// Richiesta di rete (intercettata dal service worker)
var networkUpdate = fetch(risorsa).then(function(response) {
    return response.json();
}).then(function(data) {
    networkDataReceived = true;
    updatePage();
});
// Richiesta dalla cache
caches.match(risorsa).then(function(response) {
    if (!response) throw Error("No data");
    return response.json();
}).then(function(data) {
    // Aggiorno la pagina se il contenuto dalla rete non e' stato ancora ricevuto
    if (!networkDataReceived) {
      updatePage(data);
    }
}).catch(function() {
    // Contenuto non presente in cache, attendo quello dalla rete
    return networkUpdate;
}).catch(showErrorMessage).then(stopSpinner);
Di seguito quello del service worker:

self.addEventListener('fetch', function(event) {
    event.respondWith(
        fetch(event.request).then(function(response) {
            cache.put(event.request, response.clone());
            return response;
        })
    );
});

*/