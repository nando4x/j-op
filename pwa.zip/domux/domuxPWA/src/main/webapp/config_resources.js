var VERSION = '0.0.0-alpha1';
var cacheName = 'domuxResources';
var filesToCache = [
	'index.html',
	'pages/configuration.html',
	'pages/home.html',
	'pages/options.html',
	'pages/status.html',
	'scripts/libs/jquery.js',
	'scripts/libs/vue.js',
	'scripts/libs/nx.js',
	'scripts/libs/nodulex/utils.js',
	'scripts/libs/nodulex/ajax.js',
	'scripts/libs/nodulex/mockajax.js',
	'scripts/libs/nodulex/dom.js',
	'scripts/libs/nodulex/event.js',
	'scripts/libs/nodulex/binding.js',
	'scripts/libs/nodulex/components.js',
	'scripts/libs/nodulex/components/menu.js',
	'scripts/libs/nodulex/components/navigatorBar.js',
	'scripts/libs/nodulex/components/tabs.js',
	'scripts/libs/nodulex/components/listTemplated.js',
	'scripts/libs/nodulex/components/modal.js',
	'scripts/libs/nodulex/components/password.js',
	'scripts/libs/nodulex/components/accordion.js',
	'scripts/libs/nodulex/components/spinner.js',
	'scripts/libs/nodulex/components/table.js',
	'scripts/libs/nodulex/rest.js',
	'scripts/GlobalDefine.js',
	'css/nx.css',
	'css/pwa.css',
	'css/domux.css',
	'scripts/mock.js',
	'scripts/domux.js',
	'scripts/domux-options.js',
	'scripts/domux-status.js',
	'comps/NodeRelay.vue',
	'comps/ResourceOnOff.vue',
	'comps/Status.vue'
];
var services = [
	"config_resources.js"
];

var exclude = ['restservice/*'];
